import presetIcons from '@unocss/preset-icons'
import { defineConfig } from 'unocss'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import presetUno from '@unocss/preset-uno'
import { FileSystemIconLoader } from '@iconify/utils/lib/loader/node-loaders'

const iconDirectory = resolve(__dirname, 'icons')
export default defineConfig({
  presets: [
    presetUno(),
    presetIcons({ 
      extraProperties: {
        'display': 'inline-block',
        'vertical-align': 'middle',
        'width': '24px',
        'height': '24px',
      },
      collections: {
        custom: FileSystemIconLoader(iconDirectory),
      },
     }),
  ],
})
