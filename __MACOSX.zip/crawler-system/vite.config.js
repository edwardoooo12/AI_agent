import { fileURLToPath, URL } from 'node:url'

import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'
import vueJsx from '@vitejs/plugin-vue-jsx'
import UnoCSS from 'unocss/vite'
import { codeInspectorPlugin } from 'code-inspector-plugin'
// import vueDevTools from 'vite-plugin-vue-devtools'

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, process.cwd(), '')
    console.log(env.VITE_PROXY_TARGET, 'env')
    const proxyTarget = env.VITE_PROXY_TARGET || 'https://dev-api.lizh.tech'
    return {
        // base: './', // 设置为相对路径，解决本地访问问题，生产要绝对路径
        plugins: [
            UnoCSS(),
            vue(),
            vueJsx(),
            // vueDevTools(), // 暂时禁用以解决兼容性问题
        ],
        resolve: {
            alias: {
                '@': fileURLToPath(new URL('./src', import.meta.url))
            },
        },
        server: {
            proxy: {
                "/api": {

                    target: "http://localhost:8080/api",
                    // target: "https://dev-api.lizh.tech/api",
                    changeOrigin: true,
                    rewrite: (path) => path.replace(/^\/api/, ""),
                },
            }
        }
    }
})
