import { ref, reactive } from 'vue';
import type { PaginationParams, UsePaginationReturn, PaginationState } from '../types/pagination';

/**
 * 通用分页钩子
 * @param apiFunc 分页API函数
 * @param initialParams 初始参数
 */
export function usePagination<T>(
  apiFunc: (params: any) => Promise<any>,
  initialParams: Record<string, any> = {}
): UsePaginationReturn<T> {
  // 分页状态
  const state = reactive<PaginationState<T>>({
    list: [],
    loading: false,
    pageNum: 1,
    pageSize: 10,
    total: 0
  });

  // 请求参数
  const params = ref<Record<string, any>>({
    ...initialParams
  });

  // 加载数据
  const loadList = async () => {
    try {
      state.loading = true;
      const requestParams: PaginationParams & Record<string, any> = {
        ...params.value,
        pageNum: state.pageNum,
        pageSize: state.pageSize
      };

      const response = await apiFunc(requestParams);
      const { code, rows, total, data } = response;

      if (code === 200) {
        if (Array.isArray(rows)) {
          state.list = rows;
          state.total = total;
        } else if (data && Array.isArray(data.rows)) {
          state.list = data.rows;
          state.total = Number(data.total || 0);
        } else if (Array.isArray(data)) {
          state.list = data;
          state.total = data.length;
        } else {
          state.list = [];
          state.total = 0;
        }
      }
    } catch (error) {
      console.error('分页加载失败:', error);
      state.list = [];
      state.total = 0;
    } finally {
      state.loading = false;
    }
  };

  // 处理页码变化
  const handlePageChange = (page: number) => {
    state.pageNum = page;
    loadList();
  };

  // 处理页面大小变化
  const handleSizeChange = (size: number) => {
    state.pageSize = size;
    state.pageNum = 1;
    loadList();
  };

  // 更新参数
  const updateParams = (newParams: Record<string, any>) => {
    Object.assign(params.value, newParams);
    state.pageNum = 1;
    loadList();
  };

  return {
    state: state as PaginationState<T>,
    params: params.value,
    loadList,
    handlePageChange,
    handleSizeChange,
    updateParams
  };
}
