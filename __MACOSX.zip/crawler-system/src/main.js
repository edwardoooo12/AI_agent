import 'element-plus/dist/index.css'
import './assets/styles/index.scss'
import './assets/main.less'

import { createApp } from 'vue'
import { createPinia } from 'pinia'
import ElementPlus from 'element-plus'
import ECharts from 'vue-echarts'
import { use } from 'echarts/core'
import zhCn from 'element-plus/es/locale/lang/zh-cn'

// 引入 echarts 图表
import {
    CanvasRenderer
} from 'echarts/renderers'
import {
    BarChart,
    PieChart,
    LineChart,
    TreeChart,
    HeatmapChart,
    SankeyChart,
    RadarChart,
    GraphChart
} from 'echarts/charts'
import {
    GridComponent,
    TooltipComponent,
    LegendComponent,
    TitleComponent,
    VisualMapComponent
} from 'echarts/components'

import App from './App.vue'
import router from './router'
import 'virtual:uno.css'

// 注册必须的组件
use([
    CanvasRenderer,
    BarChart,
    PieChart,
    LineChart,
    TreeChart,
    HeatmapChart,
    SankeyChart,
    RadarChart,
    GraphChart,
    GridComponent,
    TooltipComponent,
    LegendComponent,
    TitleComponent,
    VisualMapComponent
])

const app = createApp(App)

app.use(createPinia())
app.use(router)
app.use(ElementPlus, {
    locale: zhCn,
})
app.component('v-chart', ECharts)

app.mount('#app')
