import api from '@/utils/request'

// 接口返回类型（简化）
export type MilitaryChartResponse = {
  code: number
  msg?: string
  data: any
}

// 获取军事可视化图表数据
export async function getMilitaryChart(): Promise<MilitaryChartResponse> {
  const res = await api({ url: '/military/chart', method: 'get' })
  return res.data as MilitaryChartResponse
}


// 装备列表查询参数
export type MilitaryEquipmentListParams = {
  country?: string;
  equipmentName?: string;
  militaryStructureId?: number;
  pageNum?: number;
  pageSize?: number;
}

// 获取装备列表
export async function getMilitaryEquipmentList(
  params: MilitaryEquipmentListParams
): Promise<MilitaryChartResponse> {
  const res = await api({
    url: '/military/equipment/list',
    method: 'get',
    params,
  })
  return res.data as MilitaryChartResponse
}

// 获取指定国家的装备统计图表数据
export async function getCountryEquipmentChart(country: number | string): Promise<MilitaryChartResponse> {
  const res = await api({
    url: '/country/equipment/chart',
    method: 'get',
    params: { country }
  })
  return res.data as MilitaryChartResponse
}

// 获取设施台账列表
export type MilitaryFacilityListParams = {
  country?: number | string
  pageSize?: number
  pageNum?: number
}

// 获取设施台账分页列表
export async function getMilitaryFacilityList(
  params: MilitaryFacilityListParams
): Promise<MilitaryChartResponse> {
  const res = await api({
    url: '/military/facility/list',
    method: 'get',
    params,
  })
  return res.data as MilitaryChartResponse
}


