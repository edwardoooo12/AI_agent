<script setup>
import { RouterLink, RouterView, useRoute, useRouter } from "vue-router";
import { ref, computed } from "vue";

const route = useRoute();
const router = useRouter();

// 一级菜单配置
const primaryMenus = [
  {
    key: "data-crawling",
    label: "数据爬取",
    icon: "i-custom-location",
    path: "/data-crawling",
  },
  {
    key: "storage-management",
    label: "数据存储",
    icon: "i-custom-storage",
    path: "/storage-management",
  },
  {
    key: "data-retrieval",
    label: "数据检索",
    icon: "i-custom-qgsearch",
    path: "/data-retrieval",
  },
  {
    key: "data-visualization",
    label: "数据可视化",
    icon: "i-custom-time",
    path: "http://127.0.0.1:8010",
    external: true,
  },
];

// 二级菜单配置
const secondaryMenus = {
  "data-crawling": [
    {
      index: "/data-crawling/summary",
      label: "数据源总览",
      icon: "i-custom-tv",
    },
    {
      index: "/data-crawling/source-config",
      label: "数据源列表",
      icon: "i-custom-config",
    },
    {
      index: "/data-crawling/manual-crawl",
      label: "数据爬取",
      icon: "i-custom-config",
    },
    {
      index: "/data-crawling/data-export",
      label: "数据导出",
      icon: "i-custom-export",
    },
  ],
  "data-retrieval": [
    {
      index: "/data-retrieval/title-search",
      label: "标题检索",
      icon: "i-custom-export",
    },
    {
      index: "/data-retrieval/fulltext-search",
      label: "全文检索",
      icon: "i-custom-fulltext",
    },
  ],
  "data-visualization": [
    {
      index: "/data-visualization/raw-data",
      label: "原始数据",
      icon: "i-custom-data",
    },
    {
      index: "http://127.0.0.1:8010",
      label: "数据分析",
      external: true,
      icon: "i-custom-analysis",
    },
  ],
  "storage-management": [
    {
      index: "/storage-management/data-overview",
      label: "数据总览",
      icon: "i-custom-tv",
    },
    {
      index: "/storage-management/data-export",
      label: "导出数据",
      icon: "i-custom-export",
    },
    {
      index: "/storage-management/data-import",
      label: "导入数据",
      icon: "i-custom-fulltext",
    },
    {
      index: "/storage-management/data-delete",
      label: "删除数据",
      icon: "i-custom-export",
    },
  ],
};

// 当前激活的一级菜单
const activeTopMenu = computed(() => {
  const pathSegments = route.path.split("/");
  if (pathSegments.length >= 2) {
    return pathSegments[1];
  }
  return "data-overview";
});

// 当前二级菜单列表
const currentSecondaryMenus = computed(() => {
  const currentMenu = primaryMenus.find((m) => m.key === activeTopMenu.value);
  // 如果是外部链接菜单，不显示二级菜单
  if (currentMenu && currentMenu.external) {
    return [];
  }
  return secondaryMenus[activeTopMenu.value] || [];
});

// 顶部菜单点击处理
const handleTopMenuClick = (menuKey) => {
  const menu = primaryMenus.find((m) => m.key === menuKey);
  if (menu) {
    // 如果是外部链接，直接跳转
    if (menu.external) {
      window.location.href = menu.path;
      return;
    }
    // 如果有二级菜单，跳转到第一个二级菜单
    if (secondaryMenus[menuKey] && secondaryMenus[menuKey].length > 0) {
      const firstSecondaryMenu = secondaryMenus[menuKey][0];
      router.push(firstSecondaryMenu.index);
    }
  }
};

// 二级菜单点击处理（支持外部链接）
const handleSecondaryMenuItemClick = (item) => {
  if (item && item.external) {
    window.location.href = item.index;
    // window.open(item.index, "_blank");
    return;
  }
  if (item && item.index) {
    router.push(item.index);
  }
};
</script>

<template>
  <el-container style="height: 100vh">
    <!-- 顶部一级菜单 -->
    <el-header class="top-header">
      <div class="header-content">
        <i class="i-custom-group w-[20px] h-[20px] mr-4"></i>
        <h3 class="system-title">高性能非结构化数据存储系统 V1.0</h3>
        <el-menu
          :default-active="activeTopMenu"
          mode="horizontal"
          class="top-menu"
          @select="handleTopMenuClick"
        >
          <el-menu-item
            v-for="menu in primaryMenus"
            :key="menu.key"
            :index="menu.key"
          >
            <i :class="['mr-1', menu.icon]"></i>
            {{ menu.label }}
          </el-menu-item>
        </el-menu>
      </div>
    </el-header>

    <el-container class="main-container">
      <!-- 左侧二级菜单 -->
      <el-aside width="283px" class="menu-left">
        <div class="secondary-menu-container">
          <div
            v-for="item in currentSecondaryMenus"
            :key="item.index"
            :class="[
              'menu-item',
              { 'menu-item-active': $route.path === item.index },
            ]"
            @click="handleSecondaryMenuItemClick(item)"
          >
            <div class="menu-item-content">
              <i :class="['menu-icon', item.icon]"></i>
              <span class="menu-label">{{ item.label }}</span>
            </div>
            <i v-if="$route.path === item.index" class="menu-arrow">></i>
          </div>
        </div>
      </el-aside>

      <!-- 主内容区域 -->
      <el-container class="right-container">
        <el-main>
          <RouterView />
        </el-main>
      </el-container>
    </el-container>
  </el-container>
</template>

<style scoped>
/* 顶部头部样式 */
.top-header {
  height: 80px;
  background: #fff;
  border-bottom: 1px solid #e6e6e6;
  padding: 0;
}

.header-content {
  display: flex;
  align-items: center;
  height: 100%;
  padding: 0 20px;
}

.system-title {
  margin: 0;
  margin-right: 40px;
  color: #333;
  font-size: 20px;
  font-weight: bold;
}

/* 顶部横向菜单样式 */
.top-menu {
  flex: 1;
  border-bottom: none;
  margin-left: 20%;
}

.top-menu .el-menu-item {
  font-size: 16px;
  font-weight: 500;
  padding: 0 30px;
}

.top-menu .el-menu-item:hover {
  background-color: #f5f7fa;
}

/* 左侧菜单样式 */
.menu-left {
  background-image: url("@/assets/imgs/bg1.jpg");
  background-size: cover;
  padding: 20px 16px;
}

.secondary-menu-container {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.menu-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  border-radius: 8px;
  background: #ffffff;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.menu-item:hover {
  background: linear-gradient(90deg, #3490df 0%, #1c4e79 100%);
  color: #ffffff !important;
  border-color: #cbd5e1;
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.menu-item:hover .menu-label,
.menu-item:hover .menu-icon {
  color: #ffffff !important;
}

.menu-item-active {
  background: linear-gradient(90deg, #3490df 0%, #1c4e79 100%);
  color: #ffffff !important;
  box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3) !important;
}

.menu-item-content {
  display: flex;
  align-items: center;
  gap: 12px;
  flex: 1;
}

.menu-icon {
  width: 20px;
  height: 20px;
  font-size: 18px;
  color: #64748b;
}

.menu-item-active .menu-icon {
  color: #ffffff;
}

.menu-label {
  font-size: 14px;
  font-weight: 500;
  color: #334155;
}

.menu-item-active .menu-label {
  color: #ffffff;
}

.menu-arrow {
  font-size: 16px;
  font-weight: bold;
  color: #ffffff;
  margin-left: 8px;
}

/* 主内容区域样式 */
.right-container {
  background: #d0e2f0;
}

.el-main {
  padding: 20px;
}
</style>
