# Element Plus 全局样式系统

本目录包含了完整的 Element Plus 全局样式系统，提供了统一的主题配置、组件样式覆盖和工具类。

## 文件结构

```
src/assets/styles/
├── index.scss                 # 样式入口文件
├── theme-variables.scss       # 主题变量配置
├── element-theme.scss         # Element Plus 主题样式
├── component-overrides.scss   # 组件样式覆盖
└── README.md                  # 说明文档
```

## 文件说明

### 1. index.scss - 样式入口文件

- 统一引入所有样式文件
- 提供全局工具类
- 包含全局重置样式
- 响应式设计支持

### 2. theme-variables.scss - 主题变量配置

- 定义所有主题色彩变量
- 配置字体、间距、阴影等变量
- 支持暗色主题
- 导出为 CSS 变量供全局使用

### 3. element-theme.scss - Element Plus 主题样式

- 覆盖 Element Plus 默认主题
- 使用自定义主题变量
- 提供渐变效果和动画
- 响应式适配

### 4. component-overrides.scss - 组件样式覆盖

- 针对特定组件的样式增强
- 提供悬停效果和过渡动画
- 统一组件外观
- 移动端适配

## 主题色彩

### 主色调

- **主色**: #3490DF (蓝色)
- **浅色变体**: #5BA3E8, #7BB6ED, #9BC9F2, #B3D5F5, #CBE2F8
- **深色变体**: #1C4E79

### 功能色

- **成功色**: #67C23A (绿色)
- **警告色**: #E6A23C (橙色)
- **危险色**: #F56C6C (红色)
- **信息色**: #909399 (灰色)

## 使用方法

### 1. 在组件中使用主题变量

```vue
<template>
  <div class="custom-component">
    <h1>标题</h1>
    <p>内容</p>
  </div>
</template>

<style scoped>
.custom-component {
  color: var(--el-text-color-primary);
  background-color: var(--el-bg-color);
  border: 1px solid var(--el-border-color);
  border-radius: var(--el-border-radius-base);
  padding: var(--el-spacing-md);
  box-shadow: var(--el-box-shadow-light);
}
</style>
```

### 2. 使用工具类

```vue
<template>
  <div class="global-styles">
    <!-- 文本颜色 -->
    <p class="text-primary">主要文本</p>
    <p class="text-success">成功文本</p>

    <!-- 背景色 -->
    <div class="bg-gradient-primary p-md rounded">渐变背景卡片</div>

    <!-- 布局 -->
    <div class="flex-center">
      <button class="hover-lift transition">悬停按钮</button>
    </div>
  </div>
</template>
```

### 3. 自定义主题

修改 `theme-variables.scss` 文件中的变量值：

```scss
// 修改主色调
$primary-color: #your-color;

// 修改字体大小
$font-size-base: 16px;

// 修改边框半径
$border-radius-base: 8px;
```

## 工具类列表

### 文本工具类

- `.text-primary`, `.text-success`, `.text-warning`, `.text-danger`, `.text-info`
- `.text-xs`, `.text-sm`, `.text-base`, `.text-lg`, `.text-xl`
- `.font-normal`, `.font-medium`, `.font-bold`
- `.text-left`, `.text-center`, `.text-right`

### 背景工具类

- `.bg-primary`, `.bg-success`, `.bg-warning`, `.bg-danger`, `.bg-info`
- `.bg-gradient-primary`, `.bg-gradient-success`, `.bg-gradient-warning`, `.bg-gradient-danger`, `.bg-gradient-info`

### 边框工具类

- `.border-primary`, `.border-success`, `.border-warning`, `.border-danger`, `.border-info`
- `.rounded`, `.rounded-sm`, `.rounded-lg`, `.rounded-full`

### 阴影工具类

- `.shadow-light`, `.shadow`, `.shadow-dark`

### 间距工具类

- `.p-xs`, `.p-sm`, `.p-md`, `.p-lg`, `.p-xl`
- `.m-xs`, `.m-sm`, `.m-md`, `.m-lg`, `.m-xl`

### 布局工具类

- `.flex-center`, `.flex-between`, `.flex-start`, `.flex-end`
- `.flex-column`, `.flex-wrap`, `.flex-nowrap`

### 效果工具类

- `.hover-lift`, `.hover-scale`, `.hover-glow`
- `.transition`, `.transition-fast`, `.transition-slow`
- `.loading`

## 响应式设计

样式系统支持以下断点：

- **xs**: ≤ 480px
- **sm**: 481px - 768px
- **md**: 769px - 1024px
- **lg**: 1025px - 1920px
- **xl**: ≥ 1920px

## 暗色主题

系统自动检测用户的暗色主题偏好，并应用相应的样式。也可以通过修改 `theme-variables.scss` 中的暗色主题变量来自定义。

## 注意事项

1. 所有样式文件都通过 `index.scss` 统一引入
2. 主题变量必须在其他样式文件之前引入
3. 使用工具类时需要在父元素上添加 `global-styles` 类
4. 自定义样式建议使用 CSS 变量而不是直接修改 SCSS 变量
5. 移动端适配已内置，无需额外配置

## 更新日志

- **v1.0.0**: 初始版本，包含基础主题和组件样式
- 支持 Element Plus 2.x
- 提供完整的工具类系统
- 响应式设计支持
- 暗色主题支持
