// 分页参数类型
export interface PaginationParams {
  pageNum: number;
  pageSize: number;
}

// 分页状态类型
export interface PaginationState<T = any> {
  list: T[];
  loading: boolean;
  pageNum: number;
  pageSize: number;
  total: number;
}

// 分页钩子返回类型
export interface UsePaginationReturn<T = any> {
  state: PaginationState<T>;
  params: Record<string, any>;
  loadList: () => Promise<void>;
  handlePageChange: (page: number) => void;
  handleSizeChange: (size: number) => void;
  updateParams: (newParams: Record<string, any>) => void;
}
