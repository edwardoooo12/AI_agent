import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      redirect: '/data-crawling/summary'
    },
    {
      path: '/data-crawling',
      name: 'DataCrawling',
      redirect: '/data-crawling/summary',
      children: [
        {
          path: 'summary',
          name: 'summary',
          component: HomeView,
        },
        {
          path: 'source-config',
          name: 'DataSourceConfig',
          component: () => import('../views/DataSourceTable.vue'),
        },
        {
          path: 'manual-crawl',
          name: 'ManualCrawling',
          component: () => import('../views/ManualCrawling.vue'),
        },
        {
          path: 'data-export',
          name: 'DataExport',
          component: () => import('../views/DataExport.vue'),
        },
      ]
    },
    {
      path: '/data-retrieval',
      name: 'DataRetrieval',
      redirect: '/data-retrieval/title-search',
      children: [
        {
          path: 'title-search',
          name: 'TitleSearch',
          component: () => import('../views/TitleSearch.vue'),
        },
        {
          path: 'fulltext-search',
          name: 'FulltextSearch',
          component: () => import('../views/FulltextSearch.vue'),
        }
      ]
    },
    {
      path: '/data-visualization',
      name: 'DataVisualization',
      redirect: '/data-visualization/raw-data',
      children: [
        {
          path: 'raw-data',
          name: 'RawData',
          component: () => import('../views/RawData.vue'),
        }
      ]
    },
    {
      path: '/storage-management',
      name: 'StorageManagement',
      redirect: '/storage-managemen/data-overview',
      children: [
        {
          path: 'data-overview',
          name: 'DataOverview',
          component: () => import('../views/DataOverview.vue'),
        },
        {
          path: 'data-export',
          name: 'StorageDataExport',
          component: () => import('../views/StorageDataExport.vue'),
        },
        {
          path: 'data-import',
          name: 'DataImport',
          component: () => import('../views/DataImport.vue'),
        },
        {
          path: 'data-delete',
          name: 'DataDelete',
          component: () => import('../views/DataDelete.vue'),
        }
      ]
    }
  ],
})

export default router
