<template>
  <el-dialog v-model="visible" title="数据源" width="800px" class="data-source-dialog" @update:modelValue="handleClose">
    <div class="dialog-content">
      <div class="selection-section">
        <!-- 国家/地区选择 -->
        <div class="selection-item">
          <h4>国家/地区</h4>
          <div class="country-buttons">
            <el-button
              v-for="country in countryOptions"
              :key="country.value"
              :type="selectedCountry == country.value ? 'primary' : 'default'"
              @click="selectCountry(country.value)"
              class="country-btn"
            >
              {{ country.label }}
            </el-button>
          </div>
        </div>

        <!-- 数据源选择 -->
        <div class="selection-item">
          <h4>数据源</h4>
          <div class="source-buttons">
            <el-button
              v-for="source in filteredDataSources"
              :key="source.id"
              :type="selectedSource?.id == source.id ? 'primary' : 'default'"
              @click="selectSource(source)"
              class="source-btn"
            >
              {{ source.name }}
            </el-button>
          </div>
        </div>

        <!-- 板块选择 -->
        <div class="selection-item" v-if="selectedSource">
          <h4>板块</h4>
          <div class="section-grid">
            <el-checkbox-group v-model="selectedSections">
              <div class="section-row">
                <el-checkbox 
                  v-for="section in availableSections"
                  :key="String(section.value)"
                  :label="String(section.value)"
                  class="section-checkbox"
                >
                  {{ section.label }}
                </el-checkbox>
              </div>
            </el-checkbox-group>
          </div>
        </div>
      </div>
    </div>
    
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="handleClose">取消</el-button>
        <el-button type="primary" @click="confirmDataSource">确定</el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, computed, watch, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import api from '@/utils/request'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['update:modelValue', 'confirm'])

// 响应式数据
const visible = ref(props.modelValue)
const selectedCountry = ref('')
const selectedSource = ref(null)
const selectedSections = ref([]) // 选中的板块

// 联动数据
const allCountriesData = ref([]) // 存储完整的国家数据（包含children）

// 国家选项
const countryOptions = ref([])

// 可用板块选项（动态获取）
const availableSections = ref([])

// 根据选中国家过滤数据源
const filteredDataSources = computed(() => {
  if (!selectedCountry.value) return []
  const countryData = allCountriesData.value.find(country => country.id == selectedCountry.value)
  return countryData ? countryData.children || [] : []
})

// 监听props变化
watch(() => props.modelValue, (newVal) => {
  visible.value = newVal
})

// 方法
const getCountryList = async () => {
  try {
    const res = await api({
      url: '/city/tree',
      method: 'get'
    })
    if (res.data.code === 200) {
      // 根据规范，从 res.data.data 路径获取数据
      allCountriesData.value = res.data.data || []
      
      // 将接口返回的数据格式转换为组件需要的格式
      countryOptions.value = allCountriesData.value.map(item => ({
        label: item.name,
        value: item.id
      }))
    }
  } catch (error) {
    ElMessage.error('获取国家地区列表失败')
  }
}

const selectCountry = (country) => {
  selectedCountry.value = country
  selectedSource.value = null // 重置数据源选择
  selectedSections.value = [] // 重置板块选择
  availableSections.value = [] // 重置板块选项
}

const selectSource = (source) => {
  selectedSource.value = source
  selectedSections.value = [] // 重置板块选择
  
  // 根据选中的数据源设置可用板块
  if (source && source.children) {
    availableSections.value = source.children.map(section => ({
      label: section.name,
      value: String(section.id) // 确保 ID为字符串格式，符合规范
    }))
  } else {
    availableSections.value = []
  }
}

const confirmDataSource = () => {
  if (!selectedSource.value) {
    ElMessage.warning('请先选择一个数据源')
    return
  }
  
  if (selectedSections.value.length === 0) {
    ElMessage.warning('请至少选择一个板块')
    return
  }

  // 构建选择结果
  const selectedSectionNames = selectedSections.value.map(sectionId => {
    const section = availableSections.value.find(s => String(s.value) === String(sectionId))
    return section ? section.label : sectionId
  })
  
  const result = {
    id: selectedSource.value.id,
    news: selectedSource.value.name,
    country: countryOptions.value.find(c => c.value === selectedCountry.value)?.label,
    countryId: selectedCountry.value,
    sections: selectedSectionNames,
    sectionIds: selectedSections.value.map(id => String(id)), // 确保传递的ID为字符串，符合规范
    url: `https://${selectedSource.value.name.toLowerCase()}.com`
  }
  
  emit('confirm', result)
  handleClose()
  ElMessage.success(`已选择 ${result.news}，板块：${selectedSectionNames.join('、')}`)
}

const handleClose = () => {
  emit('update:modelValue', false)
  // 重置选择状态
  selectedCountry.value = ''
  selectedSource.value = null
  selectedSections.value = []
  availableSections.value = []
}

// 生命周期
onMounted(() => {
  getCountryList()
})
</script>

<style scoped>
.data-source-dialog {
  .dialog-content {
    padding: 20px 0;
  }

  .selection-section {
    .selection-item {
      margin-bottom: 32px;
      
      h4 {
        margin: 0 0 16px 0;
        font-size: 16px;
        font-weight: 600;
        color: #303133;
      }
    }
  }
  
  .country-buttons {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    
    .country-btn {
      min-width: 80px;
      border-radius: 6px;
    }
  }
  
  .source-buttons {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    
    .source-btn {
      min-width: 100px;
      border-radius: 6px;
      display: flex;
      align-items: center;
      gap: 6px;
    }
  }
  
  .section-grid {
    .section-row {
      display: flex;
      gap: 24px;
      margin-bottom: 16px;
      flex-wrap: wrap;
      
      .section-checkbox {
        margin-right: 0;
        min-width: 120px;
      }
    }
  }
  
  .dialog-footer {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
  }
}

:deep(.el-checkbox__label) {
  font-size: 14px;
  color: #606266;
}

:deep(.el-checkbox.is-checked .el-checkbox__label) {
  color: #409eff;
}
</style>