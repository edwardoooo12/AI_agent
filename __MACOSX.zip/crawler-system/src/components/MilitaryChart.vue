<script setup>
import { ref, onMounted } from 'vue'

// 基础数据
const countries = ["M国", "日本", "韩国", "台湾地区"]
const categories = ["编制结构", "JS设施", "WQ装备"]

// KPI数据
const kpiData = ref({
  countries: 4,
  jqTotal: 2047,
  equipModels: 0,
  dailyDelta: 0
})

// 热力图数据
const heatValues = [
  [0,0,160],[0,1,180],[0,2,210],
  [1,0,140],[1,1,155],[1,2,190],
  [2,0,135],[2,1,172],[2,2,188],
  [3,0,150],[3,1,166],[3,2,201],
]

// 图表配置项
const chartOptions = ref({})

// 统计信息提示框状态
const showTooltip = ref(false)
const tooltipContent = ref('')
const tooltipPosition = ref({ x: 0, y: 0 })

// 显示统计信息提示框
const showStatTooltip = (event, type) => {
  let content = ''
  const stats = getStatsForType(type)
  
  content = `统计JQ数据 来源、分布、数据量

${stats.detail}

清风`
  
  tooltipContent.value = content
  tooltipPosition.value = {
    x: event.clientX + 10,
    y: event.clientY + 10
  }
  showTooltip.value = true
}

// 隐藏统计信息提示框
const hideStatTooltip = () => {
  showTooltip.value = false
}

// 获取统计信息
const getStatsForType = (type) => {
  switch(type) {
    case 'overview':
      return {
        detail: `数据覆盖：${countries.join('、')}\n总计条目：${kpiData.value.jqTotal}\n装备型号：进行中\n最新更新：实时同步`
      }
    default:
      return {
        detail: '数据正在加载中...'
      }
  }
}

// 初始化数据
const initData = () => {
  console.log('开始初始化数据')
  
  kpiData.value.countries = countries.length
  kpiData.value.jqTotal = heatValues.reduce((s, x) => s + x[2], 0)
  
  // 初始化图表配置
  initChartOptions()
}

// 初始化图表配置项
const initChartOptions = () => {
  console.log('初始化图表配置项')
  
  // 热力图配置
  chartOptions.value.heat = {
    tooltip: { 
      formatter: (p) => `${countries[p.data[0]]} × ${categories[p.data[1]]}: <b>${p.data[2]}</b>` 
    },
    grid: { 
      left: 80, 
      right: 80, 
      top: 40, 
      bottom: 60, 
      containLabel: true 
    },
    xAxis: { 
      type: 'category', 
      data: countries, 
      axisLabel: { 
        color: '#cfd4e3', 
        fontSize: 14,
        margin: 15
      },
      splitArea: { show: true },
      axisLine: { show: true, lineStyle: { color: '#444' } },
      axisTick: { show: false }
    },
    yAxis: { 
      type: 'category', 
      data: categories, 
      axisLabel: { 
        color: '#cfd4e3', 
        fontSize: 14,
        margin: 15
      },
      splitArea: { show: true },
      axisLine: { show: true, lineStyle: { color: '#444' } },
      axisTick: { show: false }
    },
    visualMap: { 
      min: 130, 
      max: 210, 
      calculable: true, 
      orient: 'vertical',
      right: 10,
      top: 'center',
      textStyle: { color: '#cfd4e3', fontSize: 12 },
      inRange: {
        color: ['#ffeaa7', '#fab1a0', '#e17055', '#d63031']
      },
      itemWidth: 15,
      itemHeight: 100
    },
    series: [{ 
      type: 'heatmap', 
      data: heatValues, 
      label: { 
        show: true, 
        color: '#fff', 
        fontSize: 16, 
        fontWeight: 'bold' 
      },
      itemStyle: {
        borderRadius: 4,
        borderWidth: 2,
        borderColor: 'rgba(255,255,255,0.1)'
      },
      emphasis: {
        itemStyle: {
          borderColor: '#fff',
          borderWidth: 2
        }
      }
    }]
  }
}

onMounted(() => {
  console.log('MilitaryChart 组件开始挂载')
  initData()
})
</script>

<template>
  <div class="military-dashboard">
    <!-- KPI 指标 -->
    <div class="kpi-row">
      <div class="kpi">
        <div class="label">覆盖国家/地区</div>
        <div class="value">{{ kpiData.countries }}</div>
        <div class="label">M国、日本、韩国、台湾地区</div>
      </div>
      <div class="kpi">
        <div class="label">JQ 条目数（编制/JS设施/WQ装备）</div>
        <div class="value">{{ kpiData.jqTotal.toLocaleString() }}</div>
        <div class="label">每类每国目标≥100</div>
      </div>
    </div>

    <!-- 热力图 -->
    <div class="chart-container">
      <div class="panel">
        <h3>国家 × 数据大类 采集量</h3>
        <div class="chart-wrapper">
          <v-chart 
            :option="chartOptions.heat" 
            style="width: 100%; height: 500px;" 
          />
        </div>
        <div class="legend">
          <span class="tag">编制结构</span>
          <span class="tag">JS设施</span>
          <span class="tag">WQ装备</span>
        </div>
      </div>
    </div>

    <!-- 统计信息提示框 -->
    <div 
      v-if="showTooltip"
      class="stat-tooltip"
      :style="{ left: tooltipPosition.x + 'px', top: tooltipPosition.y + 'px' }"
    >
      <div class="tooltip-content">
        {{ tooltipContent }}
      </div>
    </div>
  </div>
</template>

<style scoped>
.military-dashboard {
  padding: 20px;
  background: #1a1d2e;
  color: #e6e9f0;
  font-family: "微软雅黑", Arial, sans-serif;
  min-height: 100vh;
}

/* 页面标题 */
.title {
  font-size: 24px;
  font-weight: bold;
  text-align: center;
  margin-bottom: 30px;
  color: #4fc3f7;
  background: rgba(79, 195, 247, 0.1);
  padding: 15px;
  border-radius: 8px;
}

/* KPI 指标行 */
.kpi-row {
  display: flex;
  gap: 20px;
  margin-bottom: 30px;
  justify-content: center;
}

.kpi {
  flex: 0 0 300px;
  background: rgba(30, 35, 54, 0.8);
  padding: 20px;
  border-radius: 8px;
  text-align: center;
  border: 1px solid rgba(79, 195, 247, 0.3);
}

.kpi .label {
  font-size: 14px;
  margin-bottom: 8px;
  color: #a5b3c7;
}

.kpi .value {
  font-size: 32px;
  font-weight: bold;
  color: #4fc3f7;
  margin: 10px 0;
}

/* 图表容器 */
.chart-container {
  display: flex;
  justify-content: center;
  margin-bottom: 30px;
}

/* 面板 */
.panel {
  background: rgba(30, 35, 54, 0.8);
  border-radius: 8px;
  padding: 20px;
  border: 1px solid rgba(79, 195, 247, 0.3);
  width: 100%;
  max-width: 1200px;
  min-height: 650px;
}

.panel h3 {
  margin: 0 0 20px 0;
  font-size: 16px;
  color: #4fc3f7;
  border-bottom: 1px solid rgba(79, 195, 247, 0.3);
  padding-bottom: 8px;
  text-align: center;
}

/* 图表包装器 */
.chart-wrapper {
  width: 100%;
  height: 500px;
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 20px 0;
}

/* 图例 */
.legend {
  margin-top: 10px;
  text-align: center;
}

.tag {
  display: inline-block;
  background: rgba(79, 195, 247, 0.2);
  color: #4fc3f7;
  padding: 4px 12px;
  margin: 0 5px;
  border-radius: 15px;
  font-size: 12px;
  border: 1px solid rgba(79, 195, 247, 0.4);
}

/* 统计信息提示框 */
.stat-tooltip {
  position: fixed;
  z-index: 1000;
  background: rgba(255, 193, 7, 0.95);
  color: #333;
  padding: 12px 16px;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  max-width: 300px;
  font-size: 14px;
  line-height: 1.5;
  border: 2px solid #ffc107;
  backdrop-filter: blur(5px);
}

.tooltip-content {
  white-space: pre-line;
  font-weight: 500;
}

/* 自定义滚动条样式 */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 4px;
}

::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: #a8a8a8;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .kpi-row {
    flex-direction: column;
    align-items: center;
  }
  
  .kpi {
    flex: none;
    width: 100%;
    max-width: 300px;
  }
  
  .military-dashboard {
    padding: 10px;
  }
  
  .title {
    font-size: 18px;
    padding: 10px;
  }
}
</style>