<template>
  <el-dialog
    v-model="visible"
    :title="dialogTitle"
    width="600"
    @update:modelValue="handleClose"
  >
    <el-form label-width="150px">
      <el-form-item label="国家/地区">
        <el-select
          v-model="state.formData.city"
          placeholder="请选择国家/地区"
          filterable
          style="width: 100%"
        >
          <el-option
            v-for="opt in cityOptions"
            :key="opt.value"
            :label="opt.label"
            :value="opt.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="数据源">
        <el-input v-model="state.formData.news" />
      </el-form-item>
      <el-form-item label="网址">
        <el-input v-model="state.formData.url" />
      </el-form-item>
      <el-form-item label="类别">
        <el-select
          v-model="state.formData.type"
          placeholder="请选择类别"
          filterable
          style="width: 100%"
        >
          <el-option
            v-for="opt in typeOptions"
            :key="opt.value"
            :label="opt.label"
            :value="opt.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="版面/账号/关键字">
        <el-select
          v-model="state.formData.windowType"
          placeholder="请选择版面/账号/关键字"
          filterable
          style="width: 100%"
        >
          <el-option
            v-for="opt in layoutOptions"
            :key="opt.value"
            :label="opt.label"
            :value="+opt.value"
          />
        </el-select>
        <el-input
          v-model="state.formData.layoutName"
          placeholder="请输入版面/账号/关键字"
          style="margin-top: 8px"
        />
      </el-form-item>
      <el-form-item label="数据爬取方式">
        <el-input v-model="state.formData.crawlingMethod" />
      </el-form-item>
      <el-form-item label="存储位置" v-if="storageLocation">
        <span style="color: #606266; font-size: 14px">{{
          storageLocation
        }}</span>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="handleClose">取消</el-button>
      <el-button type="primary" @click="handleSave">保存</el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, watch, computed, reactive } from "vue";

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  formData: {
    type: Object,
    default: () => ({}),
  },
  cityOptions: {
    type: Array,
    default: () => [],
  },
  typeOptions: {
    type: Array,
    default: () => [],
  },
  layoutOptions: {
    type: Array,
    default: () => [
      { label: "版面", value: "1" },
      { label: "账号", value: "2" },
      { label: "关键字", value: "3" },
    ],
  },
});

const emit = defineEmits(["update:modelValue", "save"]);

const visible = ref(props.modelValue);
const state = reactive({
  formData: { ...props.formData },
});

// 动态标题
const dialogTitle = computed(() => {
  return props.formData?.id ? "编辑数据源" : "新建数据源";
});

// 存储位置计算属性
const storageLocation = computed(() => {
  const country = state.formData?.city;
  const newsSource = state.formData?.news;
  const windowType = state.formData?.windowType;
  const layout = state.formData?.layoutName;

  // 根据windowType获取对应的label
  const getWindowTypeLabel = (value) => {
    const option = props.layoutOptions.find((opt) => opt.value == value);
    return option ? option.label : "";
  };

  // 只有当所有必要字段都有值时才显示存储位置
  if (country && newsSource && windowType && layout) {
    const windowTypeLabel = getWindowTypeLabel(windowType);

    return `项目目录/data/${country}/${newsSource}/${windowTypeLabel}/${layout}/date`;
  }

  return "";
});

watch(
  () => props.modelValue,
  (newVal) => {
    visible.value = newVal;
  }
);

const handleClose = () => {
  emit("update:modelValue", false);
};

const handleSave = () => {
  console.log(state.formData);
  emit("save", state.formData);
};
</script>

<style scoped></style>
