<script setup>
import { defineProps, defineEmits, ref, onMounted, watch, computed } from 'vue'
import { getMilitaryChart, getMilitaryEquipmentList, getMilitaryFacilityList, getCountryEquipmentChart } from '@/api/military'
import { usePagination } from '@/hooks/usePagination'

const props = defineProps({
  visible: {
    type: Boolean,
    required: true
  }
})

const emit = defineEmits(['update:visible', 'confirm', 'cancel'])

// ========== 去除默认示例数据，全部由接口填充 ==========
// 预置空集合，避免模板报错
const equipCategories = computed(() => {
  const categories = [...new Set(eqList.value.map(item => item.equipmentCategory).filter(Boolean))]
  return categories
})
const models = []

// KPI 数据
const jqTotal = ref(0)
const kpiCountries = ref(0)
// 已移除：装备台账条目、当日新增/新鲜度
const countriesLabel = ref('') 

// 图表选项初始为空，等待接口填充
const heatOption = ref({ series: [] })



const treeOption = ref({ series: [] })

const sankeyOption = ref({
  tooltip: { trigger: 'item' },
  series: [{
    type: 'sankey',
    data: [],
    links: [],
    emphasis: { focus: 'adjacency' },
    lineStyle: { opacity: 0.4 },
    label: { color: '#e6e9f0' }
  }]
})

const barOption = ref({ series: [] })
// 装备清单（分页）
const eqParams = ref({ country: "", militaryStructureId: "" })
const equipmentPagination = usePagination(getMilitaryEquipmentList, eqParams.value)

// 设施台账（分页）
const facilityParams = ref({ country: "" })
const facilityPagination = usePagination(getMilitaryFacilityList, facilityParams.value)

// 为了保持模板的兼容性，创建计算属性
const eqList = computed(() => equipmentPagination.state.list)
const eqLoading = computed(() => equipmentPagination.state.loading)
const eqPageNum = computed(() => equipmentPagination.state.pageNum)
const eqPageSize = computed(() => equipmentPagination.state.pageSize)
const eqTotal = computed(() => equipmentPagination.state.total)

const facilityList = computed(() => facilityPagination.state.list)
const facilityLoading = computed(() => facilityPagination.state.loading)
const facilityPageNum = computed(() => facilityPagination.state.pageNum)
const facilityPageSize = computed(() => facilityPagination.state.pageSize)
const facilityTotal = computed(() => facilityPagination.state.total)

const radarDims = [
  { key: 'rangeKm', name: '航程(km)', max: 2000 },
  { key: 'speedKmH', name: '速度(km/h)', max: 1000 },
  { key: 'payloadKg', name: '载荷(kg)', max: 7000 },
  { key: 'bandwidthMbps', name: '带宽(Mbps)', max: 1200 },
  { key: 'enduranceH', name: '续航(h)', max: 20 },
  { key: 'detectionKm', name: '探测距(km)', max: 400 },
]

const radarOption = ref({ series: [] })

const graphOption = ref({ series: [] })

// 分类筛选和表格
const activeCat = ref('全部')
const selectedModelId = ref(null)
const sankeyTitle = ref('单位—装备 配备关系')
const radarTitle = ref('战技性能雷达图')
const graphTitle = ref('装配/挂载 关系图')
const barTitle = ref('装备分布（接口数据）')

// ========= 接口数据加载 =========
const loadingRemote = ref(false)
const sankeyDataRef = ref({ nodes: [], links: [] })
const chart3Ref = ref(null)

async function loadMilitaryChart() {
  try {
    loadingRemote.value = true
    const { code, data } = await getMilitaryChart()
    if (code === 200 && data) {
      // 1) 热力图（国家 × 大类）
      const remoteCountries = Array.isArray(data.chart1?.countries) ? data.chart1.countries : []
      if (remoteCountries.length) {
        // 使用后端国家列表
        // 固定 y 轴顺序：与后端 key 对齐
        const remoteCategories = ['编制结构', 'JS设备', 'WQ装备']
        // KPI 展示的国家名称列表
        countriesLabel.value = remoteCountries.join('、')

        // 生成 heatValues: [xIndex, yIndex, value]
        const heat = []
        for (let i = 0; i < remoteCountries.length; i++) {
          const c = remoteCountries[i]
          const cd = data.chart1?.countryDataCount?.[c] || {}
          for (let j = 0; j < remoteCategories.length; j++) {
            const cat = remoteCategories[j]
            const val = Number(cd[cat] || 0)
            heat.push([i, j, val])
          }
        }

        // 更新 KPI
        jqTotal.value = Number(data.chart1?.jqCount || 0)
        kpiCountries.value = remoteCountries.length

        // 覆盖本地 countries/categories 以驱动图例
        // 注意：这些常量仅在 option 中使用，直接覆盖 option 即可
        heatOption.value = {
          tooltip: { formatter: (p) => `${remoteCountries[p.data[0]]} × ${remoteCategories[p.data[1]]}: <b>${p.data[2]}</b>` },
          grid: { left: 70, right: 20, top: 30, bottom: 40 },
          xAxis: { type: 'category', data: remoteCountries, axisLabel: { color: '#cfd4e3' } },
          yAxis: { type: 'category', data: remoteCategories, axisLabel: { color: '#cfd4e3' } },
          visualMap: { min: 0, max: Math.max(...heat.map(h => h[2] || 0), 10), calculable: true, left: 'right', top: 'middle', textStyle: { color: '#cfd4e3' } },
          series: [{ type: 'heatmap', data: heat, label: { show: true, color: '#fff' } }]
        }

        // 2) 柱状图（各类聚合）
        // 从 countryDataCount 汇总三类的总量
        const sumByClass = { '编制结构': 0, 'JS设备': 0, 'WQ装备': 0 }
        for (const c of remoteCountries) {
          const cd2 = data.chart1?.countryDataCount?.[c] || {}
          sumByClass['编制结构'] += Number(cd2['编制结构'] || 0)
          sumByClass['JS设备'] += Number(cd2['JS设备'] || 0)
          sumByClass['WQ装备'] += Number(cd2['WQ装备'] || 0)
        }
        barOption.value = {
          tooltip: { trigger: 'axis' },
          grid: { left: 60, right: 20, top: 20, bottom: 40 },
          xAxis: { type: 'category', data: ['编制结构', 'JS设备', 'WQ装备'], axisLabel: { color: '#cfd4e3' } },
          yAxis: { type: 'value', axisLabel: { color: '#cfd4e3' } },
          series: [{ type: 'bar', data: [sumByClass['编制结构'], sumByClass['JS设备'], sumByClass['WQ装备']] }]
        }
        barTitle.value = '装备分布（全部国家 × 3 大类）'
      }

      // 3) 树图（优先展示中国，否则展示第一个）
      const treeList = Array.isArray(data.chart2) ? data.chart2 : []
      if (treeList.length) {
        const preferred = treeList.find((n) => n?.name === '中国') || treeList[0]
        treeOption.value = {
          tooltip: { trigger: 'item', triggerOn: 'mousemove' },
          series: [{
            type: 'tree',
            data: [preferred],
            top: '1%', left: '5%', bottom: '1%', right: '20%',
            symbolSize: 10,
            label: { color: '#e6e9f0', fontSize: 12, position: 'left', verticalAlign: 'middle', align: 'right' },
            leaves: { label: { position: 'right', align: 'left' } },
            expandAndCollapse: true,
            animationDuration: 300,
            animationDurationUpdate: 300
          }]
        }
      }

      // 4) 记录 chart3，桑基图由树图点击触发按 id 渲染
      chart3Ref.value = data.chart3 || null
      sankeyTitle.value = '单位—装备 配备关系'
      sankeyDataRef.value = { nodes: [], links: [] }
      sankeyOption.value = { series: [] }
    }
  } catch (e) {
    // 静默失败，保留本地演示数据
    // console.error('loadMilitaryChart error', e)
  } finally {
    loadingRemote.value = false
  }
}

// 加载装备清单（分页）
async function loadMilitaryEquipmentList() {
  await equipmentPagination.loadList()
}

// 加载设施台账（分页）
async function loadMilitaryFacilityList() {
  await facilityPagination.loadList()
}

const handleEqPageChange = (page) => {
  equipmentPagination.handlePageChange(page)
}

const handleEqSizeChange = (size) => {
  equipmentPagination.handleSizeChange(size)
}

// 设施台账分页事件
const handleFacilityPageChange = (page) => {
  facilityPagination.handlePageChange(page)
}

const handleFacilitySizeChange = (size) => {
  facilityPagination.handleSizeChange(size)
}

// 桑基图构建（与1.html完全一致）
function buildSankey(unitName) {
  const arr = unitEquipMap[unitName] || []
  const nodes = [{ name: unitName }, ...arr.map(a => ({ name: a.equip }))]
  const links = arr.map(a => ({ source: unitName, target: a.equip, value: a.count }))
  return { nodes, links }
}

function renderSankey() {
  const { nodes, links } = sankeyDataRef.value || { nodes: [], links: [] }
  if (nodes.length && links.length) {
    sankeyOption.value = {
      tooltip: { trigger: 'item' },
      series: [{
        type: 'sankey',
        data: nodes,
        links: links,
        emphasis: { focus: 'adjacency' },
        lineStyle: { opacity: 0.4 },
        label: { color: '#e6e9f0' }
      }]
    }
  } else {
    sankeyOption.value = { series: [] }
  }
}

// 柱状图数据（与1.html完全一致）
function getBarSeriesData(country) {
  const source = country ? equipmentData.filter(d => d.country === country) : equipmentData
  return equipmentClasses.map(cls => source.filter(d => d.class === cls).reduce((s, r) => s + r.count, 0))
}

let selectedCountry = null
function renderBar() {
  // 由接口 loadMilitaryChart 内部直接设置 barOption
}

// 筛选模型
function filteredModels() {
  return activeCat.value === '全部' ? models : models.filter(m => m.category === activeCat.value)
}

// 雷达图渲染
function renderRadar(empty = false) {
  console.log('renderRadar called:', { empty, selectedModelId: selectedModelId.value, eqListLength: eqList.value.length })
  
  // 基础雷达图配置
  const baseConfig = {
    tooltip: {
      trigger: 'item'
    },
    radar: { 
      indicator: radarDims.map(d => ({ name: d.name, max: d.max })), 
      textStyle: { color: '#cfd4e3' },
      splitArea: {
        areaStyle: {
          color: ['rgba(250,250,250,0.1)', 'rgba(200,200,200,0.1)']
        }
      },
      splitLine: {
        lineStyle: {
          color: '#cfd4e3'
        }
      }
    }
  }

  if (empty || !selectedModelId.value) {
    radarTitle.value = '战技性能雷达图（请选择装备）'
    const emptyData = radarDims.map(() => 0)
    console.log('Empty radar data:', emptyData)
    radarOption.value = {
      ...baseConfig,
      series: [{
        type: 'radar',
        data: [{
          value: emptyData,
          name: '请选择装备'
        }],
        itemStyle: {
          color: '#5470c6'
        },
        areaStyle: {
          color: 'rgba(84, 112, 198, 0.2)'
        }
      }]
    }
    return
  }
  
  // 从装备清单中查找选中的装备
  const equipment = eqList.value.find(x => x.equipmentId === selectedModelId.value)
  console.log('Found equipment:', equipment)
  if (!equipment) {
    radarTitle.value = '战技性能雷达图（装备未找到）'
    const emptyData = radarDims.map(() => 0)
    radarOption.value = {
      ...baseConfig,
      series: [{
        type: 'radar',
        data: [{
          value: emptyData,
          name: '装备未找到'
        }],
        itemStyle: {
          color: '#5470c6'
        },
        areaStyle: {
          color: 'rgba(84, 112, 198, 0.2)'
        }
      }]
    }
    return
  }
  
  radarTitle.value = `战技性能雷达图（${equipment.equipmentName} · ${equipment.model}）`
  
  // 从装备数据中提取性能指标
  const vals = radarDims.map(d => {
    const value = equipment[d.key] || 0
    return Math.max(0, Number(value))
  })
  
  console.log('Radar values:', vals)
  console.log('Final radar option:', {
    ...baseConfig,
    series: [{
      type: 'radar',
      data: [{
        value: vals,
        name: equipment.model
      }]
    }]
  })
  
  radarOption.value = {
    ...baseConfig,
    series: [{
      type: 'radar',
      data: [{
        value: vals,
        name: equipment.model
      }],
      itemStyle: {
        color: '#5470c6'
      },
      areaStyle: {
        color: 'rgba(84, 112, 198, 0.2)'
      }
    }]
  }
}

// 关系图渲染（与1.html完全一致）
function renderGraph(empty = false) {
  if (empty || !selectedModelId.value) {
    graphTitle.value = '装配/挂载 关系图（集成型装备展开）'
    graphOption.value = {
      tooltip: { formatter: (p) => p.dataType === 'edge' ? '装配关系' : p.data.name },
      series: []
    }
    return
  }
  const m = models.find(x => x.id === selectedModelId.value)
  const isIntegrated = m.integrated && (m.mounts?.length > 0)
  graphTitle.value = isIntegrated
    ? `装配/挂载 关系图（${m.name} · ${m.model}）`
    : `装配/挂载 关系图（${m.name} · ${m.model}：非集成）`

  const nodes = [{ id: m.id, name: `${m.name}\n(${m.model})`, category: m.category, symbolSize: 80 }]
  const links = []
  if (isIntegrated) {
    for (const c of m.mounts) {
      nodes.push({ id: c.id, name: `${c.name}`, category: c.category, symbolSize: 50 })
      links.push({ source: m.id, target: c.id, value: '装配' })
    }
  }
  graphOption.value = {
    tooltip: { formatter: (p) => p.dataType === 'edge' ? '装配关系' : p.data.name },
    series: [{
      type: 'graph',
      layout: 'force',
      roam: true,
      label: { show: true, color: '#e6e9f0' },
      force: { repulsion: 2000, edgeLength: 120 },
      data: nodes,
      links: links,
      lineStyle: { opacity: 0.6 }
    }]
  }
}

// 加载指定国家的装备统计图表
async function loadCountryEquipmentChart(country) {
  try {
    const { code, data } = await getCountryEquipmentChart(country)
    if (code === 200 && data) {
      // 更新柱状图显示该国家的装备分布
      if (Array.isArray(data)) {
        // 假设返回格式为 [{ category: '编制结构', count: 100 }, ...]
        const categories = ['编制结构', 'JS设备', 'WQ装备']
        const counts = categories.map(cat => {
          const item = data.find(d => d.name === cat)
          return item ? Number(item.count || 0) : 0
        })

        barOption.value = {
          tooltip: { trigger: 'axis' },
          grid: { left: 60, right: 20, top: 20, bottom: 40 },
          xAxis: { type: 'category', data: categories, axisLabel: { color: '#cfd4e3' } },
          yAxis: { type: 'value', axisLabel: { color: '#cfd4e3' } },
          series: [{ type: 'bar', data: counts }]
        }
        barTitle.value = `装备分布（${country}）`
      }
    }
  } catch (e) {
    console.error('加载国家装备统计失败:', e)
  }
}

// 事件处理
const handleTreeClick = (params) => {
  const id = params?.data?.id ?? params?.id
  const country = params?.data?.country ?? params?.country
  if (!id || !chart3Ref.value) return

  // 更新装备清单参数并重新加载
  equipmentPagination.updateParams({
    country: country ,
    militaryStructureId: id
  })

  // chart3 可能是 [{ id, name, children:[{name,count}]}] 或 { nodes, links }
  let nodes = []
  let links = []

  if (Array.isArray(chart3Ref.value)) {
    const target = chart3Ref.value.find(x => x?.id === id)
    if (target && Array.isArray(target.children)) {
      const unitName = target.name || `单位${id}`
      nodes = [{ name: unitName }, ...target.children.map(ch => ({ name: ch.name }))]
      links = target.children.map(ch => ({ source: unitName, target: ch.name, value: Number(ch.count || 0) }))
      sankeyTitle.value = `单位—装备 配备关系（${unitName}）`
    }
  } else if (chart3Ref.value?.nodes && chart3Ref.value?.links) {
    // 如果是通用 nodes/links 结构，可按 id 过滤（需要数据包含单位信息）
    const unitNode = chart3Ref.value.nodes.find(n => n?.id === id || n?.unitId === id)
    if (unitNode) {
      const unitName = unitNode.name || `单位${id}`
      const outgoing = chart3Ref.value.links.filter(l => l.source === unitNode.name || l.sourceId === id)
      const targetNames = Array.from(new Set(outgoing.map(l => l.target)))
      nodes = [unitNode, ...chart3Ref.value.nodes.filter(n => targetNames.includes(n.name))]
      links = outgoing
      sankeyTitle.value = `单位—装备 配备关系（${unitName}）`
    }
  }

  sankeyDataRef.value = { nodes, links }
  renderSankey()
}

const handleHeatClick = (params) => {
  // 点击热力图时，根据国家获取装备统计图表和设施台账
  if (params && params.data && params.data[0] !== undefined) {
    const countryIndex = params.data[0]
    const countries = heatOption.value?.xAxis?.data || []
    const countryName = countries[countryIndex]
    if (countryName) {
      // 更新国家装备统计图表
      loadCountryEquipmentChart(countryName)
      
      // 更新设施台账参数并重新加载
      facilityPagination.updateParams({
        country: countryName
      })
    }
  }
}

const handleCategoryClick = (cat) => {
  activeCat.value = cat
  // 自动选择第一项装备
  const filteredList = eqList.value.filter(item => 
    cat === '全部' || item.equipmentCategory === cat
  )
  if (filteredList.length && !selectedModelId.value) {
    selectedModelId.value = filteredList[0].equipmentId
    renderRadar()
    renderGraph()
  }
  if (!filteredList.length) {
    selectedModelId.value = null
    renderRadar(true)
    renderGraph(true)
  }
}

const handleModelClick = (modelId) => {
  selectedModelId.value = modelId
  renderRadar()
  renderGraph()
}

// 确认按钮处理
const handleConfirm = () => {
  emit('confirm')
  emit('update:visible', false)
}

// 取消按钮处理
const handleCancel = () => {
  emit('cancel')
  emit('update:visible', false)
}

// 监听装备列表变化，自动选择第一个装备
watch(eqList, (newList, oldList) => {
  if (newList.length > 0) {
    // 如果当前选中的装备不在新列表中，或者没有选中任何装备，则选择第一个
    const currentSelected = selectedModelId.value
    const isCurrentSelectedInList = newList.some(item => item.equipmentId === currentSelected)
    
    if (!currentSelected || !isCurrentSelectedInList) {
      selectedModelId.value = newList[0].equipmentId
      console.log('Auto-selected first equipment:', newList[0])
      renderRadar()
      renderGraph()
    }
  } else if (newList.length === 0) {
    // 如果列表为空，清空选中状态
    selectedModelId.value = null
    renderRadar(true)
    renderGraph(true)
  }
}, { immediate: false })

onMounted(async () => {
  // 仅加载远端数据，移除所有默认本地数据
  await loadMilitaryChart()
  await equipmentPagination.loadList()
  await facilityPagination.loadList()
  
  // 设置默认选中的装备（第一个装备）
  if (eqList.value.length > 0) {
    selectedModelId.value = eqList.value[0].equipmentId
    console.log('Default selected equipment:', eqList.value[0])
  }
  
  renderSankey() // 保持空
  renderRadar() // 初始化雷达图
  renderGraph() // 初始化关系图
})
</script>

<template>
  <el-dialog :model-value="visible" @update:modelValue="val => emit('update:visible', val)"
    title="JQ/装备数据 可视化示例（扩展：WQ装备属性/性能/关联）" :fullscreen="true" :close-on-click-modal="false" :show-close="false"
    class="jq-dialog">
    <template #header>
      <div class="dlg-header">
        <div class="dlg-title">JQ/装备数据 可视化示例（扩展：WQ装备属性/性能/关联）</div>
        <span class="dlg-close" @click="handleCancel">×</span>
      </div>
    </template>
    <div class="wrap">
      <div class="title">JQ 数据与装备数据 · 大屏示例（已扩展：WQ装备基本属性 / 战技性能 / 装配关系）</div>

      <!-- KPI -->
      <div class="kpi full">
        <div class="label">覆盖国家/地区</div>
        <div class="value">{{ kpiCountries }}</div>
        <div class="label">{{ countriesLabel }}</div>
      </div>
      <div class="kpi full">
        <div class="label">JQ 条目数（编制/JS设施/WQ装备）</div>
        <div class="value">{{ jqTotal.toLocaleString() }}</div>
      </div>

      <!-- 矩阵热力 -->
      <div class="panel" style="grid-column: span 12;">
        <h3>国家 × 数据大类 采集量</h3>
        <div class="chart">
          <v-chart :option="heatOption" style="height: 300px;" @click="handleHeatClick" autoresize />
        </div>
        <div class="legend">
          <span class="tag">编制结构</span>
          <span class="tag">JS设施</span>
          <span class="tag">WQ装备</span>
        </div>
      </div>



      <!-- 编制树 -->
      <div class="panel">
        <h3>编制结构（树状）</h3>
        <div class="chart">
          <v-chart :option="treeOption" style="height: 300px;" @click="handleTreeClick" autoresize />
        </div>
      </div>

      <!-- 单位—装备（配备） -->
      <div class="panel">
        <h3>{{ sankeyTitle }}</h3>
        <div class="chart">
          <v-chart :option="sankeyOption" style="height: 300px; " autoresize />
        </div>
      </div>


      <div class="panel full-width">
        <h3>设施台账 (类型/单位/位置/描述)</h3>
        <div class="table-wrap">
          <table class="model-table">
            <thead>
              <tr>
                <th style="width:20%">设施名称</th>
                <th style="width:18%">类型</th>
                <th style="width:16%">所属单位</th>
                <th style="width:12%">地里位置</th>
                <th style="width:34%">描述</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in facilityList" :key="item.id || item.name">
                <td><strong>{{ item.name || item.facilityName || '-' }}</strong></td>
                <td>{{ item.type || item.facilityType || '-' }}</td>
                <td><span class="badge">{{ item.belongUnit || item.unit || '-' }}</span></td>
                <td>{{ item.location || item.position || '-' }}</td>
                <td class="muted">{{ item.desc || item.description || '-' }}</td>
              </tr>
              <tr v-if="!facilityLoading && facilityList.length === 0">
                <td colspan="5" class="muted" style="text-align: center;">暂无数据</td>
              </tr>
              <tr v-if="facilityLoading">
                <td colspan="5" class="muted" style="text-align: center;">加载中...</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div style="display:flex; justify-content:center; padding: 0 8px 12px;">
          <el-pagination
            background
            layout="prev, pager, next, sizes, total"
            :page-sizes="[10,20,50,100]"
            :page-size="facilityPageSize"
            :current-page="facilityPageNum"
            :total="facilityTotal"
            @current-change="handleFacilityPageChange"
            @size-change="handleFacilitySizeChange"
          />
        </div>
      </div>


      <!-- WQ 装备分类 × 型号清单 -->
      <div class="panel full-width">
        <h3>WQ 装备台账（基本属性 / 型号 / 分类 / 描述）</h3>
        <div class="toolbar">
          <span v-for="cat in ['全部', ...equipCategories]" :key="cat" class="pill" :class="{ active: cat === activeCat }"
            @click="handleCategoryClick(cat)">
            {{ cat }}
          </span>
        </div>


        <div class="table-wrap">
          <table class="model-table">
            <thead>
              <tr>
                <th style="width:20%">装备名称</th>
                <th style="width:18%">型号</th>
                <th style="width:16%">所属分类</th>
                <th style="width:12%">是否集成</th>
                <th style="width:34%">描述</th>
              </tr>
            </thead>
            <tbody>
              <tr 
                v-for="item in eqList" 
                :key="item.equipmentId || item.model"
                :class="{ selected: item.equipmentId === selectedModelId }"
                @click="handleModelClick(item.equipmentId)"
              >
                <td><strong>{{ item.equipmentName || '-' }}</strong></td>
                <td>{{ item.model || '-' }}</td>
                <td><span class="badge">{{ item.equipmentCategory || '-' }}</span></td>
                <td>
                  <span v-if="item.isIntegrated">是</span>
                  <span v-else class="muted">否</span>
                </td>
                <td class="muted">{{ item.description || '-' }}</td>
              </tr>
              <tr v-if="!eqLoading && eqList.length === 0">
                <td colspan="5" class="muted" style="text-align: center;">暂无数据</td>
              </tr>
              <tr v-if="eqLoading">
                <td colspan="5" class="muted">加载中...</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div style="display:flex; justify-content:center; padding: 0 8px 12px;">
          <el-pagination
            background
            layout="prev, pager, next, sizes, total"
            :page-sizes="[10,20,50,100]"
            :page-size="eqPageSize"
            :current-page="eqPageNum"
            :total="eqTotal"
            @current-change="handleEqPageChange"
            @size-change="handleEqSizeChange"
          />
        </div>
      </div>

      <!-- 战技性能雷达 -->
      <div class="panel">
        <h3>{{ radarTitle }}</h3>
        <div class="chart">
          <v-chart :option="radarOption" style="height: 300px; width: 100%" autoresize />
        </div>
        <div class="legend">
          <span class="tag">示例维度：航程/速度/载荷/带宽/续航/探测距</span>
        </div>
      </div>

      <!-- 装配/挂载 关联关系图 -->
      <div class="panel">
        <h3>{{ graphTitle }}</h3>
        <div class="chart">
          <v-chart :option="graphOption" style="height: 300px;" autoresize />
        </div>
        <div class="legend">
          <span class="tag">中心：集成装备</span>
          <span class="tag">节点：挂载设备</span>
          <span class="tag">连线：装配关系</span>
        </div>
      </div>

      <!-- 装备分布 -->
      <div class="panel full-width">
        <h3>{{ barTitle }}</h3>
        <div class="chart large">
          <v-chart :option="barOption" style="height: 360px" autoresize />
        </div>
      </div>
    </div>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="handleCancel">关闭</el-button>
        <el-button type="primary" @click="handleConfirm">确认</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<style scoped>
.jq-dialog :deep(.el-dialog__body) {
  padding: 0;
  background: #0f1221;
}

.jq-dialog :deep(.el-dialog__header) {
  background: #0f1221;
  border-bottom: 1px solid #1a1f35;
}

.jq-dialog :deep(.el-dialog__title) {
  color: #e6e9f0;
}

.dlg-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.dlg-title {
  font-weight: 600;
}

.dlg-close {
  cursor: pointer;
  color: #9aa3b2;
  font-size: 20px;
  line-height: 1;
  padding: 4px 8px;
  border-radius: 6px;
}

.dlg-close:hover {
  background: #1a1f35;
  color: #e6e9f0;
}

.jq-dialog :deep(.el-dialog__footer) {
  background: #0f1221;
  border-top: 1px solid #1a1f35;
}

.wrap {
  padding: 16px;
  display: grid;
  gap: 16px;
  grid-template-columns: repeat(12, 1fr);
  background: #0f1221;
  color: #e6e9f0;
  font-family: ui-sans-serif, system-ui, "Segoe UI", Roboto;
}

.title {
  grid-column: 1/-1;
  font-size: 20px;
  font-weight: 700;
  color: #e6e9f0;
}

.kpi {
  grid-column: span 3;
  background: #171a2b;
  border-radius: 14px;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.kpi.full {
  grid-column: span 6;
}

.kpi .label {
  font-size: 12px;
  color: #98a2b3;
}

.kpi .value {
  font-size: 28px;
  font-weight: 800;
  color: #e6e9f0;
}

.panel {
  grid-column: span 6;
  background: #171a2b;
  border-radius: 14px;
  padding: 12px 12px 0;
  display: flex;
  flex-direction: column;
  min-height: 360px;
}

.panel.full-width {
  grid-column: span 12;
}

.panel h3 {
  margin: 6px 8px 0 8px;
  font-size: 14px;
  color: #98a2b3;
  font-weight: 600;
}

.chart {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 8px;
}

.chart.large {
  min-height: 360px;
}

.legend {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  padding: 0 8px 12px;
}

.tag {
  padding: 4px 8px;
  border-radius: 999px;
  background: #21253b;
  color: #cfd4e3;
  font-size: 12px;
  cursor: default;
}

.toolbar {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  padding: 8px;
}

.pill {
  padding: 6px 10px;
  border-radius: 999px;
  background: #21253b;
  color: #cfd4e3;
  font-size: 12px;
  cursor: pointer;
  border: 1px solid transparent;
}

.pill.active {
  border-color: #3b82f6;
  color: #fff;
}

.table-wrap {
  overflow: auto;
  padding: 0 8px 12px;
}

.model-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0 8px;
}

.model-table th,
.model-table td {
  padding: 10px 12px;
  text-align: left;
  font-size: 13px;
}

.model-table thead th {
  color: #cfd4e3;
  font-weight: 600;
}

.model-table tbody tr {
  background: #1d2136;
  cursor: pointer;
}

.model-table tbody tr:hover {
  outline: 1px solid #2a3155;
}

.model-table tbody tr.selected {
  outline: 1px solid #3b82f6;
}

.badge {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 999px;
  background: #26304e;
  color: #d7def4;
  font-size: 12px;
}

.muted {
  color: #9aa3b2;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}

@media (max-width: 1200px) {
  .panel {
    grid-column: span 12;
  }

  .kpi {
    grid-column: span 6;
  }
}

@media (max-width: 640px) {
  .kpi {
    grid-column: span 12;
  }
}
</style>
