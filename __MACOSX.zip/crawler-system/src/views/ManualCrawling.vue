<template>
  <div class="card-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>手动爬取测试</span>
        </div>
      </template>

      <div class="form-container">
        <!-- 选择数据源 -->
        <div class="form-section with-background">
          <div class="form-item">
            <label class="form-label">数据源</label>
            <div class="form-content">
              <span
                v-if="selectedDataSource"
                class="selected-source"
                @click="showDataSourceDialog = true"
              >
                已选择：{{ selectedDataSource.news }}
                <span class="selected-sections"
                  >（{{ selectedDataSource.sections?.join("、") }}）</span
                >
              </span>
              <div v-else @click="showDataSourceDialog = true">
                请选择数据源
              </div>
            </div>
          </div>
        </div>

        <!-- 选择日期范围 -->
        <div class="form-section with-background">
          <div class="form-item">
            <label class="form-label">时间范围</label>
            <div class="form-content">
              <el-date-picker
                v-model="dateRange"
                type="daterange"
                range-separator="-"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                style="width: 100%"
              />
            </div>
          </div>
        </div>

        <!-- 快捷时间选择 -->

        <div class="form-item">
          <label class="form-label"></label>
          <div class="form-content">
            <div class="time-shortcuts">
              <el-button
                v-for="shortcut in timeShortcuts"
                :key="shortcut.text"
                size="small"
                @click="selectTimeShortcut(shortcut)"
                :type="isShortcutSelected(shortcut) ? 'primary' : 'default'"
              >
                {{ shortcut.text }}
              </el-button>
            </div>
          </div>
        </div>

        <!-- 开始爬取按钮 -->
        <div class="form-section">
          <div class="form-item">
            <div class="form-content">
              <el-button
                type="primary"
                @click="startCrawling"
                :loading="crawling"
                :disabled="!canStartCrawling"
                size="large"
              >
                开始爬取
              </el-button>
            </div>
          </div>
        </div>
      </div>
      <!-- 爬取结果展示 -->
      <div v-if="crawlingResults.length > 0" class="results-section">
        <!-- <h3>爬取结果</h3> -->
        <el-table
          :data="crawlingResults"
          border
          style="width: 100%"
          class="device-ledger-table"
          height="100%"
          :scroll-y="true"
        >
          <el-table-column prop="newsLayout" label="数据源-版面" width="180" />
          <el-table-column prop="time" label="时间" width="180" />
          <el-table-column prop="title" label="标题" min-width="200" />
          <el-table-column
            prop="storePath"
            label="数据存储位置"
            min-width="150"
          />
        </el-table>
      </div>
    </el-card>

    <!-- 数据源选择对话框组件 -->
    <DataSourceSelectDialog
      v-model="showDataSourceDialog"
      @confirm="handleDataSourceConfirm"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from "vue";
import { ElMessage } from "element-plus";
import { Setting, Download, Check } from "@element-plus/icons-vue";
import api from "@/utils/request";
import DataSourceSelectDialog from "@/components/DataSourceSelectDialog.vue";
import axios from "axios";
import {
  TIME_SHORTCUTS,
  rangeForShortcut,
  isShortcutActive,
} from "@/utils/dateShortcuts";

// 响应式数据
const showDataSourceDialog = ref(false);
const showDetailDialog = ref(false);
const selectedDataSource = ref(null);
const dateRange = ref([]);
const crawling = ref(false);
const crawlingResults = ref([]);
const currentDetail = ref(null);

// 时间快捷选项（公用）
const timeShortcuts = ref(TIME_SHORTCUTS);

// 计算属性
const canStartCrawling = computed(() => {
  return (
    selectedDataSource.value && dateRange.value && dateRange.value.length === 2
  );
});

// 方法
const handleDataSourceConfirm = (result) => {
  selectedDataSource.value = result;
};

const selectTimeShortcut = (shortcut) => {
  dateRange.value = rangeForShortcut(shortcut);
};

const isShortcutSelected = (shortcut) => {
  return isShortcutActive(dateRange.value, shortcut);
};

// 将 YYYY-MM-DD 字符串格式化为 YYYY-MM-DD
const formatCompactDate = (value) => {
  if (!value) return "";
  const str = String(value);
  if (str.includes("-")) return str;
  if (str.length !== 8) return str;
  const y = str.slice(0, 4);
  const m = str.slice(4, 6);
  const d = str.slice(6, 8);
  return `${y}-${m}-${d}`;
};

const startCrawling = async () => {
  if (!canStartCrawling.value) {
    ElMessage.warning("请先选择数据源和日期范围");
    return;
  }
  //   const { data } = await axios({
  //     method: "GET",
  //     url: "/json/dataSource.json",
  //   });

  //   const mapped = (data || []).map((item) => ({
  //     newsLayout: `${item.news_source}-${item.section}`,
  //     time: formatCompactDate(item.date),
  //     title: item.title,
  //     storePath: item.path,
  //   }));
  //   crawlingResults.value = mapped;
  //   ElMessage.success(`爬取程序已启动`);
  //   return;
  crawling.value = true;
  try {
    // 构建API调用参数
    const params = {
      countryId: selectedDataSource.value.countryId || 0,
      newsId: selectedDataSource.value.id || 0,
      layoutIds: selectedDataSource.value.sectionIds || [], // 保持字符串数组格式
      startTime: dateRange.value[0],
      endTime: dateRange.value[1],
    };

    // 调用爬取接口
    const res = await api({
      url: "/crawlData",
      method: "post",
      data: params,
    });

    if (res.data.code === 200) {
      // 根据规范，从 res.data.data 获取返回的 id
      const crawlId = res.data.data?.id;
      if (crawlId) {
        // 使用获取到的 id 调用第二个接口获取爬取结果
        const resultRes = await api({
          url: `/getCrawlDataStructure/${crawlId}`,
          method: "get",
        });

        if (resultRes.data.code === 200) {
          // 将接口返回的数据统一映射到表格需要的字段
          const resultData = resultRes.data.data?.crawlDataStructure || [];
          const normalized = (resultData || []).map((item) => ({
            newsLayout:
              item.newsLayout ??
              `${item.news_source ?? ""}-${item.section ?? ""}`,
            time: item.time
              ? formatCompactDate(item.time)
              : formatCompactDate(item.date),
            title: item.title,
            storePath: item.storePath ?? item.path,
          }));
          crawlingResults.value = normalized;
          ElMessage.success(`爬虫程序已启动`);
        } else {
          ElMessage.error(resultRes.data.msg || "获取爬取结果失败");
        }
      } else {
        ElMessage.error("爬取任务创建成功，但未获取到任务ID");
      }
    } else {
      ElMessage.error(res.data.msg || "爬取失败");
    }
  } catch (error) {
    console.error("爬取失败:", error);
    ElMessage.error("爬取失败，请重试");
  } finally {
    crawling.value = false;
  }
};

// 生命周期
// onMounted(() => {
//   // 不再需要在此初始化，组件内部处理
// })
</script>

<style scoped>
.card-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  justify-content: center;
  margin-bottom: 24px;
}

.form-container {
  max-width: 1067px;
  margin: 0 auto;
}

.form-item {
  margin-bottom: 18px;
  display: flex;
  align-items: center;
  height: 40px;
}

.form-label {
  width: 144px;
  margin-right: 20px;
  line-height: 1.4;
  font-family: "PingFang SC", sans-serif;
  font-weight: 500;
  font-size: 16px;
  color: #000000;
  flex-shrink: 0;
}
</style>
