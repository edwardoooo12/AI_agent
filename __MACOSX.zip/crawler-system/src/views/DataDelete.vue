<template>
  <div class="card-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>选择时间范围、新闻源进行批量删除</span>
        </div>
      </template>

      <div class="form-container">
        <!-- 选择数据源 -->
        <div class="form-section with-background">
          <div class="form-item">
            <label class="form-label">数据源</label>
            <div class="form-content">
              <span
                v-if="selectedDataSource"
                class="selected-source"
                @click="showDataSourceDialog = true"
              >
                已选择：{{ selectedDataSource.news }}
                <span class="selected-sections"
                  >（{{ selectedDataSource.sections?.join("、") }}）</span
                >
              </span>
              <div v-else @click="showDataSourceDialog = true">
                请选择数据源
              </div>
            </div>
          </div>
        </div>

        <!-- 选择日期范围 -->
        <div class="form-section with-background">
          <div class="form-item">
            <label class="form-label">时间范围</label>
            <div class="form-content">
              <el-date-picker
                v-model="dateRange"
                type="daterange"
                range-separator="-"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                style="width: 100%"
              />
            </div>
          </div>
        </div>

        <!-- 快捷时间选择 -->
        <div class="form-item">
          <label class="form-label"></label>
          <div class="form-content">
            <div class="time-shortcuts">
              <el-button
                v-for="shortcut in timeShortcuts"
                :key="shortcut.text"
                size="small"
                @click="selectTimeShortcut(shortcut)"
                :type="isShortcutSelected(shortcut) ? 'primary' : 'default'"
              >
                {{ shortcut.text }}
              </el-button>
            </div>
          </div>
        </div>

        <!-- 确定删除按钮 -->
        <div class="form-section">
          <div class="form-item">
            <div class="form-content">
              <el-button
                type="danger"
                @click="confirmDelete"
                :loading="deleting"
                :disabled="!canStartDelete"
                size="large"
                class="delete-btn"
              >
                {{ deleting ? "删除中..." : "确定删除" }}
              </el-button>
            </div>
          </div>
        </div>
      </div>
    </el-card>

    <!-- 数据源选择对话框组件 -->
    <DataSourceSelectDialog
      v-model="showDataSourceDialog"
      @confirm="handleDataSourceConfirm"
    />
  </div>
</template>

<script setup>
import { ref, computed } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { Setting } from "@element-plus/icons-vue";
import api from "@/utils/request";
import DataSourceSelectDialog from "@/components/DataSourceSelectDialog.vue";
import {
  TIME_SHORTCUTS,
  rangeForShortcut,
  isShortcutActive,
} from "@/utils/dateShortcuts";

// 响应式数据
const showDataSourceDialog = ref(false);
const selectedDataSource = ref(null);
const dateRange = ref([]);
const deleting = ref(false);

// 时间快捷选项（公用）
const timeShortcuts = ref(TIME_SHORTCUTS);

// 计算属性
const canStartDelete = computed(() => {
  return (
    selectedDataSource.value && dateRange.value && dateRange.value.length === 2
  );
});

// 方法
const handleDataSourceConfirm = (result) => {
  selectedDataSource.value = result;
};

// 选择快捷时间范围
const selectTimeShortcut = (shortcut) => {
  dateRange.value = rangeForShortcut(shortcut);
};

// 判断快捷项是否被选中
const isShortcutSelected = (shortcut) => {
  return isShortcutActive(dateRange.value, shortcut);
};

const confirmDelete = async () => {
  if (!canStartDelete.value) {
    ElMessage.warning("请完善删除条件");
    return;
  }

  try {
    await ElMessageBox.confirm(
      "确定要删除所选数据源在指定时间范围内的数据吗？此操作不可恢复！",
      "确认删除",
      {
        confirmButtonText: "确定删除",
        cancelButtonText: "取消",
        type: "warning",
        confirmButtonClass: "el-button--danger",
      }
    );

    await startDelete();
  } catch {
    // 用户取消删除
  }
};

const startDelete = async () => {
  deleting.value = true;
  try {
    // 根据记忆中的参数构造规范，构建删除参数
    const deleteParams = {
      countryId: selectedDataSource.value.countryId || 0,
      newsId: selectedDataSource.value.id || 0,
      layoutIds: selectedDataSource.value.sectionIds || [], // 保持字符串数组格式
      startTime: dateRange.value[0],
      endTime: dateRange.value[1],
    };

    // 调用/deleteFile接口
    const res = await api({
      url: "/deleteFile",
      method: "post",
      data: deleteParams,
    });

    if (res.data.code === 200) {
      ElMessage.success("数据删除成功！");
      // 清空选择
      selectedDataSource.value = null;
      dateRange.value = [];
    } else {
      ElMessage.error(res.data.msg || "删除失败");
    }
  } catch (error) {
    console.error("删除失败:", error);
    ElMessage.error("删除失败，请重试");
  } finally {
    deleting.value = false;
  }
};
</script>

<style scoped lang="scss">
.card-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  justify-content: center;
  margin-bottom: 24px;
}

.form-container {
  max-width: 1067px;
  margin: 0 auto;
}

.form-item {
  margin-bottom: 18px;
  display: flex;
  align-items: center;
  height: 40px;
}

.form-label {
  width: 144px;
  margin-right: 20px;
  line-height: 1.4;
  font-family: "PingFang SC", sans-serif;
  font-weight: 500;
  font-size: 16px;
  color: #000000;
  flex-shrink: 0;
}

.selected-source {
  color: #67c23a;
  font-size: 14px;
  font-family: "PingFang SC", sans-serif;
  cursor: pointer;
}

.selected-sections {
  color: #909399;
  font-size: 12px;
}

.delete-btn {
  min-width: 120px;
  height: 40px;
}

.time-shortcuts {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  :deep(.el-button) {
    & + .el-button {
      margin-left: 0;
    }
  }
}

:deep(.el-table__row) {
  cursor: pointer;
}

:deep(.el-table__row:hover) {
  background-color: #f5f7fa;
}
</style>
