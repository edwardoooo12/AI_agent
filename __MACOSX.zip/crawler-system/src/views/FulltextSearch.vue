<template>
  <div class="card-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>选择时间范围、新闻源等进行全文检索</span>
        </div>
      </template>

      <div class="form-container">
        <!-- 选择数据源 -->
        <div class="form-section with-background">
          <div class="form-item">
            <label class="form-label">数据源</label>
            <div class="form-content">
              <span
                v-if="selectedDataSource"
                class="selected-source"
                @click="showDataSourceDialog = true"
              >
                已选择：{{ selectedDataSource.news }}
                <span class="selected-sections"
                  >（{{ selectedDataSource.sections?.join("、") }}）</span
                >
              </span>
              <div v-else @click="showDataSourceDialog = true">
                请选择数据源
              </div>
            </div>
          </div>
        </div>

        <!-- 选择日期范围 -->
        <div class="form-section with-background">
          <div class="form-item">
            <label class="form-label">时间范围</label>
            <div class="form-content">
              <el-date-picker
                v-model="dateRange"
                type="daterange"
                range-separator="-"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                style="width: 100%"
              />
            </div>
          </div>
        </div>

        <!-- 快捷时间选择 -->
        <div class="form-item">
          <label class="form-label"></label>
          <div class="form-content">
            <div class="time-shortcuts">
              <el-button
                v-for="shortcut in timeShortcuts"
                :key="shortcut.text"
                size="small"
                @click="selectTimeShortcut(shortcut)"
                :type="isShortcutSelected(shortcut) ? 'primary' : 'default'"
              >
                {{ shortcut.text }}
              </el-button>
            </div>
          </div>
        </div>

        <!-- 关键词 -->
        <div class="form-section with-background">
          <div class="form-item">
            <label class="form-label">关键词</label>
            <div class="form-content">
              <el-input
                v-model="keyword"
                placeholder="请输入检索关键词"
                class="keyword-input"
                clearable
                style="width: 100%"
              />
            </div>
          </div>
        </div>

        <!-- 开始检索按钮 -->
        <div class="form-section">
          <div class="form-item">
            <div class="form-content">
              <el-button
                type="primary"
                @click="startSearch"
                :loading="searching"
                :disabled="!canStartSearch"
                size="large"
                class="search-btn"
              >
                {{ searching ? "检索中..." : "开始检索" }}
              </el-button>
            </div>
          </div>
        </div>
      </div>
    </el-card>

    <!-- 数据源选择对话框组件 -->
    <DataSourceSelectDialog
      v-model="showDataSourceDialog"
      @confirm="handleDataSourceConfirm"
    />

    <!-- 检索结果表格 -->
    <el-card v-if="searchResults.length > 0" class="result-card">
      <template #header>
        <div class="card-header">
          <span>检索结果（共 {{ searchResults.length }} 条）</span>
        </div>
      </template>

      <el-table :data="searchResults" border stripe class="result-table">
        <el-table-column
          prop="title"
          label="文件名"
          min-width="200"
          show-overflow-tooltip
        />
        <el-table-column label="新闻源-布局名称" min-width="150">
          <template #default="{ row }">
            <span>{{ getDataSourceLayout(row) }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="time" label="时间" width="180" />
        <el-table-column label="操作" width="120" fixed="right">
          <template #default="{ row }">
            <el-button
              type="primary"
              size="small"
              link
              @click="viewDetail(row)"
            >
              查看
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 预览对话框 -->
    <el-dialog
      v-model="detailVisible"
      :title="previewTitle"
      width="60%"
      :close-on-click-modal="false"
    >
      <div
        v-if="previewType === 'json'"
        style="max-height: 60vh; overflow: auto"
      >
        <pre
          style="
            background: #0f1221;
            color: #e6e9f0;
            padding: 12px;
            border-radius: 8px;
            white-space: pre-wrap;
            word-break: break-word;
          "
          >{{ previewJson }}</pre
        >
      </div>
      <div
        v-else-if="previewType === 'image'"
        style="text-align: center; max-height: 60vh; overflow: auto"
      >
        <img
          :src="previewUrl"
          alt="预览图片"
          style="max-width: 100%; height: auto"
        />
      </div>
      <div v-else>
        <p>该类型不支持在线预览，已开始下载。</p>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="detailVisible = false">关闭</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import api from "@/utils/request";
import DataSourceSelectDialog from "@/components/DataSourceSelectDialog.vue";
import { Setting } from "@element-plus/icons-vue";
import {
  TIME_SHORTCUTS,
  rangeForShortcut,
  isShortcutActive,
} from "@/utils/dateShortcuts";

// 响应式数据
const showDataSourceDialog = ref(false);
const selectedDataSource = ref(null);
const dateRange = ref([]);
const keyword = ref("");
const searching = ref(false);
const searchResults = ref([]); // 检索结果数据

// 时间快捷选项（公用）
const timeShortcuts = ref(TIME_SHORTCUTS);

// 详情预览状态
const detailVisible = ref(false);
const previewType = ref(""); // 'json' | 'image' | 'download'
const previewTitle = ref("预览");
const previewUrl = ref("");
const previewJson = ref("");
// 计算属性
const canStartSearch = computed(() => {
  return (
    dateRange.value && dateRange.value.length === 2 && keyword.value.trim()
  );
});

// 方法
const handleDataSourceConfirm = (result) => {
  selectedDataSource.value = result;
};

const startSearch = async () => {
  if (!canStartSearch.value) {
    ElMessage.warning("请完善检索条件");
    return;
  }

  searching.value = true;
  try {
    // 构建 GET 请求的查询参数 - 传递显示名称而非ID（全文检索不需要数据类型）
    const searchParams = {
      keyword: keyword.value.trim(),
      startTime: dateRange.value[0],
      endTime: dateRange.value[1],
      country: selectedDataSource.value
        ? selectedDataSource.value.country || ""
        : "", // 传递国家显示名称
      news: selectedDataSource.value ? selectedDataSource.value.news || "" : "", // 传递新闻源显示名称
      layoutName:
        selectedDataSource.value && selectedDataSource.value.sections
          ? selectedDataSource.value.sections.join(",")
          : "", // 传递板块显示名称
    };

    // 调用 /search/keyword 接口，使用 GET 请求
    const res = await api({
      url: "/search/keyword",
      method: "get",
      params: searchParams,
    });

    if (res.data.code === 200) {
      ElMessage.success("检索完成！");
      // 存储检索结果数据
      searchResults.value = res.data.data || [];
      console.log("检索结果:", res.data.data);
    } else {
      ElMessage.error(res.data.msg || "检索失败");
    }
  } catch (error) {
    console.error("检索失败:", error);
    ElMessage.error("检索失败，请重试");
  } finally {
    searching.value = false;
  }
};

// 选择快捷时间范围
const selectTimeShortcut = (shortcut) => {
  dateRange.value = rangeForShortcut(shortcut);
};

// 判断快捷项是否被选中
const isShortcutSelected = (shortcut) => {
  return isShortcutActive(dateRange.value, shortcut);
};

// 获取新闻源-布局名称显示文本
const getDataSourceLayout = (row) => {
  if (!row.news && !row.layoutName) {
    return "空";
  }
  const newsName = row.news || "";
  const layoutName = row.layoutName || "";

  if (!newsName && !layoutName) {
    return "空";
  }
  if (!newsName) {
    return layoutName;
  }
  if (!layoutName) {
    return newsName;
  }
  return `${newsName}-${layoutName}`;
};

// 查看详情：type=1 JSON，type=2 图片，其他下载
const viewDetail = async (row) => {
  console.log(
    "%c [ row ]-263-「FulltextSearch」",
    "font-size:15px; background:#c71cd5; color:#ff60ff;",
    row
  );
  try {
    const type = String(row?.type || "").trim();
    const url = "http://localhost:9023" + row?.url || row?.link || "";
    previewTitle.value = row?.title || "预览";
    if (!url) {
      ElMessage.warning("无可预览的地址");
      return;
    }

    if (type == "1") {
      previewType.value = "json";
      previewUrl.value = url;
      previewJson.value = "加载中...";
      detailVisible.value = true;
      // 尝试拉取 JSON
      const resp = await fetch(url);
      const text = await resp.text();
      // 尝试格式化为 JSON
      try {
        const obj = JSON.parse(text);
        previewJson.value = JSON.stringify(obj, null, 2);
      } catch (e) {
        previewJson.value = text;
      }
      return;
    }

    if (type == "2") {
      previewType.value = "image";
      previewUrl.value = url;
      detailVisible.value = true;
      return;
    }

    // 其他类型：下载
    previewType.value = "download";
    detailVisible.value = true;
    const a = document.createElement("a");
    a.href = url;
    a.download = "";
    a.target = "_blank";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  } catch (e) {
    console.error("预览失败:", e);
    ElMessage.error("预览失败");
  }
};
</script>

<style scoped lang="scss">
.card-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  justify-content: center;
  margin-bottom: 24px;
}

.form-container {
  max-width: 1067px;
  margin: 0 auto;
}

.form-item {
  margin-bottom: 18px;
  display: flex;
  align-items: center;
  height: 40px;
}

.form-label {
  width: 144px;
  margin-right: 20px;
  line-height: 1.4;
  font-family: "PingFang SC", sans-serif;
  font-weight: 500;
  font-size: 16px;
  color: #000000;
  flex-shrink: 0;
}

.selected-source {
  color: #67c23a;
  font-size: 14px;
  font-family: "PingFang SC", sans-serif;
  cursor: pointer;
}

.selected-sections {
  color: #909399;
  font-size: 12px;
}

.keyword-input {
  width: 100%;
}

.search-btn {
  min-width: 120px;
  height: 40px;
}

.result-card {
  margin-top: 20px;
}

.result-table {
  margin-top: 16px;
}

.time-shortcuts {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  :deep(.el-button) {
    & + .el-button {
      margin-left: 0;
    }
  }
}

:deep(.el-table .el-table__cell) {
  padding: 12px 0;
}

:deep(.el-table .el-table__header-wrapper th) {
  background-color: #f5f7fa;
  font-weight: 600;
}
</style>
