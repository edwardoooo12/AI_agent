<template>
  <DataExport />
</template>

<script setup>
import DataExport from './DataExport.vue'
</script>

<style scoped>
</style>