<script setup lang="ts">
import { ref, onMounted, nextTick, shallowRef } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import { Loading } from "@element-plus/icons-vue";
import api from "@/utils/request";
import zhCn from "element-plus/dist/locale/zh-cn.mjs";
import MilitaryChart from "@/components/MilitaryChart.vue";
import JQDataDialog from "@/components/JQDataDialog.vue";

const router = useRouter();

// 页面状态控制
const showMilitaryChart = ref(false);
const militaryChartLoading = ref(false);
const showJQDialog = ref(false);

// 显示确认弹窗
const showConfirmDialog = () => {
  showJQDialog.value = true;
};

// 确认跳转处理
const handleConfirm = async () => {
  militaryChartLoading.value = true;

  // 先显示 MilitaryChart 组件
  showMilitaryChart.value = true;

  // 等待组件初始化完成
  await nextTick();

  // 增加等待时间确保ECharts完全初始化
  setTimeout(() => {
    militaryChartLoading.value = false;
  }, 2000); // 增加到2秒
};

// 取消跳转处理
const handleCancel = () => {
  showJQDialog.value = false;
};

// 返回上一级
const goBack = () => {
  showMilitaryChart.value = false;
  militaryChartLoading.value = false;
};

// 弹窗相关状态
const dialogVisible = ref(false);
const dialogVisibleBycountry = ref(false);
const dialogTitle = ref("");
const tableData = ref([]);
const tableDataBycountry = shallowRef([]);
const currentType = ref(null);
const loading = ref(false);

// 类型映射
const typeMap = {
  1: "区域媒体",
  2: "社交平台",
  3: "公开社交媒体",
  4: "公开数据",
  5: "其他",
};

// 数据源国家统计饼图数据
const pieChartOption = ref({
  title: {
    text: "数据源国家覆盖比例",
    left: 20,
    top: 20,
    textStyle: {
      fontSize: 16,
      fontWeight: "bold",
    },
  },
  tooltip: {
    trigger: "item",
    formatter: "{a} <br/>{b}: {c} ({d}%)",
  },
  legend: {
    orient: "horizontal",
    top: 50,
    left: 20,
    itemWidth: 12,
    itemHeight: 12,
    textStyle: {
      fontSize: 12,
    },
  },
  series: [
    {
      name: "数据源统计",
      type: "pie",
      radius: ["30%", "60%"],
      center: ["50%", "60%"],
      data: [],
      labelLine: {
        show: false,
      },
      label: {
        show: false,
        position: "center",
      },
      //   itemStyle: {
      //     borderRadius: 10,
      //     borderColor: "#fff",
      //     borderWidth: 2,
      //   },
      //   label: {
      //     show: true,
      //     position: "outside",
      //     formatter: "{b}\n{c}",
      //   },
      //   emphasis: {
      //     itemStyle: {
      //       shadowBlur: 10,
      //       shadowOffsetX: 0,
      //       shadowColor: "rgba(0, 0, 0, 0.5)",
      //     },
      //   },
    },
  ],
});

// 数据类型柱状图数据
const barChartOption = ref({
  title: {
    text: "数据类型/数量",
    left: "center",
    top: 20,
    textStyle: {
      fontSize: 16,
      fontWeight: "bold",
    },
  },
  tooltip: {
    trigger: "axis",
    axisPointer: {
      type: "shadow",
    },
  },
  grid: {
    left: "3%",
    right: "4%",
    bottom: "3%",
    top: "15%",
    containLabel: true,
  },
  xAxis: {
    type: "category",
    data: [],
  },
  yAxis: {
    type: "value",
  },
  series: [
    {
      name: "数量",
      type: "bar",
      data: [],
      itemStyle: {
        color: "#5470c6",
      },
      emphasis: {
        itemStyle: {
          color: "#3ba272",
        },
      },
    },
  ],
});

// 思维导图数据
const treeChartOption = ref({
  title: {
    text: "装备数据组成",
    left: "center",
    top: 20,
    textStyle: {
      fontSize: 16,
      fontWeight: "bold",
    },
  },
  tooltip: {
    trigger: "item",
    triggerOn: "mousemove",
  },
  series: [
    {
      type: "tree",
      data: [],
      top: "10%",
      left: "7%",
      bottom: "22%",
      right: "20%",
      symbolSize: 7,
      label: {
        position: "left",
        verticalAlign: "middle",
        align: "right",
        fontSize: 12,
      },
      leaves: {
        label: {
          position: "right",
          verticalAlign: "middle",
          align: "left",
        },
      },
      emphasis: {
        focus: "descendant",
      },
      expandAndCollapse: true,
      animationDuration: 550,
      animationDurationUpdate: 750,
    },
  ],
});

// 颜色配置
const colors = [
  "#5470c6",
  "#91cc75",
  "#fac858",
  "#ee6666",
  "#73c0de",
  "#3ba272",
  "#fc8452",
  "#9a60b4",
  "#ea7ccc",
  "#5470c6",
  "#7cb342",
];

// 获取图表数据
const getChartData = async () => {
  try {
    const res = await api({ url: "/chart", method: "get" });
    if (res.data.code === 200) {
      const data = res.data.data;

      // 更新饼图数据
      updatePieChart(data.circleChart);

      // 更新柱状图数据
      updateBarChart(data.barChart);

      // 更新树形图数据
      updateTreeChart(data.treeNode);
    }
  } catch (error) {
    console.error("获取图表数据失败:", error);
  }
};

// 更新饶状图数据
const updatePieChart = (circleData) => {
  const pieData = circleData.map((item, index) => ({
    value: item.count,
    name: item.name,
    itemStyle: { color: colors[index % colors.length] },
  }));

  pieChartOption.value.series[0].data = pieData;
};

// 更新柱状图数据
const updateBarChart = (barData) => {
  const categories = barData.map((item) => item.name);
  const values = barData.map((item) => item.count);

  barChartOption.value.xAxis.data = categories;
  barChartOption.value.series[0].data = values;
};

// 转换树形数据格式
const convertTreeData = (node) => {
  if (!node) return null;

  const result: any = {
    name: node.label,
  };

  if (node.children && node.children.length > 0) {
    result.children = node.children
      .map((child) => convertTreeData(child))
      .filter(Boolean);
  }

  return result;
};

// 更新树形图数据
const updateTreeChart = (treeData) => {
  if (treeData) {
    const convertedData = convertTreeData(treeData);
    treeChartOption.value.series[0].data = [convertedData];
  }
};

// 获取数据源列表
const getDataSourceList = async (type) => {
  loading.value = true;
  try {
    const params = {
      pageNum: 1,
      pageSize: 1000,
      type: type,
    };
    const res = await api({ url: "/list", method: "get", params });
    if (res.data.code === 200) {
      tableData.value = res.data.rows || [];
    } else {
      ElMessage.error("获取数据失败");
      tableData.value = [];
    }
  } catch (error) {
    console.error("获取数据源列表失败:", error);
    ElMessage.error("获取数据失败");
    tableData.value = [];
  } finally {
    loading.value = false;
  }
};

// 根据地区获取数据源列表
const getDataSourceListByCity = async (country) => {
  loading.value = true;
  try {
    const params = {
      pageNum: 1,
      pageSize: 1000,
      country: country,
    };
    const res = await api({ url: "/news/list", method: "get", params });
    if (res.data.code === 200) {
      tableDataBycountry.value = res.data?.data || [];
    } else {
      ElMessage.error("获取数据失败");
      tableDataBycountry.value = [];
    }
  } catch (error) {
    console.error("获取数据源列表失败:", error);
    ElMessage.error("获取数据失败");
    tableDataBycountry.value = [];
  } finally {
    loading.value = false;
  }
};

// 柱状图点击事件处理
const handleBarClick = (params) => {
  // 根据点击的柱子名称匹配对应的type
  const clickedName = params.name;
  let type = null;

  // 根据柱状图的分类名称匹配type值
  for (const [key, value] of Object.entries(typeMap)) {
    if (value === clickedName) {
      type = parseInt(key);
      break;
    }
  }

  if (type !== null) {
    currentType.value = type;
    dialogTitle.value = `${clickedName} - 数据源列表`;
    dialogVisible.value = true;
    getDataSourceList(type);
  }
};

// 饼图点击事件处理（按国家/地区打开弹窗）
const handlePieClick = (params) => {
  const clickedRegion = params.name;
  currentType.value = null;
  dialogTitle.value = `${clickedRegion} - 数据源列表`;
  dialogVisibleBycountry.value = true;
  getDataSourceListByCity(clickedRegion);
};

// 根据type值获取对应的标签
const getTypeLabel = (type) => {
  return typeMap[type] || type;
};

onMounted(() => {
  // 组件加载后获取图表数据
  getChartData();
});
</script>

<template>
  <div class="dashboard-container">
    <div class="dashboard-header">
      <h1>统计数据可视化</h1>
      <el-button type="primary" @click="showConfirmDialog" class="jq-data-btn">
        跳转JQ数据
      </el-button>
    </div>

    <!-- 原始图表内容 -->
    <div v-show="!showMilitaryChart" class="charts-container">
      <!-- 上排两个图表 -->
      <div class="charts-row">
        <el-card class="chart-card">
          <v-chart
            :option="pieChartOption"
            style="height: 400px"
            @click="handlePieClick"
          />
        </el-card>

        <el-card class="chart-card">
          <v-chart
            :option="barChartOption"
            style="height: 400px"
            @click="handleBarClick"
          />
        </el-card>
      </div>

      <!-- 下排思维导图 -->
      <!-- <div class="charts-row">
        <el-card class="chart-card-full">
          <v-chart :option="treeChartOption" style="height: 500px" />
        </el-card>
      </div> -->
    </div>

    <!-- JQ数据内容（MilitaryChart组件） -->
    <div v-show="showMilitaryChart" class="military-content">
      <!-- 初始化加载状态 -->
      <div v-if="militaryChartLoading" class="loading-overlay">
        <div class="loading-content">
          <el-icon class="loading-icon">
            <Loading />
          </el-icon>
          <p>正在初始化JQ数据可视化系统...</p>
        </div>
      </div>

      <!-- MilitaryChart 组件 -->
      <div v-show="!militaryChartLoading">
        <MilitaryChart />
      </div>
    </div>

    <!-- JQ数据确认弹窗 - 暂时注释 -->
    <!-- <JQDataDialog
      v-model:visible="showJQDialog"
      @confirm="handleConfirm"
      @cancel="handleCancel"
    /> -->

    <!-- 显示JQ数据图片弹窗 -->
    <el-dialog
      v-model="showJQDialog"
      title="JQ数据"
      width="100%"
      hight="100%"
      :close-on-click-modal="true"
      :close-on-press-escape="true"
    >
      <div class="jq-data-image-container">
        <img
          src="/images/JQData.jpg"
          alt="JQ数据"
          class="jq-data-image"
          style="object-fit: contain"
        />
      </div>
    </el-dialog>

    <!-- 数据源弹窗 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogTitle"
      class="table-dialog"
      width="80%"
      top="5vh"
    >
      <el-config-provider :locale="zhCn">
        <el-table
          :data="tableData"
          class="device-ledger-table"
          style="width: 100%"
          height="500"
          v-loading="loading"
        >
          <el-table-column prop="city" label="国家/地区" width="180" />
          <el-table-column prop="news" label="数据源" min-width="160" />
          <el-table-column prop="type" label="类别" width="120">
            <template #default="scope">
              {{ getTypeLabel(scope.row.type) }}
            </template>
          </el-table-column>
          <el-table-column
            prop="url"
            label="URL"
            min-width="250"
            show-overflow-tooltip
          />
          <el-table-column
            prop="layoutName"
            label="版面/账号/关键字"
            width="220"
          />
          <el-table-column prop="crawlingMethod" label="爬取方式" width="150" />
        </el-table>

        <!-- 数据统计 -->
        <div style="margin-top: 16px; text-align: center; color: #606266">
          共 {{ tableData.length }} 条数据
        </div>
      </el-config-provider>
    </el-dialog>
    <!-- 数据源弹窗-国家 -->
    <el-dialog
      v-model="dialogVisibleBycountry"
      :title="dialogTitle"
      class="table-dialog"
      width="80%"
      top="5vh"
    >
      <div class="table-container">
        <el-table
          :data="tableDataBycountry"
          class="device-ledger-table"
          style="width: 100%"
          height="500"
          v-loading="loading"
        >
          <el-table-column prop="country" label="国家/地区" width="180" />
          <el-table-column prop="name" label="数据源" min-width="200" />
        </el-table>
      </div>

      <!-- 数据统计 -->
      <div style="margin-top: 16px; text-align: center; color: #606266">
        共 {{ tableDataBycountry.length }} 条数据
      </div>
    </el-dialog>
  </div>
</template>

<style scoped>
.table-container {
  /* background: #d0e2f0; */
}
.dashboard-container {
  padding: 20px;
  background-color: #f5f5f5;
  min-height: 100vh;
}

.dashboard-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  border-bottom: 1px solid #e4e7ed;
  padding-bottom: 12px;
}

.dashboard-header h1 {
  margin: 0;
  color: #333;
  font-size: 18px;
  font-weight: normal;
}

.jq-data-btn {
  font-size: 14px;
  padding: 8px 16px;
}

.charts-container {
  max-width: 1400px;
  margin: 0 auto;
}

.charts-row {
  display: flex;
  gap: 20px;
  margin-bottom: 20px;
}

.chart-card {
  flex: 1;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  border-radius: 8px;
}

.chart-card-full {
  width: 100%;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  border-radius: 8px;
}

/* MilitaryChart 内容样式 */
.military-content {
  width: 100%;
  min-height: calc(100vh - 120px);
  position: relative;
}

.military-content :deep(.military-dashboard) {
  padding: 0;
  background-color: transparent;
  min-height: auto;
}

/* 加载状态样式 */
.loading-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg, #0f1221 0%, #1a1f35 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.loading-content {
  text-align: center;
  color: #e6e9f0;
}

.loading-icon {
  font-size: 48px;
  color: #3b82f6;
  margin-bottom: 16px;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

.loading-content p {
  font-size: 16px;
  margin: 0;
  letter-spacing: 1px;
}

/* JQ数据图片样式 */
.jq-data-image-container {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0;
  height: 70vh;
}

.jq-data-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  /* border-radius: 8px; */
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
  cursor: pointer;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .charts-row {
    flex-direction: column;
  }

  .dashboard-container {
    padding: 10px;
  }
}
</style>
