<script setup>
import { ref, reactive, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import api from "@/utils/request";
import DataSourceDialog from "@/components/DataSourceDialog.vue";
import zhCn from "element-plus/dist/locale/zh-cn.mjs";

const tableData = ref([]);
const total = ref(0);
const currentPage = ref(1);
const pageSize = ref(10);
const cityOptions = ref([]);
const typeOptions = ref([
  { label: "区域媒体", value: 1 },
  { label: "社交平台", value: 2 },
  { label: "公开社交媒体", value: 3 },
  { label: "公开数据", value: 4 },
  { label: "其他", value: 5 },
]);

const layoutOptions = ref([
  { label: "版面", value: "1" },
  { label: "账号", value: "2" },
  { label: "关键字", value: "3" },
]);

const dialogVisible = ref(false);
const cityIdMap = ref({});
const currentRow = reactive({
  id: null,
  city: "",
  news: "",
  url: "",
  type: 1,
  layoutName: "",
  crawlingMethod: "",
});

function openEdit(row) {
  Object.assign(currentRow, row);
  dialogVisible.value = true;
}

async function handleDialogSave(data) {
  // 创建：当没有 id 时，调用新增接口
  if (data.id == null) {
    const payload = {
      cityId: cityIdMap.value[data.city] ?? 0,
      news: data.news,
      url: data.url,
      type: data.type,
      windowType: data.windowType,
      layoutName: data.layoutName,
      crawlingMethod: data.crawlingMethod,
    };
    await api({ url: "/add", method: "post", data: payload });
    ElMessage.success("新增成功");
    // 新增后跳转到第一页
    currentPage.value = 1;
    await getDataSourceList();
    dialogVisible.value = false;
    return;
  }

  // 编辑：调用更新接口
  const payload = {
    id: data.id,
    cityId: cityIdMap.value[data.city] ?? 0,
    news: data.news,
    url: data.url,
    type: data.type,
    layoutName: data.layoutName,
    crawlingMethod: data.crawlingMethod,
  };
  await api({ url: "/update", method: "put", data: payload });
  ElMessage.success("更新成功");
  await getDataSourceList();
  dialogVisible.value = false;
}

function handleCreate() {
  Object.assign(currentRow, {
    id: null,
    city: "",
    news: "",
    url: "",
    type: 1,
    layoutName: "",
    crawlingMethod: "",
  });
  dialogVisible.value = true;
}

function handleManage(row) {
  openEdit(row);
}

async function handleDelete(row) {
  try {
    await ElMessageBox.confirm("确认删除该数据源吗？", "提示", {
      type: "warning",
    });
    // 使用DELETE方法和路径参数
    await api({ url: `/${row.id}`, method: "delete" });
    ElMessage.success("删除成功");
    await getDataSourceList();
  } catch (e) {
    // ignore cancel or failure
  }
}

/**
 * 获取城市列表
 */
const getCityList = async () => {
  try {
    const res = await api({ url: "/city/list", method: "get" });
    if (res.data.code === 200) {
      // 根据记忆规范，数据位于res.data.data路径下，需要转换为{label, value}格式
      const cityData = res.data.data || [];
      cityOptions.value = cityData.map((item) => ({
        label: item.name,
        value: item.name,
      }));

      // 构建 cityId 映射表
      const idMap = {};
      cityData.forEach((item) => {
        idMap[item.name] = item.id;
      });
      cityIdMap.value = idMap;
    }
  } catch (error) {
    console.error("获取城市列表失败:", error);
  }
};

/**
 * 获取数据源列表
 */
const getDataSourceList = async () => {
  const params = {
    pageSize: pageSize.value,
    pageNum: currentPage.value,
  };
  const res = await api({ url: "/list", method: "get", params });
  if (res.data.code === 200) {
    tableData.value = res.data.rows;
    total.value = res.data.total || 0;
  }
};

/**
 * 分页改变处理
 */
const handleCurrentChange = (page) => {
  currentPage.value = page;
  getDataSourceList();
};

/**
 * 每页条数改变处理
 */
const handleSizeChange = (size) => {
  pageSize.value = size;
  currentPage.value = 1;
  getDataSourceList();
};

/**
 * 根据type值获取对应的标签
 */
const getTypeLabel = (type) => {
  const option = typeOptions.value.find((item) => item.value === type);
  return option ? option.label : type;
};

onMounted(() => {
  getCityList();
  getDataSourceList();
});
</script>

<template>
  <div class="device-ledger-container">
    <div class="ledger-title">设备台账（类型/单位/位置/描述）</div>
    <div class="table-container">
      <el-table
        :data="tableData"
        class="device-ledger-table"
        style="width: 100%"
        height="100%"
        :scroll-y="true"
      >
        <!-- <el-table-column prop="id" label="序号" width="80" /> -->
        <el-table-column prop="city" label="国家/地区" />
        <el-table-column prop="news" label="数据源" width="auto" />
        <el-table-column prop="type" label="类别" width="auto">
          <template #default="scope">
            {{ getTypeLabel(scope.row.type) }}
          </template>
        </el-table-column>
        <el-table-column
          prop="layoutName"
          label="版面/账号/关键字"
          width="auto"
        />
        <!-- <el-table-column label="操作" width="200">
          <template #default="scope">
            <el-button
              size="small"
              type="primary"
              @click="handleManage(scope.row)"
              >管理</el-button
            >
            <el-button
              size="small"
              type="danger"
              @click="handleDelete(scope.row)"
              >删除</el-button
            >
          </template>
        </el-table-column> -->
      </el-table>
    </div>

    <!-- 分页组件 -->
    <div class="pagination-container">
      <el-pagination
        v-model:current-page="currentPage"
        v-model:page-size="pageSize"
        :page-sizes="[10, 20, 50, 100]"
        :total="total"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        prev-text="上一页"
        next-text="下一页"
      />
    </div>
  </div>

  <DataSourceDialog
    v-if="dialogVisible"
    v-model="dialogVisible"
    :form-data="currentRow"
    :city-options="cityOptions"
    :type-options="typeOptions"
    :layout-options="layoutOptions"
    @save="handleDialogSave"
  />
</template>

<style scoped lang="scss">
.device-ledger-container {
  background: rgba(255, 255, 255, 0.16);
  /* border: 0.5px solid #ffffff; */
  height: 100%;
  border-radius: 8px;
  padding: 24px 20px 20px;
  backdrop-filter: blur(18px);
  display: flex;
  flex-direction: column;
  gap: 20px;
  .table-container {
    height: 0px;
    flex: 1;
  }
}

.ledger-title {
  font-family: "PingFang SC", sans-serif;
  font-weight: 500;
  font-size: 16px;
  line-height: 1.4;
  color: #333333;
  text-align: left;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}

.description-link {
  color: #333333;
  cursor: pointer;
  text-decoration: underline;
}

.description-link:hover {
  color: #409eff;
}
</style>
