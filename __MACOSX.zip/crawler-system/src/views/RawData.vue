<script setup>
import { ref, onMounted, reactive } from 'vue'
import api from '@/utils/request'
import { ElMessageBox, ElMessage } from 'element-plus'
import { 
  Folder, 
  Document, 
  Menu,
  Files,
  ArrowDown,
  ArrowUp
} from '@element-plus/icons-vue'

// 表格数据
const tableData = ref([])
const loading = ref(false)

// 移除分页信息

// 左侧导航菜单数据
const navigationItems = [
  { id: 1, label: '国家统计局', type: 1, icon: 'home' },
  { id: 2, label: '海关', type: 2, icon: 'ship' },
  { id: 3, label: '世界银行', type: 3, icon: 'building' },
  { id: 4, label: 'WTO', type: 4, icon: 'grid' }
]

// 当前选中的数据源类型
const selectedDataType = ref(null)
// 当前文件列表（存储完整的文件信息）
const fileList = ref([])  
// 文件名列表（仅存储name字段用于显示）
const fileNames = ref([])
// 文件列表展开状态
const fileListExpanded = ref(true)
// 选中的具体文件
const selectedFile = ref(null)

// 表格列配置（动态生成）
const tableColumns = ref([])

// 模拟数据 - 实际项目中应该从接口获取
const mockData = [
  { year: 1991, export_value: 735, export_amount: 368, import_amount: 366, trade_balance: 0, export_growth_rate: '', export_growth: '', import_growth: '' },
  { year: 1992, export_value: 771, export_amount: 414, import_amount: 356, trade_balance: 56, export_growth_rate: 4.9, export_growth: 12.5, import_growth: -2.7 },
  { year: 1993, export_value: 850, export_amount: 438, import_amount: 412, trade_balance: 17, export_growth_rate: 11.5, export_growth: 5.6, import_growth: 17.9 },
  { year: 1994, export_value: 1201, export_amount: 581, import_amount: 620, trade_balance: -40, export_growth_rate: 39.7, export_growth: 32.5, import_growth: 46.9 },
  { year: 1995, export_value: 2001, export_amount: 809, import_amount: 1252, trade_balance: -443, export_growth_rate: 72.1, export_growth: 39.2, import_growth: 102.3 },
  { year: 1996, export_value: 2580, export_amount: 1082, import_amount: 1485, trade_balance: -416, export_growth_rate: 24.8, export_growth: 33.7, import_growth: 19.1 },
  { year: 1997, export_value: 3054, export_amount: 1470, import_amount: 1614, trade_balance: -144, export_growth_rate: 19.5, export_growth: 35.8, import_growth: 7.7 },
  { year: 1998, export_value: 3222, export_amount: 1767, import_amount: 2065, trade_balance: -298, export_growth_rate: 23.9, export_growth: 20.2, import_growth: 27.9 },
  { year: 1999, export_value: 4156, export_amount: 1955, import_amount: 2200, trade_balance: -244, export_growth_rate: 5.7, export_growth: 10.7, import_growth: 7.1 },
  { year: 1990, export_value: 5580, export_amount: 2956, import_amount: 2574, trade_balance: 412, export_growth_rate: 35.8, export_growth: 52.7, import_growth: 17.0 },
  { year: 1991, export_value: 7266, export_amount: 3827, import_amount: 3399, trade_balance: 429, export_growth_rate: 30.0, export_growth: 29.2, import_growth: 32.1 },
  { year: 1992, export_value: 9120, export_amount: 4676, import_amount: 4443, trade_balance: 233, export_growth_rate: 25.2, export_growth: 22.2, import_growth: 30.7 },
  { year: 1993, export_value: 11271, export_amount: 5295, import_amount: 5906, trade_balance: -701, export_growth_rate: 23.6, export_growth: 13.3, import_growth: 34.7 },
  { year: 1994, export_value: 20362, export_amount: 10422, import_amount: 9960, trade_balance: 462, export_growth_rate: 80.8, export_growth: 97.2, import_growth: 68.4 },
  { year: 1995, export_value: 23500, export_amount: 12452, import_amount: 11048, trade_balance: 1404, export_growth_rate: 15.3, export_growth: 19.5, import_growth: 10.9 },
  { year: 1996, export_value: 24134, export_amount: 12676, import_amount: 11557, trade_balance: 1019, export_growth_rate: 2.7, export_growth: 1.1, import_growth: 4.6 },
  { year: 1997, export_value: 26367, export_amount: 15161, import_amount: 11007, trade_balance: 3354, export_growth_rate: 11.7, export_growth: 20.8, import_growth: 2.3 },
  { year: 1998, export_value: 26950, export_amount: 15224, import_amount: 11656, trade_balance: 3597, export_growth_rate: -0.4, export_growth: 0.4, import_growth: -1.5 },
  { year: 1999, export_value: 29596, export_amount: 16160, import_amount: 13736, trade_balance: 2423, export_growth_rate: 11.3, export_growth: 6.1, import_growth: 18.1 },
  { year: 2000, export_value: 39273, export_amount: 20634, import_amount: 18639, trade_balance: 1996, export_growth_rate: 31.4, export_growth: 27.7, import_growth: 35.7 },
  { year: 2001, export_value: 42184, export_amount: 22024, import_amount: 20159, trade_balance: 1865, export_growth_rate: 7.4, export_growth: 6.7, import_growth: 8.2 },
  { year: 2002, export_value: 51376, export_amount: 25948, import_amount: 24431, trade_balance: 2518, export_growth_rate: 21.8, export_growth: 22.4, import_growth: 21.2 },
  { year: 2003, export_value: 70483, export_amount: 36268, import_amount: 34156, trade_balance: 2092, export_growth_rate: 37.2, export_growth: 34.7, import_growth: 40.0 },
  { year: 2004, export_value: 95539, export_amount: 49103, import_amount: 46439, trade_balance: 2668, export_growth_rate: 35.5, export_growth: 35.3, import_growth: 35.6 },
  { year: 2005, export_value: 116922, export_amount: 62648, import_amount: 54274, trade_balance: 8374, export_growth_rate: 22.4, export_growth: 27.6, import_growth: 16.9 }
]

// 获取文件列表数据
const fetchFileList = async (type) => {
  try {
    const res = await api.get('/data', {
      params: { type }
    })
    
    if (res.data.code === 200) {
      // 存储完整的文件信息（包含id, type, name, data字段）
      fileList.value = res.data.data || []
      // 提取name字段用于显示
      fileNames.value = res.data.data.map(item => item.name) || []
      
      console.log('获取到文件列表:', fileList.value)
      console.log('文件数量:', fileList.value.length)
      
      return res.data.data || []
    } else {
      ElMessage.error('获取文件列表失败')
      return []
    }
  } catch (error) {
    console.error('获取文件列表失败:', error)
    ElMessage.error('获取文件列表失败')
    return []
  }
}

// 处理文件数据（从已有的文件列表中获取）
const processFileData = (fileInfo) => {
  loading.value = true
  
  try {
    console.log('文件完整信息:', fileInfo)
    
    if (fileInfo && fileInfo.data) {
      try {
        // 将data字段转换为JSON并输出到控制台
        const jsonData = JSON.parse(fileInfo.data)
        console.log('文件数据 (JSON):', jsonData)
        console.log('文件基本信息:', {
          id: fileInfo.id,
          type: fileInfo.type,
          name: fileInfo.name
        })
        
        // 处理表格数据
        if (Array.isArray(jsonData)) {
          // 如果是数组，取第一个元素生成列配置
          if (jsonData.length > 0) {
            generateTableColumns(jsonData[0])
            tableData.value = jsonData
            console.log(`表格数据已更新，共 ${jsonData.length} 条记录`)
          } else {
            console.log('数据数组为空')
            tableColumns.value = []
            tableData.value = []
          }
        } else if (jsonData && typeof jsonData === 'object') {
          // 如果是对象，直接使用该对象生成列配置和数据
          generateTableColumns(jsonData)
          tableData.value = [jsonData]
          console.log('数据为对象格式，已转换为单行表格')
        } else {
          console.warn('数据格式不是数组或对象:', jsonData)
          tableColumns.value = []
          tableData.value = []
        }
      } catch (parseError) {
        console.error('解析JSON数据失败:', parseError)
        console.log('原始data字段内容:', fileInfo.data)
        console.log('data字段类型:', typeof fileInfo.data)
        ElMessage.error('数据格式错误，请检查控制台')
        
        // 如果data是空字符串，显示提示
        if (fileInfo.data === '') {
          console.log('文件data字段为空字符串')
          ElMessage.info('文件数据为空')
        }
        
        tableColumns.value = []
        tableData.value = []
      }
    } else {
      console.log('文件数据为空或无data字段')
      console.log('文件信息:', fileInfo)
      ElMessage.info('文件数据为空')
      tableColumns.value = []
      tableData.value = []
    }
  } finally {
    loading.value = false
  }
}

// 动态生成表格列配置
const generateTableColumns = (dataObj) => {
  if (!dataObj || typeof dataObj !== 'object') {
    tableColumns.value = []
    return
  }
  
  const keys = Object.keys(dataObj)
  console.log('表格列名:', keys)
  
  tableColumns.value = keys.map((key, index) => {
    const column = {
      prop: key,
      label: key,
      align: 'center',
      showOverflowTooltip: true
    }
    
    if (index === 0) {
      // 第一列固定在左侧，设置固定宽度
      column.fixed = 'left'
      column.width = 150
    } else {
      // 其他列设置固定宽度，确保横向滚动效果
      const labelLength = key.length
      if (labelLength > 10) {
        column.width = 150
      } else if (labelLength > 6) {
        column.width = 130
      } else {
        column.width = 120
      }
    }
    
    return column
  })
  
  console.log('生成的表格列配置:', tableColumns.value)
}

// 获取表格数据（保留作为备用）
const fetchTableData = async () => {
  if (!selectedFile.value || !selectedFile.value.filename) {
    return
  }
  
  loading.value = true
  try {
    // 这里可以调用其他表格数据接口
    // 暂时使用模拟数据
    await new Promise(resolve => setTimeout(resolve, 500))
    
    tableData.value = mockData
  } catch (error) {
    console.error('获取数据失败:', error)
    ElMessage.error('获取数据失败')
  } finally {
    loading.value = false
  }
}

// 导航菜单点击处理
const handleNavClick = async (item) => {
  selectedDataType.value = item
  selectedFile.value = null // 清空选中的文件
  fileListExpanded.value = true // 切换数据源时自动展开文件列表
  
  // 获取对应的文件列表
  await fetchFileList(item.type)
}

// 文件点击处理
const handleFileClick = async (filename) => {
  // 从完整文件列表中找到对应的文件信息
  const fileInfo = fileList.value.find(file => file.name === filename)
  
  if (!fileInfo) {
    ElMessage.error('找不到文件信息')
    return
  }
  
  // 收起文件列表
  fileListExpanded.value = false
  
  selectedFile.value = {
    id: fileInfo.id,
    label: fileInfo.name,
    filename: fileInfo.name,
    type: fileInfo.type,
    parentType: selectedDataType.value.type
  }
  
  // 直接处理已有的data数据
  processFileData(fileInfo)
}

// 切换文件列表展开状态
const toggleFileList = () => {
  fileListExpanded.value = !fileListExpanded.value
}

// 获取图标组件
const getIconComponent = (iconName) => {
  const iconMap = {
    home: Menu,
    ship: Files,
    building: Document,
    grid: Folder
  }
  return iconMap[iconName] || Document
}

// 移除分页处理函数

// 组件挂载时不需要获取初始数据，等待用户点击
onMounted(() => {
  // 不需要初始化加载数据
})
</script>

<template>
  <div class="raw-data-container">
    <!-- 页面标题 -->
    <div class="page-header">
      <h2>原始数据</h2>
    </div>

    <div class="content-wrapper">
      <!-- 左侧导航菜单 -->
      <div class="left-navigation">
        <el-card class="nav-card">
          <div class="nav-list">
            <div 
              v-for="item in navigationItems" 
              :key="item.id"
              :class="['nav-item', { 'active': selectedDataType && selectedDataType.id === item.id }]"
              @click="handleNavClick(item)"
            >
              <el-icon class="nav-icon">
                <component :is="getIconComponent(item.icon)" />
              </el-icon>
              <span class="nav-label">{{ item.label }}</span>
            </div>
          </div>
        </el-card>
      </div>

      <!-- 右侧内容区域 -->
      <div class="right-content">
        <!-- 文件列表区域 -->
        <div class="file-list-section" v-if="selectedDataType">
          <el-card class="file-card">
            <template #header>
              <div class="file-card-header">
                <div class="header-left">
                  <span>文件列表</span>
                  <el-tag type="info" size="small">{{ selectedDataType.label }}</el-tag>
                </div>
                <div class="header-right">
                  <el-button 
                    type="text" 
                    size="small" 
                    @click="toggleFileList"
                    class="toggle-btn"
                  >
                    <el-icon>
                      <ArrowUp v-if="fileListExpanded" />
                      <ArrowDown v-else />
                    </el-icon>
                    {{ fileListExpanded ? '收起' : '展开' }}
                  </el-button>
                </div>
              </div>
            </template>
            <transition name="file-list-transition">
              <div class="file-list" v-show="fileListExpanded">
                <div 
                  v-for="filename in fileNames" 
                  :key="filename"
                  :class="['file-item', { 'selected': selectedFile && selectedFile.filename === filename }]"
                  @click="handleFileClick(filename)"
                >
                  <el-icon class="file-icon">
                    <Document />
                  </el-icon>
                  <span class="file-name">{{ filename }}</span>
                </div>
                
                <div v-if="fileNames.length === 0" class="empty-files">
                  <el-empty description="暂无文件" :image-size="80" />
                </div>
              </div>
            </transition>
          </el-card>
        </div>

        <!-- 数据表格区域 -->
        <div class="table-section" v-if="selectedFile">
          <el-card class="table-card">
            <!-- 表格工具栏 -->
            <div class="table-toolbar">
              <div class="toolbar-left">
                <span class="selected-source" v-if="selectedFile">
                  当前文件：{{ selectedFile.label }}
                </span>
                <span v-else class="no-selection">
                  请选择数据源和文件
                </span>
              </div>
              <div class="toolbar-right">
                <span class="data-info">单位：亿元人民币</span>
              </div>
            </div>

            <!-- 数据表格 -->
            <div class="table-wrapper">
              <el-table
                :data="tableData"
                :loading="loading"
                border
                stripe
                class="data-table"
                :height="400"
                style="width: 100%"
              >
                <el-table-column
                  v-for="column in tableColumns"
                  :key="column.prop"
                  :prop="column.prop"
                  :label="column.label"
                  :width="column.width"
                  :min-width="column.minWidth"
                  :fixed="column.fixed"
                  :align="column.align"
                  show-overflow-tooltip
                />
                
                <!-- 如果没有列配置，显示提示 -->
                <template v-if="tableColumns.length === 0">
                  <el-table-column label="暂无数据" align="center" />
                </template>
              </el-table>
            </div>

          <!-- 移除分页组件，显示全部数据 -->
          </el-card>
        </div>

        <!-- 空状态提示 -->
        <div v-if="!selectedDataType" class="empty-state-main">
          <el-empty 
            description="请选择左侧数据源查看文件列表"
            :image-size="150"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.raw-data-container {
  padding: 20px;
  background-color: #f5f5f5;
  min-height: 100vh;

  .content-wrapper {
    display: flex;
    gap: 20px;
    /* height: calc(100vh - 120px); */
    height: 100vh;
    width: 100%;
    max-width: 100%;
  }
}

.page-header {
  margin-bottom: 20px;
  border-bottom: 1px solid #e4e7ed;
  padding-bottom: 12px;
}

.page-header h2 {
  margin: 0;
  color: #333;
  font-size: 18px;
  font-weight: normal;
}

/* 左侧导航样式 */
.left-navigation {
  width: 200px;
  flex-shrink: 0;
}

.nav-card {
  height: 100%;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  overflow: visible;
}

.nav-list {
  padding: 10px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 16px;
  margin: 4px 0;
  cursor: pointer;
  border-radius: 6px;
  transition: all 0.3s ease;
  border-left: 3px solid transparent;
}

.nav-item:hover {
  background-color: #f0f9ff;
  border-left-color: #409eff;
}

.nav-item.active {
  background-color: #e6f7ff;
  border-left-color: #409eff;
  color: #409eff;
}

.nav-icon {
  margin-right: 10px;
  font-size: 16px;
}

.nav-label {
  font-size: 14px;
  font-weight: 500;
}

/* 文件列表样式 */
.file-list-section {
  margin-bottom: 20px;
}

.file-card {
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  overflow: visible;
}

.file-card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.header-right {
  display: flex;
  align-items: center;
}

.toggle-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  color: #409eff;
  font-size: 13px;
  padding: 4px 8px;
  transition: all 0.3s ease;
}

.toggle-btn:hover {
  background-color: #f0f9ff;
  border-radius: 4px;
}

.file-list {
  max-height: 200px;
  overflow-y: auto;
}

.file-item {
  display: flex;
  align-items: center;
  padding: 8px 12px;
  margin: 2px 0;
  cursor: pointer;
  border-radius: 4px;
  transition: all 0.2s ease;
}

.file-item:hover {
  background-color: #f5f7fa;
}

.file-item.selected {
  background-color: #e6f7ff;
  color: #409eff;
}

.file-icon {
  margin-right: 8px;
  color: #67c23a;
}

.file-name {
  font-size: 13px;
}

.empty-files {
  padding: 20px;
  text-align: center;
}

/* 文件列表展开收起动画 */
.file-list-transition-enter-active,
.file-list-transition-leave-active {
  transition: all 0.3s ease;
  max-height: 400px;
  overflow: hidden;
}

.file-list-transition-enter-from,
.file-list-transition-leave-to {
  max-height: 0;
  opacity: 0;
  transform: translateY(-10px);
}

.file-list-transition-enter-to,
.file-list-transition-leave-from {
  max-height: 400px;
  opacity: 1;
  transform: translateY(0);
}

/* 右侧内容区域样式 */
.right-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-width: 0;
}

.table-section {
  flex: 1;
  min-height: 0;
  min-width: 0;
  display: flex;
  flex-direction: column;
}

.table-card {
  flex: 1;
  display: flex;
  flex-direction: column;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  min-height: 0;
  overflow: visible;
}

.empty-state-main {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #fafafa;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.table-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  padding: 10px 0;
  border-bottom: 1px solid #ebeef5;
}

.selected-source {
  font-size: 14px;
  color: #606266;
  font-weight: 500;
}

.data-info {
  font-size: 14px;
  color: #909399;
}

.no-selection {
  font-size: 14px;
  color: #c0c4cc;
  font-style: italic;
}

/* 表格容器样式 */
.table-wrapper {
  width: 100%;
  max-width: 100%;
  overflow-x: auto;
  overflow-y: visible;
  border: 1px solid #ebeef5;
  border-radius: 4px;
  box-sizing: border-box;
  flex: 1;
  min-height: 0;
}

/* 表格样式 */
.data-table {
  width: max-content;
  min-width: 100%;
  max-width: none;
}

.data-table :deep(.el-table) {
  border: none;
  width: max-content;
  min-width: 100%;
}

.data-table :deep(.el-table__body-wrapper) {
  max-height: 320px;
  overflow-y: auto;
}

.data-table :deep(.el-table__header-wrapper) {
  overflow: visible;
}

.data-table :deep(.el-table__header) {
  background-color: #fafafa;
}

.data-table :deep(.el-table__header th) {
  background-color: #fafafa;
  color: #333;
  font-weight: 600;
  white-space: nowrap;
  border-right: 1px solid #ebeef5;
}

.data-table :deep(.el-table__body tr:hover > td) {
  background-color: #f5f7fa;
}

.data-table :deep(.el-table__body td) {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  border-right: 1px solid #ebeef5;
}

/* 表格容器滚动条样式 */
.table-wrapper::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

.table-wrapper::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 4px;
}

.table-wrapper::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 4px;
}

.table-wrapper::-webkit-scrollbar-thumb:hover {
  background: #a8a8a8;
}

.table-wrapper::-webkit-scrollbar-corner {
  background: #f1f1f1;
}

/* 表格内部竖向滚动条样式 */
.data-table :deep(.el-table__body-wrapper)::-webkit-scrollbar {
  width: 8px;
}

.data-table :deep(.el-table__body-wrapper)::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 4px;
}

.data-table :deep(.el-table__body-wrapper)::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 4px;
}

.data-table :deep(.el-table__body-wrapper)::-webkit-scrollbar-thumb:hover {
  background: #a8a8a8;
}

/* 数值颜色样式 */
.negative {
  color: #f56c6c;
}

.positive {
  color: #67c23a;
}

/* 空状态样式 */
.empty-state {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 400px;
  background-color: #fafafa;
  border-radius: 8px;
}

/* 分页样式 */
.pagination-wrapper {
  display: flex;
  justify-content: center;
  padding: 20px 0;
  border-top: 1px solid #ebeef5;
  margin-top: 16px;
  flex-shrink: 0;
  background: #fff;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .content-wrapper {
    flex-direction: column;
    height: auto;
  }
  
  .left-navigation {
    width: 100%;
    margin-bottom: 20px;
  }
  
  .nav-card {
    height: auto;
  }
  
  .nav-list {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }
  
  .nav-item {
    flex: 1;
    min-width: 120px;
    justify-content: center;
  }
}

@media (max-width: 768px) {
  .raw-data-container {
    padding: 10px;
  }
  
  .table-toolbar {
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;
  }
  
  .data-table {
    font-size: 12px;
  }
  
  .nav-item {
    padding: 8px 12px;
    font-size: 13px;
  }
}
</style>