<script setup>
import { ref, onMounted } from "vue";
import { ElMessage } from "element-plus";
import api from "@/utils/request";

// 数据来源国家统计饼图配置
const pieChartOption = ref({
  title: {
    text: "数据条目国家覆盖比例",
    left: 20,
    top: 20,
    textStyle: {
      fontSize: 16,
      fontWeight: "bold",
    },
  },
  tooltip: {
    trigger: "item",
    formatter: "{a} <br/>{b}: {c} ({d}%)",
  },
  legend: {
    orient: "horizontal",
    top: 50,
    left: 20,
    itemWidth: 12,
    itemHeight: 12,
    textStyle: {
      fontSize: 12,
    },
  },
  series: [
    {
      name: "数据来源统计",
      type: "pie",
      radius: ["30%", "60%"],
      center: ["50%", "60%"],
      data: [],
      label: {
        show: true,
        position: "outside",
        formatter: "{b}\n{c}",
      },
      emphasis: {
        itemStyle: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: "rgba(0, 0, 0, 0.5)",
        },
      },
    },
  ],
});

// 数据源类型/数据数量柱状图配置
const sourceBarChartOption = ref({
  title: {
    text: "数据源类型/数据数量",
    left: 20,
    top: 20,
    textStyle: {
      fontSize: 16,
      fontWeight: "bold",
    },
  },
  tooltip: {
    trigger: "axis",
    axisPointer: {
      type: "shadow",
    },
  },
  grid: {
    left: "8%",
    right: "4%",
    bottom: "15%",
    top: "20%",
    containLabel: true,
  },
  xAxis: {
    type: "category",
    data: [],
    axisLabel: {
      rotate: 0,
      fontSize: 12,
    },
  },
  yAxis: {
    type: "value",
    axisLabel: {
      fontSize: 12,
    },
  },
  series: [
    {
      name: "数量",
      type: "bar",
      data: [],
      itemStyle: {
        color: "#5B9BD5",
      },
      barWidth: "40%",
    },
  ],
});

// 数据类型柱状图配置
const dataTypeBarChartOption = ref({
  tooltip: {
    trigger: "axis",
    axisPointer: {
      type: "shadow",
    },
  },
  grid: {
    left: "8%",
    right: "4%",
    bottom: "15%",
    top: "10%",
    containLabel: true,
  },
  xAxis: {
    type: "category",
    data: [],
    axisLabel: {
      rotate: 0,
      fontSize: 12,
    },
  },
  yAxis: {
    type: "value",
    axisLabel: {
      fontSize: 12,
    },
  },
  series: [
    {
      name: "数量",
      type: "bar",
      data: [],
      itemStyle: {
        color: "#5B9BD5",
      },
      barWidth: "40%",
    },
  ],
});

// 颜色配置
const colors = [
  "#1f77b4",
  "#ff7f0e",
  "#2ca02c",
  "#d62728",
  "#9467bd",
  "#8c564b",
  "#e377c2",
  "#7f7f7f",
  "#bcbd22",
  "#17becf",
];

// 弹窗相关状态
const dialogVisible = ref(false);
const dialogTitle = ref("");
const tableData = ref([]);
const currentType = ref(null);
const loading = ref(false);

// 获取数据概览数据
const getOverviewData = async () => {
  try {
    const res = await api({ url: "/save/chart", method: "get" });
    if (res.data.code === 200) {
      const data = res.data.data;

      // 更新饼图数据
      updatePieChart(data.circleChart);

      // 更新数据源类型柱状图
      updateSourceBarChart(data.barChart1);

      // 更新数据类型柱状图
      updateDataTypeBarChart(data.barChart2);
    }
  } catch (error) {
    console.error("获取数据概览失败:", error);
  }
};

// 更新饼图数据
const updatePieChart = (countryData) => {
  const pieData = countryData.map((item, index) => ({
    value: item.count,
    name: item.name,
    itemStyle: { color: colors[index % colors.length] },
  }));

  pieChartOption.value.series[0].data = pieData;
};

// 更新数据源类型柱状图
const updateSourceBarChart = (sourceData) => {
  const categories = sourceData.map((item) => item.name);
  const values = sourceData.map((item) => item.count);

  sourceBarChartOption.value.xAxis.data = categories;
  sourceBarChartOption.value.series[0].data = values;
};

// 更新数据类型柱状图
const updateDataTypeBarChart = (dataTypeData) => {
  const categories = dataTypeData.map((item) => item.name);
  const values = dataTypeData.map((item) => item.count);

  dataTypeBarChartOption.value.xAxis.data = categories;
  dataTypeBarChartOption.value.series[0].data = values;
};

// 根据地区获取数据源列表
const getDataSourceListByCity = async (country) => {
  loading.value = true;
  try {
    const params = {
      pageNum: 1,
      pageSize: 1000,
      country: country,
    };
    const res = await api({ url: "/news/list", method: "get", params });
    if (res.data.code === 200) {
      tableData.value = res.data?.data || [];
    } else {
      ElMessage.error("获取数据失败");
      tableData.value = [];
    }
  } catch (error) {
    console.error("获取数据源列表失败:", error);
    ElMessage.error("获取数据失败");
    tableData.value = [];
  } finally {
    loading.value = false;
  }
};

// 饼图点击事件处理（按国家/地区打开弹窗）
const handlePieClick = (params) => {
  console.log(params);
  const clickedRegion = params.name;
  currentType.value = null;
  dialogTitle.value = `${clickedRegion} - 数据源列表`;
  dialogVisible.value = true;
  getDataSourceListByCity(clickedRegion);
};

onMounted(() => {
  // 组件加载后获取数据
  getOverviewData();
});
</script>

<template>
  <div class="overview-container">
    <div class="overview-title">
      <h1>数据概览</h1>
    </div>

    <div class="charts-container">
      <!-- 上排：饼图和柱状图 -->
      <div class="charts-row">
        <!-- 左侧饼图 -->
        <el-card class="chart-card pie-card">
          <v-chart
            :option="pieChartOption"
            style="height: 400px"
          />
        </el-card>

        <!-- 右侧柱状图 -->
        <el-card class="chart-card bar-card">
          <v-chart :option="sourceBarChartOption" style="height: 400px" />
        </el-card>
      </div>

      <!-- 下排：数据类型柱状图 -->
      <div class="charts-row">
        <el-card class="chart-card-full">
          <v-chart :option="dataTypeBarChartOption" style="height: 350px" />
        </el-card>
      </div>
    </div>

    <!-- 数据源弹窗 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogTitle"
      width="80%"
      top="5vh"
    >
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        height="500"
        v-loading="loading"
      >
        <el-table-column prop="country" label="国家/地区" width="150" />
        <el-table-column prop="name" label="数据源" min-width="200" />
      </el-table>

      <!-- 数据统计 -->
      <div style="margin-top: 16px; text-align: center; color: #606266">
        共 {{ tableData.length }} 条数据
      </div>
    </el-dialog>
  </div>
</template>

<style scoped>
.overview-container {
  padding: 20px;
  background-color: #f5f5f5;
  min-height: 100vh;
}

.overview-title {
  margin-bottom: 20px;
  text-align: left;
  border-bottom: 1px solid #e4e7ed;
  padding-bottom: 12px;
}

.overview-title h1 {
  margin: 0;
  color: #333;
  font-size: 18px;
  font-weight: normal;
}

.charts-container {
  max-width: 1400px;
  margin: 0 auto;
}

.charts-row {
  display: flex;
  gap: 20px;
  margin-bottom: 20px;
}

.chart-card {
  flex: 1;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  border-radius: 8px;
}

.pie-card {
  flex: 0 0 48%;
}

.bar-card {
  flex: 0 0 48%;
}

.chart-card-full {
  width: 100%;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  border-radius: 8px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .charts-row {
    flex-direction: column;
  }

  .pie-card,
  .bar-card {
    flex: 1;
  }

  .overview-container {
    padding: 10px;
  }
}
</style>
