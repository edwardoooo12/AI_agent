<template>
  <div class="card-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>导入数据</span>
        </div>
      </template>

      <div class="form-container">
        <!-- 数据路径输入 -->
        <div class="form-section with-background">
          <div class="form-item">
            <label class="form-label">数据路径</label>
            <div class="form-content">
              <el-input
                v-model="dataPath"
                placeholder="请输入数据文件路径，如：/path/to/data.xlsx"
                style="width: 100%"
              />
            </div>
          </div>
        </div>

        <!-- 选择数据源 -->
        <div class="form-section with-background">
          <div class="form-item">
            <label class="form-label">数据源</label>
            <div class="form-content">
              <span
                v-if="selectedDataSource"
                class="selected-source"
                @click="showDataSourceDialog = true"
              >
                已选择：{{ selectedDataSource.news }}
                <span class="selected-sections"
                  >（{{ selectedDataSource.sections?.join("、") }}）</span
                >
              </span>
              <div v-else @click="showDataSourceDialog = true">
                请选择数据源
              </div>
            </div>
          </div>
        </div>

        <!-- 选择日期范围 -->
        <div class="form-section with-background">
          <div class="form-item">
            <label class="form-label">时间范围</label>
            <div class="form-content">
              <el-date-picker
                v-model="dateRange"
                type="daterange"
                range-separator="-"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                style="width: 100%"
              />
            </div>
          </div>
        </div>

        <!-- 快捷时间选择 -->
        <div class="form-item">
          <label class="form-label"></label>
          <div class="form-content">
            <div class="time-shortcuts">
              <el-button
                v-for="shortcut in timeShortcuts"
                :key="shortcut.text"
                size="small"
                @click="selectTimeShortcut(shortcut)"
                :type="isShortcutSelected(shortcut) ? 'primary' : 'default'"
              >
                {{ shortcut.text }}
              </el-button>
            </div>
          </div>
        </div>

        <!-- 开始导入按钮 -->
        <div class="form-section">
          <div class="form-item">
            <div class="form-content">
              <el-button
                type="primary"
                @click="startImport"
                :loading="importing"
                :disabled="!canStartImport"
                size="large"
                class="import-btn"
              >
                {{ importing ? "导入中..." : "开始导入" }}
              </el-button>
            </div>
          </div>
        </div>
      </div>
    </el-card>

    <!-- 数据源选择对话框组件 -->
    <DataSourceSelectDialog
      v-model="showDataSourceDialog"
      @confirm="handleDataSourceConfirm"
    />
  </div>
</template>

<script setup>
import { ref, computed } from "vue";
import { ElMessage } from "element-plus";
import { Setting } from "@element-plus/icons-vue";
import api from "@/utils/request";
import DataSourceSelectDialog from "@/components/DataSourceSelectDialog.vue";
import {
  TIME_SHORTCUTS,
  rangeForShortcut,
  isShortcutActive,
} from "@/utils/dateShortcuts";

// 响应式数据
const importing = ref(false);
const dataPath = ref("");
const showDataSourceDialog = ref(false);
const selectedDataSource = ref(null);
const dateRange = ref([]);

// 时间快捷选项（公用）
const timeShortcuts = ref(TIME_SHORTCUTS);

// 计算属性
const canStartImport = computed(() => {
  return (
    dataPath.value.trim() !== "" &&
    selectedDataSource.value &&
    dateRange.value &&
    dateRange.value.length === 2
  );
});

// 方法
const handleDataSourceConfirm = (result) => {
  selectedDataSource.value = result;
};

// 选择快捷时间范围
const selectTimeShortcut = (shortcut) => {
  dateRange.value = rangeForShortcut(shortcut);
};

// 判断快捷项是否被选中
const isShortcutSelected = (shortcut) => {
  return isShortcutActive(dateRange.value, shortcut);
};

const startImport = async () => {
  if (!canStartImport.value) {
    ElMessage.warning("请完善导入条件（数据路径、数据源、日期范围）");
    return;
  }

  importing.value = true;

  try {
    // 根据记忆中的参数构造规范，构建导入参数
    const importParams = {
      importPath: dataPath.value.trim(),
      overwrite: true,
      countryId: selectedDataSource.value.countryId || 0,
      newsId: selectedDataSource.value.id || 0,
      layoutIds: selectedDataSource.value.sectionIds || ["0"], // 保持字符串数组格式
    };

    // 调用导入接口
    const res = await api({
      url: "/importFile",
      method: "post",
      data: importParams,
    });

    if (res.data.code === 200) {
      ElMessage.success("数据导入成功！");

      // 清空表单
      dataPath.value = "";
      selectedDataSource.value = null;
      dateRange.value = [];
    } else {
      ElMessage.error(res.data.msg || "导入失败");
    }
  } catch (error) {
    console.error("导入失败:", error);
    ElMessage.error("导入失败，请重试");
  } finally {
    importing.value = false;
  }
};
</script>

<style scoped lang="scss">
.card-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  justify-content: center;
  margin-bottom: 24px;
}

.form-container {
  max-width: 1067px;
  margin: 0 auto;
}

.form-item {
  margin-bottom: 18px;
  display: flex;
  align-items: center;
  height: 40px;
}

.form-label {
  width: 144px;
  margin-right: 20px;
  line-height: 1.4;
  font-family: "PingFang SC", sans-serif;
  font-weight: 500;
  font-size: 16px;
  color: #000000;
  flex-shrink: 0;
}

.selected-source {
  color: #67c23a;
  font-size: 14px;
  font-family: "PingFang SC", sans-serif;
  cursor: pointer;
}

.selected-sections {
  color: #909399;
  font-size: 12px;
}

.import-btn {
  min-width: 120px;
  height: 40px;
}

.time-shortcuts {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  :deep(.el-button) {
    & + .el-button {
      margin-left: 0;
    }
  }
}
</style>
