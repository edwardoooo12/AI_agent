<template>
  <div class="card-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>选择时间范围、新闻源进行批量导出</span>
        </div>
      </template>

      <div class="form-container">
        <!-- 选择数据源 -->
        <div class="form-section with-background">
          <div class="form-item">
            <label class="form-label">数据源</label>
            <div class="form-content">
              <span
                v-if="selectedDataSource"
                class="selected-source"
                @click="showDataSourceDialog = true"
              >
                已选择：{{ selectedDataSource.news }}
                <span class="selected-sections"
                  >（{{ selectedDataSource.sections?.join("、") }}）</span
                >
              </span>
              <div v-else @click="showDataSourceDialog = true">
                请选择数据源
              </div>
            </div>
          </div>
        </div>

        <!-- 选择日期范围 -->
        <div class="form-section with-background">
          <div class="form-item">
            <label class="form-label">时间范围</label>
            <div class="form-content">
              <el-date-picker
                v-model="dateRange"
                type="daterange"
                range-separator="-"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                style="width: 100%"
              />
            </div>
          </div>
        </div>

        <!-- 快捷时间选择 -->
        <div class="form-item">
          <label class="form-label"></label>
          <div class="form-content">
            <div class="time-shortcuts">
              <el-button
                v-for="shortcut in timeShortcuts"
                :key="shortcut.text"
                size="small"
                @click="selectTimeShortcut(shortcut)"
                :type="isShortcutSelected(shortcut) ? 'primary' : 'default'"
              >
                {{ shortcut.text }}
              </el-button>
            </div>
          </div>
        </div>

        <!-- 确定导出位置 -->
        <div class="form-section with-background">
          <div class="form-item">
            <label class="form-label">导出位置</label>
            <div class="form-content">
              <div class="export-location">
                <el-input
                  v-model="exportPath"
                  placeholder="请输入导出路径"
                  class="path-input"
                  readonly
                  @click="selectExportPath"
                >
                  <template #suffix>
                    <el-icon class="folder-icon" @click="selectExportPath">
                      <Folder />
                    </el-icon>
                  </template>
                </el-input>

                <!-- 路径选择提示 -->
                <div class="path-tip" v-if="showPathTip">
                  <div class="tip-header">
                    <el-icon><Warning /></el-icon>
                    <span>请选择导出路径</span>
                  </div>
                  <div class="tip-content">
                    请先设置导出文件保存路径， 为了方便查看建议进行保存路径设置
                  </div>
                  <div class="tip-actions">
                    <el-button size="small" @click="closeTip">取消</el-button>
                    <el-button
                      size="small"
                      type="primary"
                      @click="selectExportPath"
                      >设置</el-button
                    >
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 开始导出按钮 -->
        <div class="form-section">
          <div class="form-item">
            <div class="form-content">
              <el-button
                type="primary"
                @click="startExport"
                :loading="exporting"
                :disabled="!canStartExport"
                size="large"
                class="export-btn"
              >
                {{ exporting ? "导出中..." : "开始导出" }}
              </el-button>
            </div>
          </div>
        </div>
      </div>
    </el-card>

    <!-- 数据源选择对话框组件 -->
    <DataSourceSelectDialog
      v-model="showDataSourceDialog"
      @confirm="handleDataSourceConfirm"
    />

    <!-- 路径选择对话框 -->
    <el-dialog v-model="showPathDialog" title="选择导出路径" width="500px">
      <el-input
        v-model="tempExportPath"
        placeholder="请输入导出路径"
        style="width: 100%"
      />
      <div class="path-suggestions">
        <h5>常用路径：</h5>
        <div class="suggestion-list">
          <el-button
            v-for="path in commonPaths"
            :key="path"
            size="small"
            @click="selectCommonPath(path)"
            class="path-suggestion"
          >
            {{ path }}
          </el-button>
        </div>
      </div>
      <template #footer>
        <el-button @click="showPathDialog = false">取消</el-button>
        <el-button type="primary" @click="confirmPath">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, reactive } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { Folder, Warning } from "@element-plus/icons-vue";
import api from "@/utils/request";
import DataSourceSelectDialog from "@/components/DataSourceSelectDialog.vue";
import { Setting } from "@element-plus/icons-vue";
import {
  TIME_SHORTCUTS,
  rangeForShortcut,
  isShortcutActive,
} from "@/utils/dateShortcuts";

// 响应式数据
const showDataSourceDialog = ref(false);
const showPathDialog = ref(false);
const showPathTip = ref(false);
const selectedDataSource = ref(null);
const dateRange = ref([]);
const exportPath = ref("");
const tempExportPath = ref("");
const exporting = ref(false);

// 时间快捷选项（公用）
const timeShortcuts = ref(TIME_SHORTCUTS);

// 常用路径
const commonPaths = ref([
  "/Users/用户名/Downloads",
  "/Users/用户名/Desktop",
  "/Users/用户名/Documents/数据导出",
  "D:\\Downloads",
  "D:\\Documents\\DataExport",
]);

// 计算属性
const canStartExport = computed(() => {
  return (
    selectedDataSource.value &&
    dateRange.value &&
    dateRange.value.length === 2 &&
    exportPath.value
  );
});

// 方法
const handleDataSourceConfirm = (result) => {
  selectedDataSource.value = result;
};

const selectExportPath = () => {
  showPathTip.value = false;
  tempExportPath.value = exportPath.value;
  showPathDialog.value = true;
};

const selectCommonPath = (path) => {
  tempExportPath.value = path;
};

const confirmPath = () => {
  if (!tempExportPath.value.trim()) {
    ElMessage.warning("请输入导出路径");
    return;
  }
  exportPath.value = tempExportPath.value;
  showPathDialog.value = false;
  ElMessage.success("导出路径设置成功");
};

const closeTip = () => {
  showPathTip.value = false;
};

const startExport = async () => {
  if (!canStartExport.value) {
    if (!exportPath.value) {
      showPathTip.value = true;
      return;
    }
    ElMessage.warning("请完善导出条件");
    return;
  }

  exporting.value = true;
  try {
    // 根据记忆中的参数构造规范，构建导出参数
    const exportParams = {
      countryId: selectedDataSource.value.countryId || 0,
      newsId: selectedDataSource.value.id || 0,
      layoutIds: selectedDataSource.value.sectionIds || [], // 保持字符串数组格式
      startTime: dateRange.value[0],
      endTime: dateRange.value[1],
      exportPath: exportPath.value,
    };

    // 调用/moveFile接口
    const res = await api({
      url: "/moveFile",
      method: "post",
      data: exportParams,
    });

    if (res.data.code === 200) {
      ElMessage.success("数据导出成功！");
    } else {
      ElMessage.error(res.data.msg || "导出失败");
    }
  } catch (error) {
    console.error("导出失败:", error);
    ElMessage.error("导出失败，请重试");
  } finally {
    exporting.value = false;
  }
};

// 选择快捷时间范围
const selectTimeShortcut = (shortcut) => {
  dateRange.value = rangeForShortcut(shortcut);
};

// 判断快捷项是否被选中
const isShortcutSelected = (shortcut) => {
  const bol = isShortcutActive(dateRange.value, shortcut);
  console.log(
    "%c [ bol ]-293-「DataExport」",
    "font-size:15px; background:#4d8a6a; color:#91ceae;",
    bol
  );
  return bol;
};

// 生命周期
// onMounted(() => {
//   // 不再需要在此初始化，组件内部处理
// })
</script>

<style scoped lang="scss">
.card-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  justify-content: center;
  margin-bottom: 24px;
}

.form-container {
  max-width: 1067px;
  margin: 0 auto;
}

.form-item {
  margin-bottom: 18px;
  display: flex;
  align-items: center;
  height: 40px;
}

.form-label {
  width: 144px;
  margin-right: 20px;
  line-height: 1.4;
  font-family: "PingFang SC", sans-serif;
  font-weight: 500;
  font-size: 16px;
  color: #000000;
  flex-shrink: 0;
}

.selected-source {
  color: #67c23a;
  font-size: 14px;
  font-family: "PingFang SC", sans-serif;
  cursor: pointer;
}

.selected-sections {
  color: #909399;
  font-size: 12px;
}

.export-location {
  position: relative;
  width: 100%;
}

.path-input {
  width: 100%;
  cursor: pointer;
}

.folder-icon {
  cursor: pointer;
  color: #409eff;
}

.path-tip {
  position: absolute;
  top: 45px;
  left: 0;
  background: #fff;
  border: 1px solid #e4e7ed;
  border-radius: 6px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 16px;
  width: 280px;
  z-index: 10;
}

.tip-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
  font-weight: 600;
  color: #e6a23c;
}

.tip-content {
  font-size: 14px;
  color: #606266;
  line-height: 1.6;
  margin-bottom: 12px;
}

.tip-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

.export-btn {
  min-width: 120px;
  height: 40px;
}

.path-suggestions {
  margin-top: 16px;
}

.path-suggestions h5 {
  margin: 0 0 12px 0;
  color: #606266;
  font-size: 14px;
}

.suggestion-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  :deep(.el-button) {
    & + .el-button {
      margin-left: 0;
    }
  }
}

.path-suggestion {
  justify-content: flex-start;
  text-align: left;
  color: #606266;
}

.time-shortcuts {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

:deep(.el-table__row) {
  cursor: pointer;
}

:deep(.el-table__row:hover) {
  background-color: #f5f7fa;
}

:deep(.el-input__inner) {
  cursor: pointer;
}
</style>
