{
    "code": 200,
    "msg": "success",
    "data": {
        "chart1": {
            "countries": [
                "美国",
                "韩国",
                "台湾地区",
                "中国",
                "日本"
            ],
            "jqCount": 4888,
            "countryDataCount": {
                "美国": {
                    "WQ装备": 823,
                    "JS设备": 2873,
                    "编制结构": 154
                },
                "韩国": {
                    "WQ装备": 863,
                    "JS设备": 2382,
                    "编制结构": 145
                },
                "台湾地区": {
                    "WQ装备": 829,
                    "JS设备": 1350,
                    "编制结构": 137
                },
                "中国": {
                    "WQ装备": 808,
                    "JS设备": 2099,
                    "编制结构": 141
                },
                "日本": {
                    "WQ装备": 844,
                    "JS设备": 2172,
                    "编制结构": 144
                }
            }
        },
        "chart2": [
            {
                "id": 1,
                "name": "中国",
                "country": "中国",
                "children": [
                    {
                        "id": 2,
                        "name": "东部战区",
                        "country": "中国",
                        "children": [
                            {
                                "id": 3,
                                "name": "海军",
                                "country": "中国",
                                "children": [
                                    {
                                        "id": 4,
                                        "name": "海军13旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 5,
                                        "name": "海军48旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 6,
                                        "name": "海军26旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 7,
                                        "name": "海军49旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 8,
                                        "name": "海军1旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 9,
                                        "name": "海军43旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 10,
                                        "name": "海军4旅",
                                        "country": "中国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 11,
                                "name": "陆军",
                                "country": "中国",
                                "children": [
                                    {
                                        "id": 12,
                                        "name": "陆军13旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 13,
                                        "name": "陆军46旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 14,
                                        "name": "陆军7旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 15,
                                        "name": "陆军2旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 16,
                                        "name": "陆军5旅",
                                        "country": "中国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 17,
                                "name": "空军",
                                "country": "中国",
                                "children": [
                                    {
                                        "id": 18,
                                        "name": "空军5旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 19,
                                        "name": "空军49旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 20,
                                        "name": "空军36旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 22,
                                        "name": "空军3旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 23,
                                        "name": "空军42旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 24,
                                        "name": "空军9旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 25,
                                        "name": "空军25旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 26,
                                        "name": "空军39旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 27,
                                        "name": "空军34旅",
                                        "country": "中国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 28,
                                "name": "火箭军",
                                "country": "中国",
                                "children": [
                                    {
                                        "id": 29,
                                        "name": "火箭军31旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 30,
                                        "name": "火箭军20旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 31,
                                        "name": "火箭军8旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 32,
                                        "name": "火箭军41旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 33,
                                        "name": "火箭军34旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 34,
                                        "name": "火箭军27旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 35,
                                        "name": "火箭军7旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 37,
                                        "name": "火箭军14旅",
                                        "country": "中国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 38,
                                "name": "战略支援部队",
                                "country": "中国",
                                "children": [
                                    {
                                        "id": 39,
                                        "name": "战略支援部队37旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 40,
                                        "name": "战略支援部队42旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 41,
                                        "name": "战略支援部队29旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 42,
                                        "name": "战略支援部队18旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 43,
                                        "name": "战略支援部队7旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 44,
                                        "name": "战略支援部队34旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 45,
                                        "name": "战略支援部队24旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 46,
                                        "name": "战略支援部队25旅",
                                        "country": "中国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 47,
                                "name": "联合指挥部",
                                "country": "中国",
                                "children": [
                                    {
                                        "id": 48,
                                        "name": "联合指挥部2旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 49,
                                        "name": "联合指挥部16旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 50,
                                        "name": "联合指挥部23旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 51,
                                        "name": "联合指挥部12旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 52,
                                        "name": "联合指挥部40旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 53,
                                        "name": "联合指挥部7旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 54,
                                        "name": "联合指挥部43旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 55,
                                        "name": "联合指挥部15旅",
                                        "country": "中国",
                                        "children": null
                                    },
                                    {
                                        "id": 56,
                                        "name": "联合指挥部10旅",
                                        "country": "中国",
                                        "children": null
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "id": 58,
                        "name": "南部战区",
                        "country": "中国",
                        "children": null
                    },
                    {
                        "id": 102,
                        "name": "西部战区",
                        "country": "中国",
                        "children": null
                    },
                    {
                        "id": 154,
                        "name": "北部战区",
                        "country": "中国",
                        "children": null
                    }
                ]
            },
            {
                "id": 207,
                "name": "美国",
                "country": "美国",
                "children": [
                    {
                        "id": 208,
                        "name": "东部战区",
                        "country": "美国",
                        "children": [
                            {
                                "id": 209,
                                "name": "海军",
                                "country": "美国",
                                "children": [
                                    {
                                        "id": 210,
                                        "name": "海军17旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 211,
                                        "name": "海军27旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 212,
                                        "name": "海军31旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 213,
                                        "name": "海军19旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 215,
                                        "name": "海军3旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 216,
                                        "name": "海军15旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 217,
                                        "name": "海军35旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 218,
                                        "name": "海军11旅",
                                        "country": "美国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 219,
                                "name": "陆军",
                                "country": "美国",
                                "children": [
                                    {
                                        "id": 220,
                                        "name": "陆军20旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 221,
                                        "name": "陆军12旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 222,
                                        "name": "陆军50旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 223,
                                        "name": "陆军18旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 224,
                                        "name": "陆军23旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 225,
                                        "name": "陆军49旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 226,
                                        "name": "陆军28旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 227,
                                        "name": "陆军24旅",
                                        "country": "美国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 229,
                                "name": "空军",
                                "country": "美国",
                                "children": [
                                    {
                                        "id": 230,
                                        "name": "空军44旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 231,
                                        "name": "空军49旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 232,
                                        "name": "空军21旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 233,
                                        "name": "空军18旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 234,
                                        "name": "空军13旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 235,
                                        "name": "空军34旅",
                                        "country": "美国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 236,
                                "name": "火箭军",
                                "country": "美国",
                                "children": [
                                    {
                                        "id": 237,
                                        "name": "火箭军5旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 238,
                                        "name": "火箭军11旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 239,
                                        "name": "火箭军26旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 240,
                                        "name": "火箭军35旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 241,
                                        "name": "火箭军40旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 242,
                                        "name": "火箭军1旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 243,
                                        "name": "火箭军38旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 244,
                                        "name": "火箭军24旅",
                                        "country": "美国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 245,
                                "name": "战略支援部队",
                                "country": "美国",
                                "children": [
                                    {
                                        "id": 246,
                                        "name": "战略支援部队21旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 247,
                                        "name": "战略支援部队2旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 248,
                                        "name": "战略支援部队19旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 249,
                                        "name": "战略支援部队47旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 250,
                                        "name": "战略支援部队26旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 251,
                                        "name": "战略支援部队7旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 252,
                                        "name": "战略支援部队15旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 253,
                                        "name": "战略支援部队36旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 254,
                                        "name": "战略支援部队34旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 255,
                                        "name": "战略支援部队24旅",
                                        "country": "美国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 256,
                                "name": "联合指挥部",
                                "country": "美国",
                                "children": [
                                    {
                                        "id": 257,
                                        "name": "联合指挥部13旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 258,
                                        "name": "联合指挥部3旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 259,
                                        "name": "联合指挥部9旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 260,
                                        "name": "联合指挥部35旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 261,
                                        "name": "联合指挥部19旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 262,
                                        "name": "联合指挥部20旅",
                                        "country": "美国",
                                        "children": null
                                    },
                                    {
                                        "id": 263,
                                        "name": "联合指挥部23旅",
                                        "country": "美国",
                                        "children": null
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "id": 264,
                        "name": "南部战区",
                        "country": "美国",
                        "children": null
                    },
                    {
                        "id": 314,
                        "name": "西部战区",
                        "country": "美国",
                        "children": null
                    },
                    {
                        "id": 362,
                        "name": "北部战区",
                        "country": "美国",
                        "children": null
                    }
                ]
            },
            {
                "id": 415,
                "name": "日本",
                "country": "日本",
                "children": [
                    {
                        "id": 416,
                        "name": "东部战区",
                        "country": "日本",
                        "children": [
                            {
                                "id": 417,
                                "name": "海军",
                                "country": "日本",
                                "children": [
                                    {
                                        "id": 418,
                                        "name": "海军13旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 419,
                                        "name": "海军32旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 420,
                                        "name": "海军45旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 421,
                                        "name": "海军24旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 422,
                                        "name": "海军25旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 423,
                                        "name": "海军23旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 424,
                                        "name": "海军1旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 425,
                                        "name": "海军10旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 426,
                                        "name": "海军5旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 427,
                                        "name": "海军34旅",
                                        "country": "日本",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 428,
                                "name": "陆军",
                                "country": "日本",
                                "children": [
                                    {
                                        "id": 429,
                                        "name": "陆军33旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 430,
                                        "name": "陆军13旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 431,
                                        "name": "陆军50旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 432,
                                        "name": "陆军1旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 433,
                                        "name": "陆军25旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 434,
                                        "name": "陆军29旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 435,
                                        "name": "陆军43旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 436,
                                        "name": "陆军27旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 437,
                                        "name": "陆军35旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 438,
                                        "name": "陆军44旅",
                                        "country": "日本",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 439,
                                "name": "空军",
                                "country": "日本",
                                "children": [
                                    {
                                        "id": 440,
                                        "name": "空军11旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 441,
                                        "name": "空军42旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 443,
                                        "name": "空军45旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 444,
                                        "name": "空军12旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 445,
                                        "name": "空军27旅",
                                        "country": "日本",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 446,
                                "name": "火箭军",
                                "country": "日本",
                                "children": [
                                    {
                                        "id": 447,
                                        "name": "火箭军4旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 448,
                                        "name": "火箭军7旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 449,
                                        "name": "火箭军13旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 450,
                                        "name": "火箭军18旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 451,
                                        "name": "火箭军31旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 452,
                                        "name": "火箭军8旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 453,
                                        "name": "火箭军48旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 454,
                                        "name": "火箭军22旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 455,
                                        "name": "火箭军10旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 456,
                                        "name": "火箭军5旅",
                                        "country": "日本",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 457,
                                "name": "战略支援部队",
                                "country": "日本",
                                "children": [
                                    {
                                        "id": 458,
                                        "name": "战略支援部队43旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 459,
                                        "name": "战略支援部队21旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 460,
                                        "name": "战略支援部队10旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 461,
                                        "name": "战略支援部队46旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 462,
                                        "name": "战略支援部队14旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 463,
                                        "name": "战略支援部队29旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 465,
                                        "name": "战略支援部队30旅",
                                        "country": "日本",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 466,
                                "name": "联合指挥部",
                                "country": "日本",
                                "children": [
                                    {
                                        "id": 467,
                                        "name": "联合指挥部47旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 468,
                                        "name": "联合指挥部30旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 469,
                                        "name": "联合指挥部3旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 470,
                                        "name": "联合指挥部7旅",
                                        "country": "日本",
                                        "children": null
                                    },
                                    {
                                        "id": 471,
                                        "name": "联合指挥部4旅",
                                        "country": "日本",
                                        "children": null
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "id": 472,
                        "name": "南部战区",
                        "country": "日本",
                        "children": null
                    },
                    {
                        "id": 527,
                        "name": "西部战区",
                        "country": "日本",
                        "children": null
                    },
                    {
                        "id": 579,
                        "name": "北部战区",
                        "country": "日本",
                        "children": null
                    }
                ]
            },
            {
                "id": 628,
                "name": "韩国",
                "country": "韩国",
                "children": [
                    {
                        "id": 629,
                        "name": "东部战区",
                        "country": "韩国",
                        "children": [
                            {
                                "id": 630,
                                "name": "海军",
                                "country": "韩国",
                                "children": [
                                    {
                                        "id": 631,
                                        "name": "海军18旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 632,
                                        "name": "海军47旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 633,
                                        "name": "海军1旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 634,
                                        "name": "海军16旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 635,
                                        "name": "海军37旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 636,
                                        "name": "海军28旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 638,
                                        "name": "海军14旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 639,
                                        "name": "海军38旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 640,
                                        "name": "海军34旅",
                                        "country": "韩国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 641,
                                "name": "陆军",
                                "country": "韩国",
                                "children": [
                                    {
                                        "id": 642,
                                        "name": "陆军50旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 643,
                                        "name": "陆军30旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 644,
                                        "name": "陆军44旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 645,
                                        "name": "陆军24旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 646,
                                        "name": "陆军27旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 647,
                                        "name": "陆军35旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 648,
                                        "name": "陆军13旅",
                                        "country": "韩国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 651,
                                "name": "空军",
                                "country": "韩国",
                                "children": [
                                    {
                                        "id": 652,
                                        "name": "空军44旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 653,
                                        "name": "空军12旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 654,
                                        "name": "空军39旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 655,
                                        "name": "空军23旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 656,
                                        "name": "空军45旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 658,
                                        "name": "空军41旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 659,
                                        "name": "空军36旅",
                                        "country": "韩国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 660,
                                "name": "火箭军",
                                "country": "韩国",
                                "children": [
                                    {
                                        "id": 661,
                                        "name": "火箭军37旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 662,
                                        "name": "火箭军28旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 663,
                                        "name": "火箭军45旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 664,
                                        "name": "火箭军23旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 665,
                                        "name": "火箭军24旅",
                                        "country": "韩国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 666,
                                "name": "战略支援部队",
                                "country": "韩国",
                                "children": [
                                    {
                                        "id": 667,
                                        "name": "战略支援部队48旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 668,
                                        "name": "战略支援部队32旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 669,
                                        "name": "战略支援部队47旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 670,
                                        "name": "战略支援部队17旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 671,
                                        "name": "战略支援部队14旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 672,
                                        "name": "战略支援部队25旅",
                                        "country": "韩国",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 673,
                                "name": "联合指挥部",
                                "country": "韩国",
                                "children": [
                                    {
                                        "id": 674,
                                        "name": "联合指挥部47旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 675,
                                        "name": "联合指挥部41旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 676,
                                        "name": "联合指挥部23旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 677,
                                        "name": "联合指挥部34旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 679,
                                        "name": "联合指挥部20旅",
                                        "country": "韩国",
                                        "children": null
                                    },
                                    {
                                        "id": 680,
                                        "name": "联合指挥部4旅",
                                        "country": "韩国",
                                        "children": null
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "id": 681,
                        "name": "南部战区",
                        "country": "韩国",
                        "children": null
                    },
                    {
                        "id": 739,
                        "name": "西部战区",
                        "country": "韩国",
                        "children": null
                    },
                    {
                        "id": 794,
                        "name": "北部战区",
                        "country": "韩国",
                        "children": null
                    }
                ]
            },
            {
                "id": 844,
                "name": "台湾地区",
                "country": "台湾地区",
                "children": [
                    {
                        "id": 845,
                        "name": "东部战区",
                        "country": "台湾地区",
                        "children": [
                            {
                                "id": 846,
                                "name": "海军",
                                "country": "台湾地区",
                                "children": [
                                    {
                                        "id": 847,
                                        "name": "海军13旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 848,
                                        "name": "海军32旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 849,
                                        "name": "海军4旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 850,
                                        "name": "海军25旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 851,
                                        "name": "海军42旅",
                                        "country": "台湾地区",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 852,
                                "name": "陆军",
                                "country": "台湾地区",
                                "children": [
                                    {
                                        "id": 853,
                                        "name": "陆军42旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 854,
                                        "name": "陆军5旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 855,
                                        "name": "陆军11旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 856,
                                        "name": "陆军18旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 857,
                                        "name": "陆军41旅",
                                        "country": "台湾地区",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 858,
                                "name": "空军",
                                "country": "台湾地区",
                                "children": [
                                    {
                                        "id": 859,
                                        "name": "空军10旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 860,
                                        "name": "空军12旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 861,
                                        "name": "空军15旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 862,
                                        "name": "空军37旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 863,
                                        "name": "空军41旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 864,
                                        "name": "空军13旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 865,
                                        "name": "空军8旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 866,
                                        "name": "空军45旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 867,
                                        "name": "空军27旅",
                                        "country": "台湾地区",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 868,
                                "name": "火箭军",
                                "country": "台湾地区",
                                "children": [
                                    {
                                        "id": 869,
                                        "name": "火箭军27旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 870,
                                        "name": "火箭军23旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 871,
                                        "name": "火箭军49旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 872,
                                        "name": "火箭军37旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 873,
                                        "name": "火箭军7旅",
                                        "country": "台湾地区",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 874,
                                "name": "战略支援部队",
                                "country": "台湾地区",
                                "children": [
                                    {
                                        "id": 875,
                                        "name": "战略支援部队14旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 876,
                                        "name": "战略支援部队18旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 877,
                                        "name": "战略支援部队28旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 879,
                                        "name": "战略支援部队50旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 880,
                                        "name": "战略支援部队42旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 881,
                                        "name": "战略支援部队31旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 882,
                                        "name": "战略支援部队34旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 883,
                                        "name": "战略支援部队5旅",
                                        "country": "台湾地区",
                                        "children": null
                                    }
                                ]
                            },
                            {
                                "id": 884,
                                "name": "联合指挥部",
                                "country": "台湾地区",
                                "children": [
                                    {
                                        "id": 885,
                                        "name": "联合指挥部9旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 886,
                                        "name": "联合指挥部36旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 887,
                                        "name": "联合指挥部26旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 888,
                                        "name": "联合指挥部13旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 889,
                                        "name": "联合指挥部5旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 890,
                                        "name": "联合指挥部14旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 891,
                                        "name": "联合指挥部28旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 892,
                                        "name": "联合指挥部44旅",
                                        "country": "台湾地区",
                                        "children": null
                                    },
                                    {
                                        "id": 893,
                                        "name": "联合指挥部20旅",
                                        "country": "台湾地区",
                                        "children": null
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "id": 894,
                        "name": "南部战区",
                        "country": "台湾地区",
                        "children": null
                    },
                    {
                        "id": 947,
                        "name": "西部战区",
                        "country": "台湾地区",
                        "children": null
                    },
                    {
                        "id": 1001,
                        "name": "北部战区",
                        "country": "台湾地区",
                        "children": null
                    }
                ]
            }
        ],
        "chart3": [
            {
                "id": 1,
                "name": "中国",
                "children": null
            },
            {
                "id": 2,
                "name": "东部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 3,
                "name": "海军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 14
                    }
                ]
            },
            {
                "id": 4,
                "name": "海军13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 5,
                "name": "海军48旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 6,
                "name": "海军26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 7,
                "name": "海军49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 8,
                "name": "海军1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 9,
                "name": "海军43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 10,
                "name": "海军4旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 11,
                "name": "陆军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 17
                    }
                ]
            },
            {
                "id": 12,
                "name": "陆军13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 13,
                "name": "陆军46旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 14,
                "name": "陆军7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 15,
                "name": "陆军2旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 16,
                "name": "陆军5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 17,
                "name": "空军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 17
                    }
                ]
            },
            {
                "id": 18,
                "name": "空军5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 19,
                "name": "空军49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 20,
                "name": "空军36旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 22,
                "name": "空军3旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 12
                    }
                ]
            },
            {
                "id": 23,
                "name": "空军42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 24,
                "name": "空军9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 25,
                "name": "空军25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 26,
                "name": "空军39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 27,
                "name": "空军34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 12
                    }
                ]
            },
            {
                "id": 28,
                "name": "火箭军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 14
                    }
                ]
            },
            {
                "id": 29,
                "name": "火箭军31旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 30,
                "name": "火箭军20旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 31,
                "name": "火箭军8旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 12
                    }
                ]
            },
            {
                "id": 32,
                "name": "火箭军41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 33,
                "name": "火箭军34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 34,
                "name": "火箭军27旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 35,
                "name": "火箭军7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 37,
                "name": "火箭军14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 38,
                "name": "战略支援部队",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 16
                    }
                ]
            },
            {
                "id": 39,
                "name": "战略支援部队37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 40,
                "name": "战略支援部队42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 41,
                "name": "战略支援部队29旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 42,
                "name": "战略支援部队18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 43,
                "name": "战略支援部队7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 44,
                "name": "战略支援部队34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 45,
                "name": "战略支援部队24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 46,
                "name": "战略支援部队25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 47,
                "name": "联合指挥部",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 18
                    }
                ]
            },
            {
                "id": 48,
                "name": "联合指挥部2旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 49,
                "name": "联合指挥部16旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 50,
                "name": "联合指挥部23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 51,
                "name": "联合指挥部12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 52,
                "name": "联合指挥部40旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 53,
                "name": "联合指挥部7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 54,
                "name": "联合指挥部43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 12
                    }
                ]
            },
            {
                "id": 55,
                "name": "联合指挥部15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 56,
                "name": "联合指挥部10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 58,
                "name": "南部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 60,
                "name": "海军24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 61,
                "name": "海军42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 64,
                "name": "海军15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 66,
                "name": "陆军43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 68,
                "name": "陆军10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 69,
                "name": "陆军30旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 70,
                "name": "陆军19旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 71,
                "name": "陆军14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 72,
                "name": "陆军1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 74,
                "name": "空军10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 75,
                "name": "空军6旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 82,
                "name": "火箭军25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 83,
                "name": "火箭军30旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 85,
                "name": "火箭军18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 86,
                "name": "火箭军21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 87,
                "name": "火箭军37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 88,
                "name": "火箭军50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 90,
                "name": "战略支援部队3旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 91,
                "name": "战略支援部队20旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 93,
                "name": "战略支援部队46旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 94,
                "name": "战略支援部队16旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 95,
                "name": "战略支援部队27旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 97,
                "name": "联合指挥部41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 98,
                "name": "联合指挥部17旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 100,
                "name": "联合指挥部38旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 101,
                "name": "联合指挥部24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 102,
                "name": "西部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 104,
                "name": "海军17旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 105,
                "name": "海军22旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 107,
                "name": "海军10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 109,
                "name": "海军6旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 13
                    }
                ]
            },
            {
                "id": 113,
                "name": "陆军28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 116,
                "name": "陆军8旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 118,
                "name": "陆军38旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 119,
                "name": "陆军33旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 121,
                "name": "空军22旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 122,
                "name": "空军17旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 124,
                "name": "空军44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 125,
                "name": "空军2旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 128,
                "name": "空军41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 130,
                "name": "火箭军36旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 131,
                "name": "火箭军2旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 133,
                "name": "火箭军39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 136,
                "name": "战略支援部队8旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 137,
                "name": "战略支援部队6旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 138,
                "name": "战略支援部队17旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 140,
                "name": "战略支援部队35旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 141,
                "name": "战略支援部队32旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 143,
                "name": "战略支援部队36旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 144,
                "name": "战略支援部队2旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 145,
                "name": "战略支援部队38旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 147,
                "name": "联合指挥部26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 149,
                "name": "联合指挥部47旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 150,
                "name": "联合指挥部14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 151,
                "name": "联合指挥部42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 152,
                "name": "联合指挥部50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 154,
                "name": "北部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 157,
                "name": "海军12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 159,
                "name": "海军7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 160,
                "name": "海军37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 161,
                "name": "海军30旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 163,
                "name": "海军44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 165,
                "name": "海军23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 167,
                "name": "陆军12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 169,
                "name": "陆军41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 172,
                "name": "陆军45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 173,
                "name": "陆军24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 174,
                "name": "陆军9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 178,
                "name": "空军40旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 179,
                "name": "空军15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 180,
                "name": "空军45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 182,
                "name": "空军47旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 185,
                "name": "火箭军38旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 186,
                "name": "火箭军49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 187,
                "name": "火箭军46旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 188,
                "name": "火箭军33旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 189,
                "name": "火箭军24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 193,
                "name": "战略支援部队43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 194,
                "name": "战略支援部队26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 195,
                "name": "战略支援部队50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 196,
                "name": "战略支援部队23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 198,
                "name": "战略支援部队47旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 199,
                "name": "战略支援部队15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 200,
                "name": "战略支援部队4旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 202,
                "name": "联合指挥部39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 206,
                "name": "联合指挥部3旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 207,
                "name": "美国",
                "children": null
            },
            {
                "id": 208,
                "name": "东部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 209,
                "name": "海军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 17
                    }
                ]
            },
            {
                "id": 210,
                "name": "海军17旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 211,
                "name": "海军27旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 212,
                "name": "海军31旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 213,
                "name": "海军19旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 215,
                "name": "海军3旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 216,
                "name": "海军15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 217,
                "name": "海军35旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 218,
                "name": "海军11旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 219,
                "name": "陆军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 16
                    }
                ]
            },
            {
                "id": 220,
                "name": "陆军20旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 221,
                "name": "陆军12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 222,
                "name": "陆军50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 223,
                "name": "陆军18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 224,
                "name": "陆军23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 225,
                "name": "陆军49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 226,
                "name": "陆军28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 227,
                "name": "陆军24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 229,
                "name": "空军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 15
                    }
                ]
            },
            {
                "id": 230,
                "name": "空军44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 231,
                "name": "空军49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 232,
                "name": "空军21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 12
                    }
                ]
            },
            {
                "id": 233,
                "name": "空军18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 234,
                "name": "空军13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 235,
                "name": "空军34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 236,
                "name": "火箭军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 13
                    }
                ]
            },
            {
                "id": 237,
                "name": "火箭军5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 238,
                "name": "火箭军11旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 239,
                "name": "火箭军26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 240,
                "name": "火箭军35旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 241,
                "name": "火箭军40旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 242,
                "name": "火箭军1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 243,
                "name": "火箭军38旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 244,
                "name": "火箭军24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 245,
                "name": "战略支援部队",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 17
                    }
                ]
            },
            {
                "id": 246,
                "name": "战略支援部队21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 247,
                "name": "战略支援部队2旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 248,
                "name": "战略支援部队19旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 249,
                "name": "战略支援部队47旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 250,
                "name": "战略支援部队26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 251,
                "name": "战略支援部队7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 252,
                "name": "战略支援部队15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 253,
                "name": "战略支援部队36旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 254,
                "name": "战略支援部队34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 255,
                "name": "战略支援部队24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 12
                    }
                ]
            },
            {
                "id": 256,
                "name": "联合指挥部",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 17
                    }
                ]
            },
            {
                "id": 257,
                "name": "联合指挥部13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 258,
                "name": "联合指挥部3旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 259,
                "name": "联合指挥部9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 260,
                "name": "联合指挥部35旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 261,
                "name": "联合指挥部19旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 262,
                "name": "联合指挥部20旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 263,
                "name": "联合指挥部23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 264,
                "name": "南部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 267,
                "name": "海军23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 268,
                "name": "海军37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 269,
                "name": "海军9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 270,
                "name": "海军20旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 271,
                "name": "海军30旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 272,
                "name": "海军29旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 273,
                "name": "海军21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 274,
                "name": "海军1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 275,
                "name": "海军18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 278,
                "name": "陆军42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 280,
                "name": "陆军40旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 13
                    }
                ]
            },
            {
                "id": 281,
                "name": "陆军21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 284,
                "name": "空军47旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 285,
                "name": "空军32旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 286,
                "name": "空军17旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 287,
                "name": "空军2旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 289,
                "name": "空军24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 290,
                "name": "空军50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 292,
                "name": "空军19旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 294,
                "name": "火箭军12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 295,
                "name": "火箭军46旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 296,
                "name": "火箭军34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 297,
                "name": "火箭军14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 299,
                "name": "火箭军7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 300,
                "name": "火箭军23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 302,
                "name": "战略支援部队32旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 304,
                "name": "战略支援部队28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 306,
                "name": "战略支援部队31旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 308,
                "name": "联合指挥部37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 309,
                "name": "联合指挥部4旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 310,
                "name": "联合指挥部39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 311,
                "name": "联合指挥部18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 312,
                "name": "联合指挥部24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 313,
                "name": "联合指挥部49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 314,
                "name": "西部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 316,
                "name": "海军12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 317,
                "name": "海军49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 319,
                "name": "海军16旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 320,
                "name": "海军50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 321,
                "name": "海军48旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 324,
                "name": "陆军44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 325,
                "name": "陆军10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 326,
                "name": "陆军5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 327,
                "name": "陆军32旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 328,
                "name": "陆军13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 330,
                "name": "空军3旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 331,
                "name": "空军9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 332,
                "name": "空军7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 333,
                "name": "空军31旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 334,
                "name": "空军1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 335,
                "name": "空军26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 337,
                "name": "空军4旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 338,
                "name": "空军48旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 339,
                "name": "空军37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 341,
                "name": "火箭军9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 342,
                "name": "火箭军18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 343,
                "name": "火箭军21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 345,
                "name": "火箭军15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 347,
                "name": "战略支援部队27旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 348,
                "name": "战略支援部队38旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 349,
                "name": "战略支援部队11旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 350,
                "name": "战略支援部队3旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 351,
                "name": "战略支援部队44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 353,
                "name": "战略支援部队40旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 354,
                "name": "战略支援部队39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 356,
                "name": "联合指挥部27旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 357,
                "name": "联合指挥部22旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 358,
                "name": "联合指挥部41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 359,
                "name": "联合指挥部10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 360,
                "name": "联合指挥部15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 361,
                "name": "联合指挥部12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 362,
                "name": "北部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 364,
                "name": "海军13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 365,
                "name": "海军36旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 370,
                "name": "海军45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 372,
                "name": "陆军45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 373,
                "name": "陆军36旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 378,
                "name": "空军39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 379,
                "name": "空军41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 380,
                "name": "空军8旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 382,
                "name": "空军14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 383,
                "name": "空军38旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 385,
                "name": "空军15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 386,
                "name": "空军11旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 388,
                "name": "火箭军45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 389,
                "name": "火箭军44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 390,
                "name": "火箭军2旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 391,
                "name": "火箭军13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 392,
                "name": "火箭军33旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 393,
                "name": "火箭军16旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 395,
                "name": "战略支援部队13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 401,
                "name": "战略支援部队37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 405,
                "name": "联合指挥部44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 406,
                "name": "联合指挥部16旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 407,
                "name": "联合指挥部30旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 409,
                "name": "联合指挥部42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 411,
                "name": "联合指挥部50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 413,
                "name": "联合指挥部46旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 415,
                "name": "日本",
                "children": null
            },
            {
                "id": 416,
                "name": "东部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 417,
                "name": "海军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 15
                    }
                ]
            },
            {
                "id": 418,
                "name": "海军13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 419,
                "name": "海军32旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 420,
                "name": "海军45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 421,
                "name": "海军24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 422,
                "name": "海军25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 423,
                "name": "海军23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 424,
                "name": "海军1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 425,
                "name": "海军10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 426,
                "name": "海军5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 427,
                "name": "海军34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 428,
                "name": "陆军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 15
                    }
                ]
            },
            {
                "id": 429,
                "name": "陆军33旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 430,
                "name": "陆军13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 431,
                "name": "陆军50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 432,
                "name": "陆军1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 433,
                "name": "陆军25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 434,
                "name": "陆军29旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 435,
                "name": "陆军43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 17
                    }
                ]
            },
            {
                "id": 436,
                "name": "陆军27旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 437,
                "name": "陆军35旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 438,
                "name": "陆军44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 439,
                "name": "空军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 16
                    }
                ]
            },
            {
                "id": 440,
                "name": "空军11旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 441,
                "name": "空军42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 443,
                "name": "空军45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 444,
                "name": "空军12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 445,
                "name": "空军27旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 446,
                "name": "火箭军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 14
                    }
                ]
            },
            {
                "id": 447,
                "name": "火箭军4旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 448,
                "name": "火箭军7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 449,
                "name": "火箭军13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 450,
                "name": "火箭军18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 451,
                "name": "火箭军31旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 452,
                "name": "火箭军8旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 453,
                "name": "火箭军48旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 454,
                "name": "火箭军22旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 455,
                "name": "火箭军10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 456,
                "name": "火箭军5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 457,
                "name": "战略支援部队",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 17
                    }
                ]
            },
            {
                "id": 458,
                "name": "战略支援部队43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 19
                    }
                ]
            },
            {
                "id": 459,
                "name": "战略支援部队21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 460,
                "name": "战略支援部队10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 461,
                "name": "战略支援部队46旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 462,
                "name": "战略支援部队14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 463,
                "name": "战略支援部队29旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 13
                    }
                ]
            },
            {
                "id": 465,
                "name": "战略支援部队30旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 466,
                "name": "联合指挥部",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 16
                    }
                ]
            },
            {
                "id": 467,
                "name": "联合指挥部47旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 468,
                "name": "联合指挥部30旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 469,
                "name": "联合指挥部3旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 470,
                "name": "联合指挥部7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 471,
                "name": "联合指挥部4旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 472,
                "name": "南部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 474,
                "name": "海军14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 475,
                "name": "海军16旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 476,
                "name": "海军21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 477,
                "name": "海军7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 478,
                "name": "海军49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 480,
                "name": "海军29旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 485,
                "name": "陆军17旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 487,
                "name": "陆军23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 488,
                "name": "陆军11旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 489,
                "name": "陆军28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 490,
                "name": "陆军9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 493,
                "name": "空军43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 494,
                "name": "空军49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 495,
                "name": "空军14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 496,
                "name": "空军23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 497,
                "name": "空军9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 498,
                "name": "空军46旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 500,
                "name": "火箭军21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 501,
                "name": "火箭军28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 502,
                "name": "火箭军2旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 503,
                "name": "火箭军16旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 505,
                "name": "火箭军46旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 507,
                "name": "火箭军43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 509,
                "name": "战略支援部队41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 511,
                "name": "战略支援部队50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 512,
                "name": "战略支援部队15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 514,
                "name": "战略支援部队26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 515,
                "name": "战略支援部队42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 516,
                "name": "战略支援部队8旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 517,
                "name": "战略支援部队32旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 518,
                "name": "战略支援部队36旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 520,
                "name": "联合指挥部39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 521,
                "name": "联合指挥部1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 522,
                "name": "联合指挥部2旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 523,
                "name": "联合指挥部46旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 524,
                "name": "联合指挥部44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 526,
                "name": "联合指挥部25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 527,
                "name": "西部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 529,
                "name": "海军41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 530,
                "name": "海军37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 532,
                "name": "海军19旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 533,
                "name": "海军26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 534,
                "name": "海军15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 536,
                "name": "海军28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 537,
                "name": "海军4旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 541,
                "name": "陆军34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 544,
                "name": "陆军5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 545,
                "name": "陆军48旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 547,
                "name": "空军19旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 548,
                "name": "空军10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 549,
                "name": "空军36旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 550,
                "name": "空军15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 551,
                "name": "空军5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 557,
                "name": "火箭军49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 558,
                "name": "火箭军19旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 560,
                "name": "战略支援部队48旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 565,
                "name": "战略支援部队37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 566,
                "name": "战略支援部队9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 567,
                "name": "战略支援部队12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 568,
                "name": "战略支援部队2旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 569,
                "name": "战略支援部队7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 572,
                "name": "联合指挥部5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 573,
                "name": "联合指挥部16旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 576,
                "name": "联合指挥部50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 577,
                "name": "联合指挥部42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 578,
                "name": "联合指挥部26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 579,
                "name": "北部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 581,
                "name": "海军31旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 582,
                "name": "海军30旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 583,
                "name": "海军40旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 587,
                "name": "陆军42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 588,
                "name": "陆军39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 596,
                "name": "空军4旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 597,
                "name": "空军39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 598,
                "name": "空军1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 599,
                "name": "空军40旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 600,
                "name": "空军26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 601,
                "name": "空军25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 602,
                "name": "空军35旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 606,
                "name": "火箭军44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 608,
                "name": "火箭军9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 609,
                "name": "火箭军3旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 612,
                "name": "战略支援部队3旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 613,
                "name": "战略支援部队38旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 622,
                "name": "联合指挥部23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 624,
                "name": "联合指挥部35旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 625,
                "name": "联合指挥部40旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 626,
                "name": "联合指挥部24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 628,
                "name": "韩国",
                "children": null
            },
            {
                "id": 629,
                "name": "东部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 630,
                "name": "海军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 16
                    }
                ]
            },
            {
                "id": 631,
                "name": "海军18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 632,
                "name": "海军47旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 633,
                "name": "海军1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 12
                    }
                ]
            },
            {
                "id": 634,
                "name": "海军16旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 635,
                "name": "海军37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 14
                    }
                ]
            },
            {
                "id": 636,
                "name": "海军28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 638,
                "name": "海军14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 639,
                "name": "海军38旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 640,
                "name": "海军34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 641,
                "name": "陆军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 14
                    }
                ]
            },
            {
                "id": 642,
                "name": "陆军50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 643,
                "name": "陆军30旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 644,
                "name": "陆军44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 645,
                "name": "陆军24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 646,
                "name": "陆军27旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 647,
                "name": "陆军35旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 648,
                "name": "陆军13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 651,
                "name": "空军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 18
                    }
                ]
            },
            {
                "id": 652,
                "name": "空军44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 653,
                "name": "空军12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 654,
                "name": "空军39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 13
                    }
                ]
            },
            {
                "id": 655,
                "name": "空军23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 13
                    }
                ]
            },
            {
                "id": 656,
                "name": "空军45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 658,
                "name": "空军41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 659,
                "name": "空军36旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 660,
                "name": "火箭军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 16
                    }
                ]
            },
            {
                "id": 661,
                "name": "火箭军37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 662,
                "name": "火箭军28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 663,
                "name": "火箭军45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 664,
                "name": "火箭军23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 665,
                "name": "火箭军24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 666,
                "name": "战略支援部队",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 15
                    }
                ]
            },
            {
                "id": 667,
                "name": "战略支援部队48旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 668,
                "name": "战略支援部队32旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 669,
                "name": "战略支援部队47旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 670,
                "name": "战略支援部队17旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 671,
                "name": "战略支援部队14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 672,
                "name": "战略支援部队25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 673,
                "name": "联合指挥部",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 13
                    }
                ]
            },
            {
                "id": 674,
                "name": "联合指挥部47旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 675,
                "name": "联合指挥部41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 676,
                "name": "联合指挥部23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 17
                    }
                ]
            },
            {
                "id": 677,
                "name": "联合指挥部34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 679,
                "name": "联合指挥部20旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 680,
                "name": "联合指挥部4旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 681,
                "name": "南部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 683,
                "name": "海军5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 684,
                "name": "海军19旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 685,
                "name": "海军6旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 687,
                "name": "海军39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 688,
                "name": "海军30旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 691,
                "name": "海军29旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 692,
                "name": "海军42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 694,
                "name": "陆军26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 695,
                "name": "陆军12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 696,
                "name": "陆军5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 697,
                "name": "陆军10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 698,
                "name": "陆军34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 699,
                "name": "陆军28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 701,
                "name": "陆军11旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 703,
                "name": "陆军16旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 706,
                "name": "空军46旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 709,
                "name": "空军2旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 710,
                "name": "空军35旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 711,
                "name": "空军25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 712,
                "name": "空军33旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 713,
                "name": "空军47旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 716,
                "name": "火箭军4旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 717,
                "name": "火箭军6旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 718,
                "name": "火箭军47旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 719,
                "name": "火箭军13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 720,
                "name": "火箭军36旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 721,
                "name": "火箭军9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 723,
                "name": "火箭军43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 724,
                "name": "火箭军14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 726,
                "name": "战略支援部队39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 727,
                "name": "战略支援部队22旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 728,
                "name": "战略支援部队3旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 729,
                "name": "战略支援部队42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 730,
                "name": "战略支援部队11旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 731,
                "name": "战略支援部队15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 733,
                "name": "联合指挥部10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 734,
                "name": "联合指挥部14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 735,
                "name": "联合指挥部1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 736,
                "name": "联合指挥部12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 737,
                "name": "联合指挥部28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 739,
                "name": "西部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 741,
                "name": "海军26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 742,
                "name": "海军43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 744,
                "name": "海军20旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 745,
                "name": "海军12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 750,
                "name": "陆军17旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 752,
                "name": "陆军38旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 753,
                "name": "陆军31旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 754,
                "name": "陆军22旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 755,
                "name": "陆军20旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 756,
                "name": "陆军39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 760,
                "name": "空军1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 761,
                "name": "空军21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 762,
                "name": "空军26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 763,
                "name": "空军34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 764,
                "name": "空军22旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 766,
                "name": "空军8旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 768,
                "name": "空军6旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 771,
                "name": "火箭军3旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 772,
                "name": "火箭军39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 773,
                "name": "火箭军18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 774,
                "name": "火箭军33旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 775,
                "name": "火箭军42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 776,
                "name": "火箭军10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 777,
                "name": "火箭军1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 778,
                "name": "火箭军40旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 782,
                "name": "战略支援部队10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 784,
                "name": "战略支援部队49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 785,
                "name": "战略支援部队21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 787,
                "name": "联合指挥部30旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 789,
                "name": "联合指挥部21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 790,
                "name": "联合指挥部27旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 791,
                "name": "联合指挥部24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 793,
                "name": "联合指挥部18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 794,
                "name": "北部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 797,
                "name": "海军50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 798,
                "name": "海军9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 800,
                "name": "海军25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 804,
                "name": "陆军15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 806,
                "name": "陆军43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 807,
                "name": "陆军7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 809,
                "name": "陆军21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 815,
                "name": "空军28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 816,
                "name": "空军16旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 818,
                "name": "空军14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 822,
                "name": "火箭军44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 825,
                "name": "火箭军50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 826,
                "name": "火箭军29旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 828,
                "name": "战略支援部队46旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 829,
                "name": "战略支援部队7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 832,
                "name": "战略支援部队6旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 835,
                "name": "联合指挥部29旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 839,
                "name": "联合指挥部25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 841,
                "name": "联合指挥部39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 842,
                "name": "联合指挥部35旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 843,
                "name": "联合指挥部11旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 844,
                "name": "台湾地区",
                "children": null
            },
            {
                "id": 845,
                "name": "东部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 846,
                "name": "海军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 15
                    }
                ]
            },
            {
                "id": 847,
                "name": "海军13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 848,
                "name": "海军32旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 13
                    }
                ]
            },
            {
                "id": 849,
                "name": "海军4旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 850,
                "name": "海军25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 851,
                "name": "海军42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 852,
                "name": "陆军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 18
                    }
                ]
            },
            {
                "id": 853,
                "name": "陆军42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 854,
                "name": "陆军5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 855,
                "name": "陆军11旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 856,
                "name": "陆军18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 12
                    }
                ]
            },
            {
                "id": 857,
                "name": "陆军41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 858,
                "name": "空军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 16
                    }
                ]
            },
            {
                "id": 859,
                "name": "空军10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 860,
                "name": "空军12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 861,
                "name": "空军15旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 862,
                "name": "空军37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 863,
                "name": "空军41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 864,
                "name": "空军13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 865,
                "name": "空军8旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 866,
                "name": "空军45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 867,
                "name": "空军27旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 868,
                "name": "火箭军",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 17
                    }
                ]
            },
            {
                "id": 869,
                "name": "火箭军27旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 870,
                "name": "火箭军23旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 871,
                "name": "火箭军49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 872,
                "name": "火箭军37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 873,
                "name": "火箭军7旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 874,
                "name": "战略支援部队",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 17
                    }
                ]
            },
            {
                "id": 875,
                "name": "战略支援部队14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 876,
                "name": "战略支援部队18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 877,
                "name": "战略支援部队28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 879,
                "name": "战略支援部队50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 880,
                "name": "战略支援部队42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 881,
                "name": "战略支援部队31旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 882,
                "name": "战略支援部队34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 883,
                "name": "战略支援部队5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 884,
                "name": "联合指挥部",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 16
                    }
                ]
            },
            {
                "id": 885,
                "name": "联合指挥部9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 886,
                "name": "联合指挥部36旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 887,
                "name": "联合指挥部26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 888,
                "name": "联合指挥部13旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 889,
                "name": "联合指挥部5旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 890,
                "name": "联合指挥部14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 891,
                "name": "联合指挥部28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 892,
                "name": "联合指挥部44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 893,
                "name": "联合指挥部20旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 894,
                "name": "南部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 898,
                "name": "海军33旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 899,
                "name": "海军17旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 900,
                "name": "海军24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 901,
                "name": "海军22旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 904,
                "name": "陆军39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 905,
                "name": "陆军45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 906,
                "name": "陆军30旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 907,
                "name": "陆军28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 911,
                "name": "陆军49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 912,
                "name": "陆军34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 914,
                "name": "空军9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 915,
                "name": "空军48旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 916,
                "name": "空军21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 917,
                "name": "空军42旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 919,
                "name": "空军28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 920,
                "name": "空军3旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 922,
                "name": "空军49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 924,
                "name": "火箭军48旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 925,
                "name": "火箭军41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 926,
                "name": "火箭军34旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 10
                    }
                ]
            },
            {
                "id": 927,
                "name": "火箭军50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 930,
                "name": "战略支援部队36旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 15
                    }
                ]
            },
            {
                "id": 931,
                "name": "战略支援部队44旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 932,
                "name": "战略支援部队1旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 933,
                "name": "战略支援部队22旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 934,
                "name": "战略支援部队26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 935,
                "name": "战略支援部队17旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 936,
                "name": "战略支援部队41旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 937,
                "name": "战略支援部队45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 939,
                "name": "战略支援部队8旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 941,
                "name": "联合指挥部37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 943,
                "name": "联合指挥部25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 946,
                "name": "联合指挥部19旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 947,
                "name": "西部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 949,
                "name": "海军35旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 950,
                "name": "海军6旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 951,
                "name": "海军21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 952,
                "name": "海军28旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 953,
                "name": "海军18旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 957,
                "name": "陆军29旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 959,
                "name": "陆军43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 960,
                "name": "陆军25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 961,
                "name": "陆军37旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 966,
                "name": "空军20旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 967,
                "name": "空军11旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 968,
                "name": "空军50旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 971,
                "name": "空军25旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 973,
                "name": "空军14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 975,
                "name": "空军43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 977,
                "name": "火箭军21旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 978,
                "name": "火箭军43旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 979,
                "name": "火箭军12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 980,
                "name": "火箭军35旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 15
                    }
                ]
            },
            {
                "id": 981,
                "name": "火箭军22旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 986,
                "name": "战略支援部队20旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 988,
                "name": "战略支援部队19旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 6
                    }
                ]
            },
            {
                "id": 989,
                "name": "战略支援部队48旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 992,
                "name": "联合指挥部45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 9
                    }
                ]
            },
            {
                "id": 993,
                "name": "联合指挥部11旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 994,
                "name": "联合指挥部24旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 8
                    }
                ]
            },
            {
                "id": 996,
                "name": "联合指挥部10旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 997,
                "name": "联合指挥部22旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 998,
                "name": "联合指挥部17旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 999,
                "name": "联合指挥部16旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 11
                    }
                ]
            },
            {
                "id": 1001,
                "name": "北部战区",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 1005,
                "name": "海军20旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 1006,
                "name": "海军49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 1007,
                "name": "海军26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 1010,
                "name": "陆军31旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 1011,
                "name": "陆军12旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 1013,
                "name": "陆军9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 1016,
                "name": "空军26旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 1020,
                "name": "空军2旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 1021,
                "name": "空军38旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 1026,
                "name": "火箭军9旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 1028,
                "name": "火箭军14旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 1031,
                "name": "火箭军45旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 1032,
                "name": "火箭军38旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 5
                    }
                ]
            },
            {
                "id": 1036,
                "name": "战略支援部队46旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 1037,
                "name": "战略支援部队40旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 1038,
                "name": "战略支援部队27旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 4
                    }
                ]
            },
            {
                "id": 1039,
                "name": "战略支援部队4旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 1041,
                "name": "战略支援部队33旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 1045,
                "name": "战略支援部队39旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 1051,
                "name": "联合指挥部40旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 7
                    }
                ]
            },
            {
                "id": 1053,
                "name": "联合指挥部33旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            },
            {
                "id": 1054,
                "name": "联合指挥部49旅",
                "children": [
                    {
                        "name": "WQ装备",
                        "count": 3
                    }
                ]
            }
        ]
    }
}

{
    "code": 200,
    "msg": "success",
    "data": [
        {
            "equipmentId": 817,
            "country": "美国",
            "unitId": 210,
            "parentUnitId": 209,
            "equipmentCategory": "WQ装备",
            "equipmentName": "雷达系统-7496",
            "model": "型号-14",
            "isIntegrated": true,
            "description": "描述：高效能",
            "rangeKm": 1956.0,
            "speedKmH": 976.0,
            "payloadKg": 363.0,
            "bandwidthMbps": 928.0,
            "enduranceH": 17.0,
            "parentEquipmentId": null
        },
        {
            "equipmentId": 818,
            "country": "美国",
            "unitId": 210,
            "parentUnitId": 209,
            "equipmentCategory": "WQ装备",
            "equipmentName": "无人平台-2212",
            "model": "型号-5",
            "isIntegrated": false,
            "description": "描述：多功能",
            "rangeKm": 495.0,
            "speedKmH": 440.0,
            "payloadKg": 4887.0,
            "bandwidthMbps": 908.0,
            "enduranceH": 29.0,
            "parentEquipmentId": null
        },
        {
            "equipmentId": 819,
            "country": "美国",
            "unitId": 210,
            "parentUnitId": 209,
            "equipmentCategory": "WQ装备",
            "equipmentName": "雷达系统-6283",
            "model": "型号-2",
            "isIntegrated": true,
            "description": "描述：高频段",
            "rangeKm": 1092.0,
            "speedKmH": 346.0,
            "payloadKg": 4872.0,
            "bandwidthMbps": 666.0,
            "enduranceH": 40.0,
            "parentEquipmentId": null
        },
        {
            "equipmentId": 820,
            "country": "美国",
            "unitId": 210,
            "parentUnitId": 209,
            "equipmentCategory": "WQ装备",
            "equipmentName": "无人平台-8717",
            "model": "型号-43",
            "isIntegrated": false,
            "description": "描述：集成平台",
            "rangeKm": 1980.0,
            "speedKmH": 874.0,
            "payloadKg": 3014.0,
            "bandwidthMbps": 608.0,
            "enduranceH": 28.0,
            "parentEquipmentId": null
        },
        {
            "equipmentId": 821,
            "country": "美国",
            "unitId": 210,
            "parentUnitId": 209,
            "equipmentCategory": "WQ装备",
            "equipmentName": "侦测器-8599",
            "model": "型号-13",
            "isIntegrated": true,
            "description": "描述：单一用途",
            "rangeKm": 242.0,
            "speedKmH": 756.0,
            "payloadKg": 3488.0,
            "bandwidthMbps": 550.0,
            "enduranceH": 4.0,
            "parentEquipmentId": null
        }
    ]
}