import axios from 'axios'

const api = axios.create({
    // 使用 Vite 代理，开发环境走 /api，避免跨域
    // /api
    // https://dev-api.lizh.tech/api
    baseURL: '/api',
    //   baseURL: 'https://dev-api.lizh.tech/api',
    // timeout: 10000
})

api.interceptors.response.use(
    (response) => response,
    (error) => Promise.reject(error)
)

export default api


