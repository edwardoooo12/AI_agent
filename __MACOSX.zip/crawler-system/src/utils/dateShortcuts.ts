export type TimeShortcut = { text: string; value: number };

/**
 * 格式化日期时间
 * @param date 日期对象或可以被转换为日期的字符串/时间戳
 * @param format 格式模板，默认为 'YYYY-MM-DD HH:mm:ss'
 * @returns 格式化后的日期字符串
 *
 * 支持的格式：
 * - YYYY: 四位年份
 * - MM: 两位月份（01-12）
 * - DD: 两位日期（01-31）
 * - HH: 两位小时（00-23）
 * - mm: 两位分钟（00-59）
 * - ss: 两位秒钟（00-59）
 * - SSS: 三位毫秒（000-999）
 */
export function formatDate(
  date: Date | string | number = new Date(),
  format: string = "YYYY-MM-DD HH:mm:ss"
): string {
  if (!date) return "";
  const d = date instanceof Date ? date : new Date(date);

  if (Number.isNaN(d.getTime())) {
    console.error("格式化的日期无效");
    return "";
  }

  const tokens: Record<string, string> = {
    YYYY: String(d.getFullYear()),
    MM: String(d.getMonth() + 1).padStart(2, "0"),
    DD: String(d.getDate()).padStart(2, "0"),
    HH: String(d.getHours()).padStart(2, "0"),
    mm: String(d.getMinutes()).padStart(2, "0"),
    ss: String(d.getSeconds()).padStart(2, "0"),
    SSS: String(d.getMilliseconds()).padStart(3, "0"),
  };

  return format.replace(/(YYYY|MM|DD|HH|mm|ss|SSS)/g, (match) => tokens[match]);
}

/**
 * 获取相对时间描述（例如："刚刚"，"5分钟前"，"2小时前"等）
 * @param date 日期对象或可以被转换为日期的字符串/时间戳
 * @param now 当前时间参考点，默认为当前时间
 * @param useRelative 是否使用相对时间，默认为true。如果为false则返回格式化的日期
 * @returns 相对时间描述或格式化的日期
 */
export function getRelativeTime(
  date: Date | string | number,
  now: Date | string | number = new Date(),
  useRelative: boolean = true
): string {
  const d = date instanceof Date ? date : new Date(date);
  const currentTime = now instanceof Date ? now : new Date(now);

  if (Number.isNaN(d.getTime()) || Number.isNaN(currentTime.getTime())) {
    console.error("Invalid date provided to getRelativeTime");
    return "Invalid Date";
  }

  // 如果不使用相对时间，直接返回格式化的日期
  if (!useRelative) {
    return formatDate(d);
  }

  const diffInSeconds = Math.floor(
    (currentTime.getTime() - d.getTime()) / 1000
  );

  if (diffInSeconds < 0) {
    return formatDate(d);
  }

  if (diffInSeconds < 60) {
    return "刚刚";
  }

  if (diffInSeconds < 3600) {
    return `${Math.floor(diffInSeconds / 60)}分钟前`;
  }

  if (diffInSeconds < 86400) {
    return `${Math.floor(diffInSeconds / 3600)}小时前`;
  }

  if (diffInSeconds < 2592000) {
    return `${Math.floor(diffInSeconds / 86400)}天前`;
  }

  if (diffInSeconds < 31536000) {
    return `${Math.floor(diffInSeconds / 2592000)}个月前`;
  }

  return `${Math.floor(diffInSeconds / 31536000)}年前`;
}

// 统一的快捷项列表
export const TIME_SHORTCUTS: TimeShortcut[] = [
  { text: "今天", value: 0 },
  { text: "7天", value: 7 },
  { text: "30天", value: 30 },
  { text: "1年", value: 365 },
];

// 根据快捷项计算日期范围（YYYYMMDD, YYYYMMDD）
export function rangeForShortcut(
  shortcut: TimeShortcut,
  baseDate: Date = new Date()
): [string, string] {
  const end = new Date(baseDate);
  const start = new Date(baseDate);
  if (shortcut.value === 0) {
    return [formatDate(end, "YYYY-MM-DD"), formatDate(end, "YYYY-MM-DD")];
  }
  start.setDate(baseDate.getDate() - shortcut.value);
  return [formatDate(start, "YYYY-MM-DD"), formatDate(end, "YYYY-MM-DD")];
}

// 判断当前日期范围是否等于快捷项
export function isShortcutActive(
  dateRange: string[] | undefined,
  shortcut: TimeShortcut,
  baseDate: Date = new Date()
): boolean {
  if (!dateRange || dateRange.length !== 2) return false;
  const selectedStart = formatDate(dateRange[0], "YYYY-MM-DD");
  const selectedEnd = formatDate(dateRange[1], "YYYY-MM-DD");
  if (!selectedStart || !selectedEnd) return false;

  if (shortcut.value === 0) {
    return (
      formatDate(selectedStart, "YYYY-MM-DD") ===
        formatDate(baseDate, "YYYY-MM-DD") &&
      formatDate(selectedEnd, "YYYY-MM-DD") ===
        formatDate(baseDate, "YYYY-MM-DD")
    );
  }
  const expectedStart = new Date(baseDate);
  expectedStart.setDate(baseDate.getDate() - shortcut.value);

  return (
    formatDate(selectedStart, "YYYY-MM-DD") ===
      formatDate(expectedStart, "YYYY-MM-DD") &&
    formatDate(selectedEnd, "YYYY-MM-DD") === formatDate(baseDate, "YYYY-MM-DD")
  );
}
